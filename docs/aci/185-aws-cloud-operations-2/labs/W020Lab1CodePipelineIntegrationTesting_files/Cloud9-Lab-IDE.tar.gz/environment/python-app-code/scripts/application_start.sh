echo "application_start.sh"
sudo systemctl start flaskapp
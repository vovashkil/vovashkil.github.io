# app.py
import os
import uuid
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import aws_controller
from utils.validate_form_data import validate_form_inputs

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Needed for flash messages

"""
    This is the index route. It will display the index.html template.
"""
@app.route('/')
def index():
    return render_template("index.html")

"""
    This is the register_user route. It will take in the username, email, and password from the form and store it in the database.
"""
@app.route('/register_user', methods=["POST"])
def register_user():
    username = request.form.get("username")
    email = request.form.get("email")
    password = request.form.get("password")
    id = str(uuid.uuid4())

    # Validate the fields are filled out for username, email, and password
    errors = validate_form_inputs(username, email, password)
    if errors:
        for error in errors:
            flash(error)
        return redirect(url_for("index"))
    
    aws_controller.create_item(id, username, email, password)

    return redirect(url_for("dashboard"))

"""
    This is the dashboard route. It will display a list of all users in the database.
"""
@app.route('/dashboard')
def dashboard():
    users = aws_controller.get_items()["Items"]
    return render_template("dashboard.html", users=users)


if __name__ == "__main__":
    host = os.environ.get('IP', '127.0.0.1')
    port = int(os.environ.get('PORT', 5000))
    app.run(host=host, port=port, debug=True)
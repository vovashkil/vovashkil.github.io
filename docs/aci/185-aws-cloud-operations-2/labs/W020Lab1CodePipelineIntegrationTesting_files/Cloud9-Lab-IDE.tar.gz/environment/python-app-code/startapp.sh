#!/bin/bash
export AWS_DEFAULT_REGION=`curl http://169.254.169.254/latest/meta-data/placement/region`
/home/ec2-user/flask-app/venv/bin/gunicorn -b localhost:8000 -w 4 app:app
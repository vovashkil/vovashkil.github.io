echo "after_install.sh"

python3 -m pip install virtualenv

virtualenv /home/ec2-user/flask-app/venv
source /home/ec2-user/flask-app/venv/bin/activate

sudo chown -R ec2-user:ec2-user /home/ec2-user/flask-app
chmod +x /home/ec2-user/flask-app/startapp.sh

python3 -m pip install -r /home/ec2-user/flask-app/requirements.txt
sudo cp /home/ec2-user/flask-app/flaskapp.service /etc/systemd/system/flaskapp.service
sudo systemctl daemon-reload

sudo systemctl enable nginx
sudo systemctl start nginx

sudo cp /home/ec2-user/flask-app/flaskapp.conf /etc/nginx/conf.d/flaskapp.conf
sudo systemctl restart nginx
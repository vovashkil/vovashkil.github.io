import sys
import os
import pytest
import uuid
from unittest.mock import patch

# Add the project root to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.validate_form_data import validate_email
from app import app

def test_validate_email():
    # Valid email tests
    assert validate_email("test@example.com")
    assert validate_email("user.name+tag+sorting@example.com")
    assert validate_email("x@example.com")
    assert validate_email("example-indeed@strange-example.com")

    # Invalid email tests
    assert not validate_email("plainaddress")
    assert not validate_email("plainaddress@")
    assert not validate_email("@missinglocal.org")
    assert not validate_email("missingatsign.com")
    assert not validate_email("missingdot@com")
    assert not validate_email("missingdomain@.com")

@patch('utils.validate_form_data.validate_email')
def test_register_user_route(mock_validate_email):
    mock_validate_email.return_value = True

    with app.test_client() as client:
        response = client.post('/register_user', data={
            'id': str(uuid.uuid4()),
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'password123'
        })

        assert response.status_code == 302
        assert '/dashboard' in response.headers['Location']

@patch('utils.validate_form_data.validate_email')
def test_register_user_route_invalid_email(mock_validate_email):
    mock_validate_email.return_value = False

    with app.test_client() as client:
        response = client.post('/register_user', data={
            'id': str(uuid.uuid4()),
            'username': 'testuser',
            'email': 'invalid-email',
            'password': 'password123'
        })

        assert response.status_code == 302
        response = client.get('/')
        assert b'Invalid email' in response.data

import boto3
import pytest
import requests
import uuid

ec2 = boto3.resource('ec2')

# method to get the public IP of an ec2 instance by tag
def get_public_ip_by_tag(tag):
    
    instances = ec2.instances.filter(Filters=[{'Name': 'tag:Name', 'Values': [tag]}])
    for instance in instances:
        return instance.public_ip_address
        
@pytest.fixture()
def host_url():
    return get_public_ip_by_tag("EC2ApplicationServer")

def test_default_page_returns_200(host_url):
    host = get_public_ip_by_tag("EC2ApplicationServer")
    
    # make an http request to the public ip of the ec2 instance
    response = requests.get(f"http://{host}/")
    assert response.status_code == 200
    
    
def test_dashboard_page_returns_200(host_url):
    host = get_public_ip_by_tag("EC2ApplicationServer")

    response = requests.get(f"http://{host}/dashboard")
    assert response.status_code == 200
    
# post to /register_user redirects to dashboard
def test_register_user_redirects_to_dashboard(host_url):
    host = get_public_ip_by_tag("EC2ApplicationServer")

    # make an http request to the public ip of the ec2 instance
    response = requests.post(f"http://{host}/register_user", allow_redirects=True, data={"id": str(uuid.uuid4()), "username": "XXXXXXXXXXXXX", "email": "test@anycompany.com", "password": "test_password"})
    if response.history:
        print("Request was redirected")
        for resp in response.history:
            print(resp.status_code, resp.url)
        print("Final destination:")
        print(response.status_code, response.url)
    else:
        print("Request was not redirected")
        print(response.status_code, response.url)
    # Introduce an error by asserting an incorrect status code
    assert response.status_code == 200
    assert response.url == f"http://{host}/dashboard"

import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError


# Initialize a new instance of the DynamoDB client with the specified AWS access key, secret access key, and region.
dynamo_client = boto3.client('dynamodb')

table_name = 'user-table'

"""
Get all items from the DynamoDB table.

Returns:
    dict: A dictionary containing the response from the DynamoDB API.
"""
def get_items():
    try:
        return dynamo_client.scan(
            TableName=table_name
        )
    except (NoCredentialsError, PartialCredentialsError) as e:
        print(f"Credentials error: {e}")
        return None

"""
Create a new item in the DynamoDB table.

Args:
    id (str): The ID of the item.
    name (str): The name of the item.
    email (str): The email of the item.
    phone (str): The phone number of the item.

Returns:
    dict: A dictionary containing the response from the DynamoDB API.
"""
def create_item(id, username, email, password):
    return dynamo_client.put_item(
        TableName=table_name,
        Item={
            'id': {
                'S': id
            },
            'username': {
                'S': username
            },
            'email': {
                'S': email
            },
            'password': {
                'S': password
            }
        }
    )

"""
Delete an item from the DynamoDB table.

Args:
    id (str): The ID of the item to delete.

Returns:
    dict: A dictionary containing the response from the DynamoDB API.
"""
def delete_item(id):
    return dynamo_client.delete_item(
        TableName=table_name,
        Key={
            'id': {
                'S': id
            }
        }
    )
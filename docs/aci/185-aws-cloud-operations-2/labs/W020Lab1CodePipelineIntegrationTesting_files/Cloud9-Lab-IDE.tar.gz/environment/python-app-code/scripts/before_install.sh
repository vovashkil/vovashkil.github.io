echo "before_install.sh"
echo `pwd`
sudo yum update
sudo yum install -y python3 python3-pip nginx
sudo yum remove -y python3-requests
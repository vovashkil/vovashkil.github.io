echo "application_stop.sh"
sudo systemctl stop flaskapp
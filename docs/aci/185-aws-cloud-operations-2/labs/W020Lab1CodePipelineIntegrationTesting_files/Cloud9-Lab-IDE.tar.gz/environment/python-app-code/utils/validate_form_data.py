# utils/validate_form_data.py
import re

def validate_email(email):
    """Validate the format of an email address.

    Args:
        email (str): The email address to validate.

    Returns:
        bool: True if the email address is valid, False otherwise.
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if re.match(pattern, email):
        return True
    return False

def validate_form_inputs(username, email, password):
    """Validate the form inputs for a new user.

    Args:
        username (str): The username entered by the user.
        email (str): The email entered by the user.
        password (str): The password entered by the user.

    Returns:
        list: A list of error messages if any validation errors occur.
    """
    errors = []

    if not username:
        errors.append("Missing username")
    if not email:
        errors.append("Missing email")
    elif not validate_email(email):
        errors.append("Invalid email")
    if not password:
        errors.append("Missing password")

    return errors

import os

from aws_cdk import (
    # Duration,
    Stack,
    # aws_sqs as sqs,
    aws_lambda as lambda_,
    aws_iam as iam,
    aws_apigateway as apigateway
)
from constructs import Construct

class LambdaApiStack(Stack):

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # The code that defines your stack goes here

        # example resource
        # queue = sqs.Queue(
        #     self, "LambdaApiQueue",
        #     visibility_timeout=Duration.seconds(300),
        # )
        
        hello_role = iam.Role.from_role_arn(self, "HelloRole", f"arn:aws:iam::{Stack.of(self).account}:role/HelloLambdaRole")
        
        hello_function = lambda_.Function(self, 'Hello', 
            code= lambda_.Code.from_asset(os.path.join('lambda_api/lambda')),
            handler= 'hello.handler',
            runtime= lambda_.Runtime.PYTHON_3_9,
            role= hello_role,
        );
        
        api = apigateway.LambdaRestApi(self, "myApi", handler = hello_function)

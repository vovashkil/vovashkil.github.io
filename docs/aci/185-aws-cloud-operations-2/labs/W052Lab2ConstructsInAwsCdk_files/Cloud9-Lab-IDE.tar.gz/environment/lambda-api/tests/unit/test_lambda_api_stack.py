from lambda_api.lambda_api_stack import LambdaApiStack

import pytest
from aws_cdk import (
    Stack,
    App,
    assertions,
    aws_lambda as lambda_
)
    
@pytest.fixture
def template():
    app = App()
    stack = LambdaApiStack(app, "lambda-api")
    template = assertions.Template.from_stack(stack)
    return template
    
def test_api_restapi(template):
    template.has_resource("AWS::ApiGateway::RestApi", {})

def test_api_deployment(template):
    template.resource_count_is("AWS::ApiGateway::Deployment", 1)
    
def test_lambda(template):
    template.has_resource_properties(
        "AWS::Lambda::Function",
        {
            "Handler": "hello.handler",
            "Runtime": "python3.9",
        },
    )

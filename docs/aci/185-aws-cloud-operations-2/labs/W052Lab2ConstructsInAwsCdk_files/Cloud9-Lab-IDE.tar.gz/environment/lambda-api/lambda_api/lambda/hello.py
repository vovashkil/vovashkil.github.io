def handler(event, context):
    print("request:", event)
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "text/plain"},
        "body": f"Hello, CDK! You've hit {event['path']}\n",
    }

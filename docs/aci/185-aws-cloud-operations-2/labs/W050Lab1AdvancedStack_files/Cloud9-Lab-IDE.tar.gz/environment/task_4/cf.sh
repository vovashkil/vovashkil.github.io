ACCOUNT_ID=$(aws sts get-caller-identity --output text --query 'Account')

aws s3 sync . s3://templates-$ACCOUNT_ID
aws cloudformation create-change-set  --stack-name "nested-stack" --template-body "file://4_root.yaml" \
    --change-set-name addAppLayer --parameters  \
    ParameterKey="DailyAgendaParameterValue",ParameterValue="Finish Q4 deliverables\\,Week 5 code review\\,Add MFA to production accounts"

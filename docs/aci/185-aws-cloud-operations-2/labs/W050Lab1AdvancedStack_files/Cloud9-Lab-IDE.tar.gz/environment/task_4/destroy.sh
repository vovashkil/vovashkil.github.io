aws cloudformation delete-stack \
    --stack-name "nested-stack"
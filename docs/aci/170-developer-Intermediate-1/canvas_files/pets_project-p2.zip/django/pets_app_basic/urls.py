from django.urls import path
from pets_app import views

urlpatterns = [
    path("pets/", views.listPets, name="petsList"),
    path("pet/<str:pet_id>", views.pet, name="pet"),
]

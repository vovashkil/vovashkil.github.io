from django.contrib import admin
from .models import Breed, VaccinationCard, Pet, VetVisit

# Register your models here.
admin.site.register(Breed)
admin.site.register(VaccinationCard)
admin.site.register(Pet)
admin.site.register(VetVisit)

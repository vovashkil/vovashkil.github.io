---------- DISCLAIMER ---------- 
This files are part of the AWS CLOUD INSTITUTE program, and are
PROVIDED FOR EDUCATIONAL INSTRUCTIONAL PURPOSES ONLY.

---------- CONTENTS ---------- 
This folder includes multiple examples from week 2 of the Developer Intermediate 1 class.

---------- FILE NAMING CONVENTION ---------- 
Please note that many of the examples will have files with names follwing a convention of "<name><number>.xxx", 
where <number> is an index from 1 to n. For example:
- example1.html
- example2.html
- example3.html

Each numbered version represents a further progression of the example. In the instructor led sessions, these changes were
progressively made in a file without a numbered index (such "example.html" for the examples above). The indexed
files are like a checkpoint for each change.

In this naming convention, the latest index version would be the final state for that portion of the demo.
For example, if we have:
- recommended-movies-table1.html
- recommended-movies-table2.html
- recommended-movies-table3.html
The file "recommended-movies-table3.html" would be the final state for this portion of the demos, where we showed 
the use of HTML tables in a movies demo.
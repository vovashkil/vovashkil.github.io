function submitReview() {
    alert("I've submitted your awesome review!")
}

function enteredName(val) {
    alert("Hello " + val + ". Thank you for submitting a review.")
}

function checkRating(val) {
    if (val == 10)
        alert("Wow! That must have been an awesome movie")
}

function dontDoIt() {
    alert("Don't even think about it!\nYou NEVER kill the dog.")
}

function startedReview(review) {
    review.value = "Don't bother entering a review. Did I mention I didn't write a backend yet?"
}

function endedReview(review) {
    review.value = "Didn't I tell you not to bother? Are you hard of hearing?"
}

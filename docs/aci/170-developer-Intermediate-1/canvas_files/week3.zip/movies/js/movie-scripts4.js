// performs any processing require when form is submitted
function submitReview() {
    // if the form was successfully validated, continue with submission
    if (validateForm()) {
        alert("I've submitted your awesome review!")
        return true;
    }
    else
        return false;
}

// validates the input fields on the form
function validateForm() {

    // validate the review
    if (!validateReview()) {
        return false;
    }
    
    // all validations were successful, so return true
    return true;
}

// validates a movie review
const badWords = ["stupid", "jerk", "poop"];
function validateReview() {
    var review = document.getElementById("movie-review").value;
    
    // iterate through bad words, and check if thwey are present in review
    for (var i = 0; i < badWords.length; i++) {
        // check against lower case version of review, to make it case insensitive
        if (review.toLowerCase().includes(badWords[i])) {
            alert("Please refrain from using profanities ("+ badWords[i] + ") in your review");
            return false;
        }
    }
    
    // no bad words found, so return true
    return true;
    
}
function submitReview() {
  alert("I've submitted your awesome review!")
}

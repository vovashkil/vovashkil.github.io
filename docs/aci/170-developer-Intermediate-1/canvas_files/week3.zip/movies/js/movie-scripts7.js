// performs any processing require when form is submitted
function submitReview() {
    // if the form was successfully validated, continue with submission
    if (validateForm()) {
        alert("I've submitted your awesome review!")
        return true;
    }
    else
        return false;
}

// validates the input fields on the form
function validateForm() {

    // validate the review
    if (!validateReview()) {
        return false;
    }

    // all validations were successful, so return true
    return true;
}

// validates a movie review
const badWords = ["stupid", "jerk", "poop"];

function validateReview() {
    var review = document.getElementById("movie-review").value;

    // iterate through bad words, and check if thwey are present in review
    for (var i = 0; i < badWords.length; i++) {
        // check against lower case version of review, to make it case insensitive
        if (review.toLowerCase().includes(badWords[i])) {
            alert("Please refrain from using profanities (" + badWords[i] + ") in your review");
            return false;
        }
    }

    // no bad words found, so return true
    return true;

}

// search for a movie based on prefix
function searchMovie() {
    // retrieve value from movie name field
    let movieSearch = document.getElementById("movie-title").value;
    
    // insert it in selected movie field
    document.getElementById("selected-movie").value = movieSearch
}

// add a movie to watch list
function addMovie() {
    // retrieve value of selected movie
    let selectedMovie = document.getElementById("selected-movie").value

    // remove leading or trainling spaces, and make sure there is a movie value
    selectedMovie = selectedMovie.trim();
    if (selectedMovie == "") {
        // if no movie is selected, return and do nothing
        return
    }
   
    // retrieve watch list table
    let watchList = document.getElementById("watch-list");
    
    // add a row to the watch list table
    let newRow = watchList.insertRow();

    // add td cells for the checkbox and the movie name
    let checkCell = newRow.insertCell(0);
    let movieCell = newRow.insertCell(1);
    
    // set the TD HTML contents of the check cell
    checkCell.outerHTML = '<td class="check-column"><input type="checkbox" onclick="checkMovie(this)"></td>';
    
    // set text inside TD cell with selected movie
    movieCell.innerHTML = selectedMovie;
}

// add a movie to watch list
function checkMovie(checkBox) {
    // retrieve value of the checkbox
    let rowChecked = checkBox.checked;
    
    // get row node of the checkbox in the table (parentNode moves up the hierarchy to get to table row)
    let trNode = checkBox.parentNode.parentNode;
    
    // set row to strikethrough or not, depending on whether checkbox is checked
    if (rowChecked)
        trNode.style.textDecoration = "line-through";
    else
        trNode.style.textDecoration = "none";
}
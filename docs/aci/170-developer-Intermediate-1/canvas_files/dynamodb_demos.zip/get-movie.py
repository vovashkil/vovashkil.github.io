#!/usr/bin/env python
# coding: utf-8

# # <span style="color:blue">DynamoDB Get Item
# AWS CLOUD INSTITUTE: PROVIDED FOR EDUCATIONAL INSTRUCTIONAL PURPOSES ONLY.

# # 1) Import AWS Python SDK (Boto) Package

# In[ ]:


import boto3
from boto3.dynamodb.conditions import Key


# In[ ]:


# import the json module for nicer printing of JSON results
import json


# # 2) Create DynamoDB client object
# The Python SDK supports two clients:
# - The low-level DynamoDB **service client**
# - The higher-level DynamoDB **resource client**
# 
# **For this example I'll be using the low-level service client**, which makes for simpler looking calls.

# In[ ]:


# Creating the DynamoDB Client
ddb = boto3.client('dynamodb')


# ## 3) Use DynamoDB client to perform operations

# ## Retrieve specific items with *get_item*
# A *get-item* operation retrieves a specific item specifying a partition key and and option sort key.
# 
# For this example, we'll be retrieving a movie with this key information:
# - Movie ***year***: 2012
# - Movie ***title***: Silver Linings Playbook

# In[ ]:


# set variables for the filtering criteria
year = 2012
title = "Silver Linings Playbook"

try: 
    # Retrieve a specific item by key
    response = ddb.get_item(
        TableName="MoviesDemo",
        Key={
            'year': {'N': str(year)},
            'title': {'S': title}
        }
    )
    
# catch exceptions
except Exception as e:
    print("Error on get_item: ")
    print(e)


# ### Get data from response object
# Response objects are in JSON format, which in Python will be in a dictionary. We just need to check the format, and extract the data we want from it.

# #### OPTIONAL: Print the complete response object if we want to visualize it
# When we use the low-level service client, the response includes the DynamoDB type indicator. You can see the "N" (Number), "S" (String), "L" (List), and "M" (Map) indicators in the response structure.

# In[ ]:


# Print the complete response object
print("Full response:\n",json.dumps(response, indent=4))


# #### Extract just the data we want

# In[ ]:


# extract the movie title, year, and plot from the response object
title = response['Item']['title']['S']
year = response['Item']['year']['N']
plot = response['Item']['info']['M']['plot']['S']
rating = response['Item']['info']['M']['rating']['N']
print(f'Movie: {title}\nYear: {year}\nPlot: {plot}\nRating: {rating}\n\n')


# ## OPTIONAL> Repeat the operation with a resource client and *get_item*

# ### Create DynamoDB resource client object

# In[ ]:


# Creating the DynamoDB Client
ddb = boto3.resource('dynamodb')


# ### Get table resource

# In[ ]:


try:
    # get a reference to the movies_table
    movies_table = ddb.Table('MoviesDemo')
# catch exceptions
except Exception as e:
    print("Error obtaining resource: ", e)


# ### Retrieve the same information with the *get_item* on the resource client

# In[ ]:


# set variables for the filtering criteria
year = 2012
title = "Silver Linings Playbook"

try:        
    # query table
    response = movies_table.get_item(
        Key={
            'year': year,
            'title': title
        }
    )
    
# catch exceptions
except Exception as e:
    print("Error on get_item: ")
    print(e)


# ### Get data from response object
# Response objects are in JSON format, which in Python will be in a dictionary. We just need to check the format, and extract the data we want from it.

# #### OPTIONAL: Print the complete response object if we want to visualize it
# When we use the low-level service client, the response includes the DynamoDB type indicator. You can see the "N" (Number), "S" (String), "L" (List), and "M" (Map) indicators in the response structure.

# In[ ]:


# Print the complete response object
print("Full response:\n",json.dumps(response, default=str, indent=4))


# #### Extract just the data we want

# In[ ]:


# extract the movie from the response
item = response["Item"]

# extract the movie title, year, and plot from the response object
title = item["title"]
year = item["year"]
plot = item["info"]["plot"]
rating = item["info"]["rating"]
print(f'Movie: {title}\nYear: {year}\nPlot: {plot}\nRating: {rating}\n\n')


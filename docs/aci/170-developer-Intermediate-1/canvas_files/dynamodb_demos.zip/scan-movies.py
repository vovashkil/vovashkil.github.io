#!/usr/bin/env python
# coding: utf-8

# # <span style="color:blue">DynamoDB Scan
# AWS CLOUD INSTITUTE: PROVIDED FOR EDUCATIONAL INSTRUCTIONAL PURPOSES ONLY.

# # 1) Import AWS Python SDK (Boto) Package

# In[ ]:


import boto3
from boto3.dynamodb.conditions import Key, Attr


# # 2) Create DynamoDB client object
# The Python SDK supports two clients:
# - The low level DynamoDB **service client**
# - The higher level DynamoDB **resource client**
# 
# **For this example I'll be using the resource client**, which makes for simpler looking calls.

# In[ ]:


# Creating the DynamoDB Client
ddb = boto3.resource('dynamodb')


# ## 3) Use DynamoDB client to perform operations

# ### Get table resource
# The resource client follows an object-oriented style. So here I use the resource client to get an object that maps to the table specified. I will subsequently make calls on that object.

# In[ ]:


try:
    # get a reference to the movies_table
    movies_table = ddb.Table('MoviesDemo')
# catch exceptions
except Exception as e:
    print("Error obtaining resource: ", e)


# ## Retrieve items with *scan*
# A *scan* operation retrieves items based on filtering criteria on any field.
# 
# For this example, I'll be filtering on the following:
# - Movie ***rating*** greater than or equal to 8

# In[ ]:


# set variables for the filtering criteria
min_rating = 8

try:        
    # scan table
    response = movies_table.scan(
        # Use FilterExpression to specify the filtering criteria
        FilterExpression = (
            # compare rating in the info map
            Attr('info.rating').gte(min_rating)
        )
    )
    
# catch exceptions
except Exception as e:
    print("Error on scan: ")
    print(e)


# ### Get data from response object
# Response objects are in JSON format, which in Python will be in a dictionary. We just need to check the format, and extract the data we want from it.

# #### OPTIONAL: Print the complete response object if we want to visualize it

# In[ ]:


print("Full response:\n",response)


# #### Extract just the data we want

# In[ ]:


# iterate through each movie item, and print a summary for each
for item in response["Items"]:
    # extract the movie title, year, and plot from the response item
    title = item["title"]
    year = item["year"]
    plot = item["info"]["plot"]
    rating = item["info"]["rating"]
    print(f'Movie: {title}\nYear: {year}\nPlot: {plot}\nRating: {rating}\n\n')


# In[ ]:





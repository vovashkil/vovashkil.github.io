#!/usr/bin/env python
# coding: utf-8

# # <span style="color:blue">DynamoDB Update
# AWS CLOUD INSTITUTE: PROVIDED FOR EDUCATIONAL INSTRUCTIONAL PURPOSES ONLY.

# # 1) Import AWS Python SDK (Boto) Package

# In[ ]:


import boto3
from boto3.dynamodb.conditions import Key


# In[ ]:


# additional libraries
from decimal import Decimal


# # 2) Create DynamoDB client object
# The Python SDK supports two clients:
# - The low level DynamoDB **service client**
# - The higher level DynamoDB **resource client**
# 
# **For this example I'll be using the resource client**, which makes for simpler looking calls.

# In[ ]:


# Creating the DynamoDB Client
ddb = boto3.resource('dynamodb')


# ## 3) Use DynamoDB client to perform operations

# ### Get table resource
# The resource client follows an object-oriented style. So here I use the resource client to get an object that maps to the table specified. I will subsequently make calls on that object.

# In[ ]:


try:
    # get a reference to the movies_table
    movies_table = ddb.Table('MoviesDemo')
# catch exceptions
except Exception as e:
    print("Error obtaining resource: ", e)


# ## Update items with *update-item*
# A *query* operation Updates an existing item in a DynamoDB table. The item to be updated is selected using the primary key (partition key and optionally sort key).
# 
# For this example, I'll be updating the rating of the movie "Silver Linings Playbook".

# In[ ]:


# set variables for the filtering criteria
year = 2012
title = "Silver Linings Playbook"
new_rating = "8.8"

try:        
    # update table
    response = movies_table.update_item(
        # Specify the key for the item to update
        Key={"year": year, "title": title},
        
        # Use UpdateExpression to specify fields to update
        # The value with a ":" is a placeholder
        UpdateExpression="set info.rating=:new_rating",
        ExpressionAttributeValues={":new_rating": Decimal(new_rating)},
        ReturnValues="UPDATED_NEW",
    )
    
# catch exceptions
except Exception as e:
    print("Error on update-item: ")
    print(e)


# ### Get data from response object
# Response objects are in JSON format, which in Python will be in a dictionary. We just need to check the format, and extract the data we want from it.
# 
# In the case of a update operation, we don't necessarily need to look at the response, but since if we specified a "ReturnValue=UPDATED_NEW"", the updated attributes get returned.

# In[ ]:


print("Full response:\n",response)


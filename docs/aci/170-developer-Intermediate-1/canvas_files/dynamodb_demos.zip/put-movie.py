#!/usr/bin/env python
# coding: utf-8

# # <span style="color:blue">DynamoDB Put
# AWS CLOUD INSTITUTE: PROVIDED FOR EDUCATIONAL INSTRUCTIONAL PURPOSES ONLY.

# # 1) Import AWS Python SDK (Boto) Package

# In[ ]:


import boto3


# In[ ]:


# additional libraries
from decimal import Decimal


# # 2) Create DynamoDB client object
# The Python SDK supports two clients:
# - The low level DynamoDB **service client**
# - The higher level DynamoDB **resource client**
# 
# Clients perform the same, and the choice is a matter of style and use case.
# 
# **For this example I'll be using the Resource Client**, because it makes a little easier to insert JSON structures, since you can operate with the plain JSON structure, without having to specify data types.

# In[ ]:


# Creating the DynamoDB Client
ddb = boto3.resource('dynamodb')


# # 3) Use client to perform operations

# ## Insert an item with *put*

# ### Get table resource
# The resource client follows an object-oriented style. So here I use the resource client to get an object that maps to the table specified. I will subsequently make calls on that object.

# In[ ]:


try:
    # get a reference to the movies_table
    movies_table = ddb.Table('MoviesDemo')
# catch exceptions
except Exception as e:
    print("Error obtaining resource: ", e)


# ### Set data to insert
# Here we set the movie we'll be adding. Because I'm using the resource client, I can use plain JSON data, which is assigned to a Python dictionary. 
# 
# I could also use the service client, but then I would have to use the DynamoDB specific format, which includes a data type indicator for each field.

# In[ ]:


movie_item = {
    "year": 2013,
    "title": "Rush",
    "info": {
        "directors": ["Ron Howard"],
        "release_date": "2013-09-02T00:00:00Z",
        "rating": Decimal("8.3"),
        "genres": [
            "Action",
            "Biography",
            "Drama",
            "Sport"
        ],
        "image_url": "http://ia.media-imdb.com/images/M/MV5BMTQyMDE0MTY0OV5BMl5BanBnXkFtZTcwMjI2OTI0OQ@@._V1_SX400_.jpg",
        "plot": "A re-creation of the merciless 1970s rivalry between Formula One rivals James Hunt and Niki Lauda.",
        "rank": 2,
        "running_time_secs": 7380,
        "actors": [
            "Daniel Bruhl",
            "Chris Hemsworth",
            "Olivia Wilde"
        ]
    }
}


# ### Insert item
# Now we use the table object to insert the new item. 
# 
# Note that it's always important to check for errors, using a standard try/exception block.

# In[ ]:


try:
    # insert movie and get a response object
    response = movies_table.put_item(Item=movie_item)

    # if we got here, then we had not exceptions, and the item was successfully added
    print(f'Successfully inserted "{movie_item["title"]}"')

# catch exceptions
except Exception as e:
    print("Error on put-item: ")
    print(e)


# ### Get data from response object
# Response objects are in JSON format, which in Python will be in a dictionary. We just need to check the format, and extract the data we want from it.
# 
# In the case of a **put operation**, we are **not expecting any application data back**, so we wouldn't necessarily need to check it.

# In[ ]:


print("Response: ", response)


# ## Insert additional items
# The DynamoDB SDK supports methods for writing multiple items as a batch for information on that you can view the documentation on [batch_writer]( https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/dynamodb/table/batch_writer.html).
# 
# For this example, to keep things simpler, we'll just use a regular Python for loop, and insert 10 movies one at a time.

# ### Set data to insert
# We are populating 11 movies, using a list with one item for each movie.

# In[ ]:


movie_list = [
	{
        "year": 2013,
        "title": "Thor: The Dark World",
        "info": {
            "directors": ["Alan Taylor"],
            "release_date": "2013-10-30T00:00:00Z",
            "rating": Decimal("6.7"),
            "genres": [
                "Action",
                "Adventure",
                "Fantasy"
            ],
            "image_url": "http://ia.media-imdb.com/images/M/MV5BMTQyNzAwOTUxOF5BMl5BanBnXkFtZTcwMTE0OTc5OQ@@._V1_SX400_.jpg",
            "plot": "Faced with an enemy that even Odin and Asgard cannot withstand, Thor must embark on his most perilous and personal journey yet, one that will reunite him with Jane Foster and force him to sacrifice everything to save us all.",
            "rank": 5,
            "actors": [
                "Chris Hemsworth",
                "Natalie Portman",
                "Tom Hiddleston"
            ]
        }
    },
    {
        "year": 2013,
        "title": "World War Z",
        "info": {
            "directors": ["Marc Forster"],
            "release_date": "2013-06-02T00:00:00Z",
            "rating": Decimal("7.1"),
            "genres": [
                "Action",
                "Adventure",
                "Horror",
                "Sci-Fi",
                "Thriller"
            ],
            "image_url": "http://ia.media-imdb.com/images/M/MV5BMTg0NTgxMjIxOF5BMl5BanBnXkFtZTcwMDM0MDY1OQ@@._V1_SX400_.jpg",
            "plot": "United Nations employee Gerry Lane traverses the world in a race against time to stop the Zombie pandemic that is toppling armies and governments, and threatening to destroy humanity itself.",
            "rank": 8,
            "running_time_secs": 6960,
            "actors": [
                "Brad Pitt",
                "Mireille Enos",
                "Daniella Kertesz"
            ]
        }
    },
    {
        "year": 2012,
        "title": "The Avengers",
        "info": {
            "directors": ["Joss Whedon"],
            "release_date": "2012-04-11T00:00:00Z",
            "rating": Decimal("8.2"),
            "genres": [
                "Action",
                "Fantasy"
            ],
            "image_url": "http://ia.media-imdb.com/images/M/MV5BMTk2NTI1MTU4N15BMl5BanBnXkFtZTcwODg0OTY0Nw@@._V1_SX400_.jpg",
            "plot": "Nick Fury of S.H.I.E.L.D. assembles a team of superhumans to save the planet from Loki and his army.",
            "rank": 48,
            "running_time_secs": 8580,
            "actors": [
                "Robert Downey Jr.",
                "Chris Evans",
                "Scarlett Johansson"
            ]
        }
    },
    {
        "year": 2012,
        "title": "Silver Linings Playbook",
        "info": {
            "directors": ["David O. Russell"],
            "release_date": "2012-09-08T00:00:00Z",
            "rating": Decimal("7.9"),
            "genres": [
                "Comedy",
                "Drama",
                "Romance"
            ],
            "image_url": "http://ia.media-imdb.com/images/M/MV5BMTM2MTI5NzA3MF5BMl5BanBnXkFtZTcwODExNTc0OA@@._V1_SX400_.jpg",
            "plot": "After a stint in a mental institution, former teacher Pat Solitano moves back in with his parents and tries to reconcile with his ex-wife. Things get more challenging when Pat meets Tiffany, a mysterious girl with problems of her own.",
            "rank": 78,
            "running_time_secs": 7320,
            "actors": [
                "Bradley Cooper",
                "Jennifer Lawrence",
                "Robert De Niro"
            ]
        }
    },
    {
        "year": 1997,
        "title": "Titanic",
        "info": {
            "directors": ["James Cameron"],
            "release_date": "1997-11-01T00:00:00Z",
            "rating": Decimal("7.6"),
            "genres": [
                "Drama",
                "Romance"
            ],
            "image_url": "http://ia.media-imdb.com/images/M/MV5BMjExNzM0NDM0N15BMl5BanBnXkFtZTcwMzkxOTUwNw@@._V1_SX400_.jpg",
            "plot": "A seventeen-year-old aristocrat, expecting to be married to a rich claimant by her mother, falls in love with a kind but poor artist aboard the luxurious, ill-fated R.M.S. Titanic.",
            "rank": 111,
            "running_time_secs": 11640,
            "actors": [
                "Leonardo DiCaprio",
                "Kate Winslet",
                "Billy Zane"
            ]
        }
    },
    {
        "year": 2004,
        "title": "The Incredibles",
        "info": {
            "directors": ["Brad Bird"],
            "release_date": "2004-10-27T00:00:00Z",
            "rating": Decimal("8"),
            "genres": [
                "Animation",
                "Action",
                "Adventure",
                "Family"
            ],
            "image_url": "http://ia.media-imdb.com/images/M/MV5BMTY5OTU0OTc2NV5BMl5BanBnXkFtZTcwMzU4MDcyMQ@@._V1_SX400_.jpg",
            "plot": "A family of undercover superheroes, while trying to live the quiet suburban life, are forced into action to save the world.",
            "rank": 112,
            "running_time_secs": 6900,
            "actors": [
                "Craig T. Nelson",
                "Samuel L. Jackson",
                "Holly Hunter"
            ]
        }
    },
    {
        "year": 2010,
        "title": "Inception",
        "info": {
            "directors": ["Christopher Nolan"],
            "release_date": "2010-07-08T00:00:00Z",
            "rating": Decimal("8.8"),
            "genres": [
                "Action",
                "Adventure",
                "Mystery",
                "Sci-Fi",
                "Thriller"
            ],
            "image_url": "http://ia.media-imdb.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_SX400_.jpg",
            "plot": "A skilled extractor is offered a chance to regain his old life as payment for a task considered to be impossible.",
            "rank": 121,
            "running_time_secs": 8880,
            "actors": [
                "Leonardo DiCaprio",
                "Joseph Gordon-Levitt",
                "Ellen Page"
            ]
        }
    },
    {
        "year": 1972,
        "title": "The Godfather",
        "info": {
            "directors": ["Francis Ford Coppola"],
            "release_date": "1972-03-15T00:00:00Z",
            "rating": Decimal("9.2"),
            "genres": [
                "Crime",
                "Drama"
            ],
            "image_url": "http://ia.media-imdb.com/images/M/MV5BMjEyMjcyNDI4MF5BMl5BanBnXkFtZTcwMDA5Mzg3OA@@._V1_SX400_.jpg",
            "plot": "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.",
            "rank": 143,
            "running_time_secs": 10500,
            "actors": [
                "Marlon Brando",
                "Al Pacino",
                "James Caan"
            ]
        }
    },
    {
        "year": 1999,
        "title": "For Love of the Game",
        "info": {
            "directors": ["Sam Raimi"],
            "release_date": "1999-09-15T00:00:00Z",
            "rating": Decimal("6.3"),
            "genres": [
                "Drama",
                "Romance",
                "Sport"
            ],
            "image_url": "https://m.media-amazon.com/images/M/MV5BZDgzY2NkMTgtODQwZC00MWEzLWFlZjQtZTcxOTc3NzU1MDVhXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_FMjpg_UX1000_.jpg",
            "plot": "A washed up pitcher flashes through his career.",
            "rank": 4987,
            "running_time_secs": 8220,
            "actors": [
                "Kevin Costner",
                "Kelly Preston",
                "John C. Reilly"
            ]
        }
    },
    {
        "year": 2019,
        "title": "Star Wars - The Rise of Skywalker",
        "info": {
            "directors": ["J.J. Abrams"],
            "release_date": "2019-05-25T00:00:00Z",
            "rating": Decimal("6.5"),
            "genres": [
                "Action",
                "Adventure",
                "Fantasy",
                "Sci-Fi"
            ],
            "image_url": "https://m.media-amazon.com/images/M/MV5BMDljNTQ5ODItZmQwMy00M2ExLTljOTQtZTVjNGE2NTg0NGIxXkEyXkFqcGdeQXVyODkzNTgxMDg@._V1_FMjpg_UX1000_.jpg",
            "plot": "In the riveting conclusion of the landmark Skywalker saga, new legends will be born-and the final battle for freedom is yet to come.",
            "rank": 226,
            "running_time_secs": 7260,
            "actors": [
                "Daisy Ridley",
                "Mark Hamill",
                "Adam Driver",
                "John Boyega",
                "Oscar Isaac"
            ]
        }
    },
    {
        "year": 1977,
        "title": "Star Wars",
        "info": {
            "directors": ["George Lucas"],
            "release_date": "1977-05-25T00:00:00Z",
            "rating": Decimal("8.7"),
            "genres": [
                "Action",
                "Adventure",
                "Fantasy",
                "Sci-Fi"
            ],
            "image_url": "http://ia.media-imdb.com/images/M/MV5BMTU4NTczODkwM15BMl5BanBnXkFtZTcwMzEyMTIyMw@@._V1_SX400_.jpg",
            "plot": "Luke Skywalker joins forces with a Jedi Knight, a cocky pilot, a wookiee and two droids to save the universe from the Empire's world-destroying battle-station, while also attempting to rescue Princess Leia from the evil Darth Vader.",
            "rank": 226,
            "running_time_secs": 7260,
            "actors": [
                "Mark Hamill",
                "Harrison Ford",
                "Carrie Fisher"
            ]
        }
    }
]


# ### Insert items
# Note that we can continue to use the same *movies_table* object for additional operations on the same table.

# In[ ]:


try:
    # iterate through each movie on the list
    for movie_item in movie_list:
        # insert movie and get a response object
        response = movies_table.put_item(Item=movie_item)
    
        # if we got here, then we had not exceptions, and the item was successfully added
        print(f'Successfully inserted "{movie_item["title"]}"')

# catch exceptions
except Exception as e:
    print("Error on put-item: ")
    print(e)


#!/usr/bin/env python
# coding: utf-8

# # <span style="color:blue">DynamoDB Delete
# AWS CLOUD INSTITUTE: PROVIDED FOR EDUCATIONAL INSTRUCTIONAL PURPOSES ONLY.

# # 1) Import AWS Python SDK (Boto) Package

# In[ ]:


import boto3
from boto3.dynamodb.conditions import Key


# # 2) Create DynamoDB client object
# The Python SDK supports two clients:
# - The low-level DynamoDB **service client**
# - The higher-level DynamoDB **resource client**
# 
# **For this example I'll be using the low-level service client**, which makes for simpler looking calls.

# In[ ]:


# Creating the DynamoDB Client
ddb = boto3.client('dynamodb')


# ## 3) Use DynamoDB client to perform operations

# ## Delete specific items with *get*
# A *delete_item* operation deletes a specific item specifying a partition key and and option sort key.
# 
# For this example, we'll be deleting the movie with this key information:
# - Movie ***year***: 2012
# - Movie ***title***: The Avengers

# In[ ]:


# set variables for the filtering criteria
year = 2012
title = "The Avengers"

try: 
    # Delete a specific item by key
    response = ddb.delete_item(
        TableName="MoviesDemo",
        Key={
            'year': {'N': str(year)},
            'title': {'S': title}
        }
    )
    
# catch exceptions
except Exception as e:
    print("Error on delete_item: ")
    print(e)


# ### Get data from response object
# Response objects are in JSON format, which in Python will be in a dictionary. We just need to check the format, and extract the data we want from it.
# 
# In the case of a delete operation, we don't necessarily need to look at the response, unless we had specified a ReturnValues attribute in the operation.

# In[ ]:


print("Full response:\n",response)


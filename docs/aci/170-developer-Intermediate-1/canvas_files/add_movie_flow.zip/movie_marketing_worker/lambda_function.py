import boto3
import json

# get client object for SNS
sns = boto3.client('sns')

# define ARN for new movie topic
sns_topic = 'arn:aws:sns:us-east-2:359520436611:movie-campaign-ready'

# message template
message_template = "The marketing campaign for the movie {} is ready."

def lambda_handler(event, context):
    # write event to log
    print(event)

    # a single event may contain multiple movies, so iterate through records
    for record in event['Records']:
        # extract message from event
        message_body = record['body']
        movie_key = json.loads(message_body)
        print("Message data: ", movie_key)

        # here is the place where we would do whatever marketing work is needed
        print(f'Marketing movie: {movie_key["title"]} ({movie_key["year"]})')

        # after marketting tasks are completed, publish to SNS
        notify_marketing(movie_key)


def notify_marketing(movie_key):
    # create message for SNS
    message = message_template.format(movie_key["title"])

    # write message to log
    print("Publishing message: ", message)

    # publish message to SNS topic
    response = sns.publish(
        TopicArn = sns_topic,
        Message = json.dumps(message),
        Subject = 'Marketing campaign ready'
    )
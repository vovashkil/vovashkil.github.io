import boto3
import json

# get client object for SNS
sns = boto3.client('sns')

# define ARN for new movie topic
sns_topic = 'arn:aws:sns:us-east-2:359520436611:movie-test-result'

# bad movie titles (this is just for testing)
bad_titles = ["Star Wars - The Rise of Skywalker"]
failed_message = "Could not stream movie"
success_message = "Movie streaming successful"

def lambda_handler(event, context):
    # write event to log
    print(event)

    # a single event may contain multiple movies, so iterate through records
    for record in event['Records']:
        # extract message from event
        message_body = record['body']
        movie_key = json.loads(message_body)
        print("Message data: ", movie_key)

        # here is the place where we would test the movie title and year
        print(f'Testing movie: {movie_key["title"]} ({movie_key["year"]})')

        # in this simulated test, we will consider a failed test based on the title
        if movie_key["title"] in bad_titles:
            # if movie failed test, notify SNS topic
            notify_test_result(movie_key, False, failed_message)
        else:
            # if movie passed test, notify SNS topic
            notify_test_result(movie_key, True, success_message)


def notify_test_result(movie_key, test_result, result_message):
    # create message for SNS
    messageJSON = {
        "title": movie_key["title"],
        "year": movie_key["year"],
        "test_result": test_result,
        "message": result_message
    }

    # write message to log
    print("Publishing message: ", messageJSON)

    # publish message to SNS topic
    response = sns.publish(
        TopicArn = sns_topic,
        Message = json.dumps(messageJSON),
        Subject = 'Movie tested'
    )
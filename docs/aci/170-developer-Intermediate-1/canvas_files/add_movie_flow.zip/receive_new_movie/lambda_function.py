import boto3
import json

# get client object for SNS
sns = boto3.client('sns')

# define ARN for new movie topic
sns_topic = 'arn:aws:sns:us-east-2:359520436611:movie-added'

def lambda_handler(event, context):
    # write event to log
    print(event)

    # a single event may contain multiple movies, so iterate through records
    for record in event['Records']:
        # Verify that the event is a new movie
        if record['eventName'] != 'INSERT':
            print('Not a new movie, so do nothing')
        else:
            # notify subscribers that a movie has been added
            notify_new_movie(record)

def notify_new_movie(record):
    # create message for SNS
    messageJSON = {
        "title": record['dynamodb']['NewImage']['title']['S'], 
        "year": record['dynamodb']['NewImage']['year']['N'],
    }
    # write message to log
    print("Publishing message: ", messageJSON)

    # publish message to SNS topic
    response = sns.publish(
        TopicArn = sns_topic,
        Message = json.dumps(messageJSON),
        Subject = 'New Movie Added'
    )
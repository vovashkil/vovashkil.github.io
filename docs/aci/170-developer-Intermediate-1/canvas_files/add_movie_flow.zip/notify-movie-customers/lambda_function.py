import boto3
import json

# get client object for SNS
sns = boto3.client('sns')

# define ARN for new movie topic
sns_topic = 'arn:aws:sns:us-east-2:359520436611:notify-movie'

# message template
message_template = 'We have just added a great new movie to our library. \
{} is now available to stream at Tucker Movies Emporium'

def lambda_handler(event, context):
    # write event to log
    print(event)

    # a single event may contain multiple movies, so iterate through records
    for record in event['Records']:
        # extract message from event record
        sns_message = record['Sns']
        message_body = sns_message['Message']
        print(f'Message received: {message_body}')

        # retrieve movie title from SNS message
        movie_key = json.loads(record["Sns"]["Message"])
        print(f'Processing movie: {movie_key["title"]} ({movie_key["year"]})')

        # send movie to SQS queue to be tested
        notify_movie_customers(movie_key)


def notify_movie_customers(movie_key):
    # create message for SNS
    message = message_template.format(movie_key["title"])

    # write message to log
    print("Publishing message: ", message)

    # publish message to SNS topic
    response = sns.publish(
        TopicArn = sns_topic,
        Message = json.dumps(message),
        Subject = 'Great new movie coming your way!'
    )
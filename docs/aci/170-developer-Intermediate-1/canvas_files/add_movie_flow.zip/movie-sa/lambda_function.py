import boto3
import json

# get client object for SQS
sqs = boto3.client('sqs')

# define ARN for new movie topic
queue_url = "https://sqs.us-east-2.amazonaws.com/359520436611/new-movie-test"

def lambda_handler(event, context):
    # write event to log
    print(event)

    # a single event may contain multiple movies, so iterate through records
    for record in event['Records']:
        # extract message from event record
        sns_message = record['Sns']
        message_body = sns_message['Message']
        print(f'Message received: {message_body}')

        # retrieve movie title from SNS message
        movie_key = json.loads(record["Sns"]["Message"])
        print(f'Processing movie: {movie_key["title"]} ({movie_key["year"]})')

        # send movie to SQS queue to be tested
        send_movie_to_test(movie_key)

def send_movie_to_test(movie_key):
    # prepare message for test
    message = json.dumps(movie_key)

    # send message to SQS queue
    response = sqs.send_message(
        QueueUrl = queue_url,
        MessageBody = message
    )

    print('Sent message to test: ', message)

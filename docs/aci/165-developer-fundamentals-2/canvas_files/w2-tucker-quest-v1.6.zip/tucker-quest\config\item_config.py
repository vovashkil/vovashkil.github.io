'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

'''
This file has configurations to define types for items
'''
from attack_item import AttackItem
from defense_item import DefenseItem
from treasure import Treasure
from sword import Sword
from spell import Spell
from armor import Armor
from protection_spell import ProtectionSpell
from key import Key
from potion import Potion
from holy_water import HolyWater

from game_types_config import ItemType


# this maps a character type with the factory method that can create it from a JSON based dictionary
item_from_dict_map = {
    ItemType.GENERAL_ATTACK_ITEM: AttackItem.from_dict,
    ItemType.GENERAL_DEFENSE_ITEM: DefenseItem.from_dict,
    ItemType.TREASURE_ITEM: Treasure.from_dict,
    ItemType.SWORD_ITEM: Sword.from_dict,
    ItemType.SPELL_ITEM: Spell.from_dict,
    ItemType.ARMOR_ITEM: Armor.from_dict,
    ItemType.PROTECTION_SPELL_ITEM: ProtectionSpell.from_dict,
    ItemType.KEY_ITEM: Key.from_dict,
    ItemType.POTION_ITEM: Potion.from_dict,
    ItemType.HOLY_WATER_ITEM: HolyWater.from_dict
}

# This method can create a specific item type from a dictionary
# It will leverage the specific item type from_dict static function, defined in the map above
def item_from_dict(item_dict):

    # get item type from item dictionary, and make sure it exists
    item_type = item_dict.get("type")
    if (item_type is None):
        return None
    
    # get reference to the from_dict function for this item type
    obj_from_dict = item_from_dict_map[item_type]

    # create and return appropriate object from dictionary
    return obj_from_dict(item_dict)

# These are the ids for the default attack and defense item when a fighter has none
DEFAULT_ATTACK_ITEM = "d0001"
DEFAULT_DEFENSE_ITEM = "d0002"
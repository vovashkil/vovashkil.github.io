'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

from enemy import Enemy
import json
from game_types_config import NPCType


class HumanEnemy(Enemy):
    def __init__(self, id=None, name=None, pronoun = None, status=None, description=None,
                 level=None, max_health=None, attack_item_id=None, defense_item_id=None, inventory = None, message=None):

        # initialize the Enemy elements
        Enemy.__init__(self, name=name, pronoun = pronoun, status=status, description=description, id=id,
                       level=level, max_health=max_health, attack_item_id = attack_item_id, defense_item_id = defense_item_id,
                       inventory = inventory, message=message)

        # initialize character type
        self.type = NPCType.HUMAN_ENEMY

    # create an object from a dictionary
    @staticmethod
    def from_dict(char_dict):
        return HumanEnemy(id=char_dict["id"], name=char_dict["name"], pronoun=char_dict["pronoun"], status=char_dict["status"],
                          description=char_dict["description"], level=char_dict["level"],
                          max_health=char_dict["max_health"], inventory = char_dict["inventory"], message=char_dict["message"],
                          attack_item_id=char_dict["attack_item_id"], defense_item_id=char_dict["defense_item_id"])

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

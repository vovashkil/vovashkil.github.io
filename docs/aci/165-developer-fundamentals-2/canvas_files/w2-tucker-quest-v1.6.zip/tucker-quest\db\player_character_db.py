'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
import json
from tucker_db import TuckerDB
import player_character_config as pcc
from game_exception import GameException
from player_character_config import player_from_dict

class PlayerCharacterDB():
    # define variables for PlayerCharacterDB database
    TABLE_NAME = "player_characters"

    # make the TuckerDB instance a class variable, so we only have one connection
    tucker_db = None

    def __init__(self):
        logging.debug(">>> PlayerCharacterDB.__init__()")
        # initalizar TuckerDB instance, if not already done
        if (PlayerCharacterDB.tucker_db is None):
            PlayerCharacterDB.tucker_db = TuckerDB(PlayerCharacterDB.TABLE_NAME)

    # get an item by id
    def get(self, id):
        logging.debug(f">>> PlayerCharacterDB.get_item({id})")

        # get item dictionary from PlayerCharacterDB database
        char_dict = PlayerCharacterDB.tucker_db.get(id)

        # if item cannot be found, return None
        if (char_dict is None):
            logging.info(f"PlayerCharacterDB.get> Could not find character: {id}")
            return None

        logging.debug(f"PlayerCharacterDB.get> Read character from DB: ({char_dict})")

        # use utility function in non_player_character_config to build the correct object of the specific item type
        char_obj =  player_from_dict(char_dict)
        logging.debug(f"ItemDB.get> Created object from dictionary: {char_obj}")

        # return the object
        return char_obj

        
    # save player chracter to database
    def save(self, player):
        logging.debug(f">>> PlayerCharacterDB.save({player.id},{player})")

        # save player with  id as the key
        PlayerCharacterDB.tucker_db.add(player.id, json.loads(str(player))) 


'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
from enemy import Enemy
import json
from game_types_config import NPCType,ItemType
from attack_item import AttackItem

class Undead(Enemy):
    DEFAULT_ATTACK_DRAIN = 10

    def __init__(self, id = None, name = None, pronoun = None, status = None, description = None,
                 level = None, max_health = None, attack_item_id = None, defense_item_id = None, inventory = None, message = None,
                 attack_drain = None):
        # initialize the Enemy elements
        Enemy.__init__(self, name = name, pronoun = pronoun, status = status, description = description, id = id,
                       level = level, max_health = max_health, attack_item_id = attack_item_id, defense_item_id = defense_item_id,
                       inventory = inventory, message = message)

        # initialize character type
        self.type = NPCType.UNDEAD

        # initialize the Undead elements
        self.attack_drain = attack_drain if attack_drain else Undead.DEFAULT_ATTACK_DRAIN

        # since some display items will expect an actual item object with a name, create a dummy one
        self.attack_item = AttackItem(id="drain", name="Health drain",
                                      description=f"drains openent health by {self.attack_drain}%")
        self.attack_item.type = ItemType.GENERAL_ATTACK_ITEM
        
    # Undeads override the standard equip method, since they have their own "built-in" health drain attack
    def equip_attack_item(self):
        logging.debug(">>>Undead.equip_attack_item()")
        return

    # Undead characters have a different kind of attack. They drain the energy of the oponent by a percentage each time
    def attack(self, opponent):
        logging.debug(">>> Undead.attack()")
        logging.debug(f"Undead.attack> {self.id} attacks {opponent.id} with health {opponent.health}")    

        # calculate the drain percentage (use default if none was set)
        drain_percentage = self.attack_drain/100 if self.attack_drain else Undead.DEFAULT_ATTACK_DRAIN/100

        # get attack power for this fighter based on a percentage of the oponents health, rounded to an integer
        attack_power = int(opponent.health * drain_percentage)

        # invoke enemy's defense function to determine damage
        defense_power = opponent.defense(attack_power)
        logging.debug(f"Undead.attack> attack power: {attack_power}, defense power: {defense_power}")

        # calculate damage of this attack (if defense is greater than attack, set damage to 0)
        damage =  (attack_power - defense_power) if (defense_power < attack_power) else 0

        # reduce openents health by the damage
        opponent.decrease_health(damage)
        logging.debug(f"Undead.attack> Damage applied: {damage}, Opponent health: {opponent.health}")

        # return tuple to indicate result of the attack
        return (attack_power, defense_power, damage)

    # create an object from a dictionary
    @staticmethod
    def from_dict(char_dict):
        return Undead(id=char_dict["id"], name=char_dict["name"], pronoun=char_dict["pronoun"], status=char_dict["status"],
                       description=char_dict["description"], level=char_dict["level"],
                       max_health=char_dict["max_health"], inventory = char_dict["inventory"], message=char_dict["message"], 
                       attack_item_id=char_dict["attack_item_id"], defense_item_id=char_dict["defense_item_id"])
    
    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging

class NonPlayerCharacter():
    def __init__(self, id = None, name = None, pronoun = None, status = None, description = None, message = None, inventory = None):

        self.id = id
        self.name = name
        self.pronoun = pronoun
        self.status = status
        self.description = description
        self.message = message
        self.inventory = inventory


        # initialize values set later
        self.type = None


    # This is a place-holder method for any special actions that an NPC performs when it first meets the player
    # This method will be invoked in NPC encounter type scenes. It can be left as is, but if we want to a specialized
    # behavior for certain NPC types, we can override this method.
    def pre_action(self):
        logging.debug("NonPlayerCharacter.pre_action> no pre-action implemented for this NPC")
        return None

    # this is a place-holder method for any special actions that an NPC performs at the end of a player encounter.
    # This method will be invoked in NPC encounter type scenes. It can be left as is, but if we want to a specialized
    # behavior for certain NPC types, we can override this method.
    def post_action(self):
        logging.debug("NonPlayerCharacter.post_action> no post_action implemented for this NPC")
        return None

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)
    
    # define equality based on id
    def __eq__(self, other):
        return self.id == other.id

'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import sys

# append directories for modules to be imported
sys.path.append('db')
sys.path.append('config')
sys.path.append('item')
sys.path.append('character')
sys.path.append('ui')
sys.path.append('scene')
sys.path.append('world')

import logging
import os, getopt
from datetime import datetime
from game_controller import GameController
from battle_scene import BattleScene

# default log file name
DEFAULT_LOGFILE = "tucker_quest.log"
DEFAULT_LOGFOLDER = "logs"

# battle stats file
BATTLE_STATS_FILE = "battle_stats.csv"

# default log level based on (10=DEBUG, 20=INFO, 30=WARNING, 40=ERROR, 50=CRITICAL)
DEFAULT_LOGLEVEL = 20

# setup application logging
def setup_logging(log_level):
    # if a log level argumen was not passed, try to get it from environemnt
    if log_level is None:
        # retrieve log file name from environment
        log_level = int(os.environ.get("TUCKER_LOGLEVEL", DEFAULT_LOGLEVEL))
    else:
        # convert log level argument to integer
        log_level = int(log_level)

    # retrieve log file name from environment or defaulr
    log_file = os.environ.get("TUCKER_LOGFILE")
    if (log_file is None):
        log_file = os.path.join(DEFAULT_LOGFOLDER, DEFAULT_LOGFILE)
    
    # initialize logging
    logging.basicConfig(filename=log_file, encoding='utf-8', level=log_level, force=True)
    logging.info(f">>>>>>>>>>>> Started at {datetime.now()}")

# setup any stats to be collected
def setup_stats():
    # set file name for battle stats
    battle_stats_file = os.path.join(DEFAULT_LOGFOLDER, BATTLE_STATS_FILE)
    
    # open a file to collect battle stats
    BattleScene.stats_f = open(battle_stats_file, "a")
    logging.info(f">>>>>>>>>>>> Setup battle stats file at {battle_stats_file}")

# perform any final cleanup
def cleanup():
    # close battle stats
    BattleScene.stats_f.close()

def main(log_level = None):

    # setup logging
    setup_logging(log_level)

    # setup stats collection
    setup_stats()

    # create a GameControler object and run program
    game_controller = GameController()
    game_controller.run()

if __name__ == "__main__":   
    # get run time arguments
    log_level = None
    try:
        opts, args = getopt.getopt(sys.argv[1:],"l:",["ifile=","log_level="])
    except getopt.GetoptError:
        print ("tucker_quest.py -l <log_level>")
        sys.exit(2)

    for opt, arg in opts:
        if opt in ['-l', '--log_level']:
            log_level = arg

    # run main program
    main(log_level)

    logging.info(f"<<<<<<<<<<<< Ended at {datetime.now()}")
'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

from fighter import Fighter
import player_character_config as pcc
import json
import logging
from game_types_config import ItemType
from player_interaction import PlayerInteraction as pui

class PlayerCharacter(Fighter):
    def __init__(self, id = None, name = None, pronoun = None, status = None, description = None,
                 level = None, max_health = None, health = None, inventory = None):

        self.id = id
        self.name = name
        self.status = status
        self.description = description
        self.pronoun = pronoun

        # initialize the Fighter elements
        Fighter.__init__(self, level = level, max_health = max_health, health = health)

        # initialize values set later
        self.type = None
        self.inventory = inventory if inventory else []

    # return Boolean to determine whether an item can be used by this character
    def can_use(self, item_type):
        logging.debug(f">>> PlayerCharacter.can_use({item_type})")
        return (self.type in pcc.character_can_use_map and
                item_type in pcc.character_can_use_map[self.type])


    # this utility methid filters a list of items to only those that can be used by this character
    def items_can_use(self, item_list):
        logging.debug(f">>> PlayerCharacter.items_can_use({item_list})")

        # use list comprehension to filter list to only those this character can use
        return [item for item in item_list if self.can_use(item.type)]
    
    # this utility methid filters a list of items to only those that can be applied by this player
    # this is strictly using the item category, but it can be further specialized by a derived class
    def get_applicable_items(self):
        # use list comprehension to filter list to only those this character can consume
        return [item for item in self.inventory  if item.category == ItemType.APPLICABLE_ITEM]

    # return a filtered list of attack items from inventory
    def get_attack_items(self):
        return [item for item in self.inventory if item.category == ItemType.ATTACK_ITEM]

    # return a filtered list of defense items from inventory
    def get_defense_items(self):
        return [item for item in self.inventory if item.category == ItemType.DEFENSE_ITEM]
    
    # return an item from the inventory by id, or None if not found
    def get_item(self, key):
        logging.debug(f">>> PlayerCharacter.get_item({key})")

        # try to find item in inventory. ValueError mean it's not found
        try:
            index = self.inventory.index(key)
            return self.inventory[index]
        except ValueError:
            logging.debug(f"PlayerCharacter.get_item> No item {key} in inventory")
            return None
    
    # return a list of just the item ids in the inventory
    # this is useful because most application objects deal with just idsm and not full item objects
    def inventory_ids(self):
        return [item.id for item in self.inventory]

    # equip defense item
    # this default implementation can be overridden by specific player types for specialized behavior
    def equip_defense_item(self):
        logging.debug(">>> PlayerCharacter.equip_defense_item()")

        # get a list of defense items from the player
        player_defense_items = self.get_defense_items()
        logging.debug(f"PlayerCharacter.equip_defense_item> defense items: {player_defense_items}")

        # if there are more than one defense items to choose from, then ask user to choose one
        if len(player_defense_items) > 1:
            # build a list of item choices for display
            item_choices = [f"{item.name} (defense power between {item.min_power} and {item.max_power})" for item in player_defense_items]
            logging.debug(f"PlayerCharacter.equip_attack_item> defense item options: {item_choices}")

            # ask user to choose a defense item
            item_index = pui.select_defense_item(item_choices)
        
            # set defense item to the corresponding index
            self.defense_item = player_defense_items[item_index]
        # if there is only one defense item, then set it
        elif len(player_defense_items) == 1:
            self.defense_item = player_defense_items[0]

            # tell user of selected defense item
            pui.confirm_defense_item(self.defense_item.name, self.defense_item.min_power, self.defense_item.max_power)
        else:
            # tell user that there are no defense items, and equip them with default
            pui.confirm_no_defense_item()
            self.defense_item = self.get_default_defense_item()


    # equip attack item
    # this default implementation can be overridden by specific player types for specialized behavior
    def equip_attack_item(self):
        logging.debug(">>> PlayerCharacter.equip_attack_item()")

        # get a list of attack items from the player
        player_attack_items = self.get_attack_items()
        logging.debug(f"PlayerCharacter.equip_attack_item> attack items: {player_attack_items}")

        # if there are more than one attack items to choose from, then ask user to choose one
        if len(player_attack_items) > 1:
            # build a list of item choices for display
            item_choices = [f"{item.name} (attack power between {item.min_power} and {item.max_power})" for item in player_attack_items]
            logging.debug(f"PlayerCharacter.equip_attack_item> attack item options: {item_choices}")

            # ask user to choose a attack item
            item_index = pui.select_attack_item(item_choices)
        
            # set attack item to the corresponding index
            self.attack_item = player_attack_items[item_index]
        # if there is only one attack item, then set it
        elif len(player_attack_items) == 1:
            self.attack_item = player_attack_items[0]

            # tell user of selected attack item
            pui.confirm_attack_item(self.attack_item.name, self.attack_item.min_power, self.attack_item.max_power)
        else:
            # tell user that there are no attack items and equip it with default
            pui.confirm_no_attack_item()
            self.attack_item = self.get_default_attack_item()

    # This function will remove an item from the inventory
    def remove_inventory_item(self, item):
        logging.debug(f">>> PlayerCharacter.remove_inventory_item({item})")
        self.inventory.remove(item)

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

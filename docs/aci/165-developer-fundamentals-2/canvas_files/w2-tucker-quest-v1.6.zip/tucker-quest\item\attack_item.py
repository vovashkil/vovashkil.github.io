'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''
import json
import random
from item import Item
from game_types_config import ItemType

class AttackItem(Item):

    def __init__(self, id = None, name = None, description = None, min_power = None, max_power = None):
        # initialize base class
        super().__init__(id, name, description)

        # initialize base items
        self.category = ItemType.ATTACK_ITEM

        # initialize this class
        self.min_power = min_power
        self.max_power = max_power


    # generate a random attack power between min_power and max_power
    def generate_attack(self):
        return random.randint(self.min_power, self.max_power)
    
    @staticmethod
    # create an object from a dictionary
    def from_dict(item_dict):
        return AttackItem(id=item_dict["id"], name=item_dict["name"],
                          description=item_dict["description"],
                          min_power=item_dict["min_power"], max_power=item_dict["max_power"])

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)
    



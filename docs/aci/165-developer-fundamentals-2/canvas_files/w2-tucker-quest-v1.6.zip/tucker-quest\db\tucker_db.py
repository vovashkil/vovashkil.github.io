'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
import os

class TuckerDB():

    # database folder
    DATA_FOLDER = "data"

    def __init__(self, table, filename = None):
        logging.debug(f">>> TuckerDB.__init__({table}, {filename})")

        self.table = table

        # if no filename was passed, construct it with table name
        self.filename = table + ".json" if filename is None else filename

        # full path to file
        self.fullname = os.path.join(self.DATA_FOLDER, self.filename)
        logging.debug(f"__init__> Full DB file: {self.fullname}")

        # initialize empty dictionary
        self.db_dict = None

    # load data from file
    def load_data(self):
        logging.debug(">>> TuckerDB.load_data()")
        with open(self.fullname, "r") as f:
            jsonStr = f.read()
        logging.debug(f"load_data> Read JSON string from file: {jsonStr}")

        # convert JSON string to Python dictionary
        self.db_dict = json.loads(jsonStr)
        logging.debug(f"load_data> Built dict from JSON string: {str(self.db_dict)}")

    # load data from file
    def save_data(self):
        logging.debug(">>> TuckerDB.save_data()")
        with open(self.fullname, "w", encoding="utf-8") as f:
            jsonStr = json.dumps(self.db_dict, indent = 4) 
            f.write(jsonStr)

    # returns full data
    def get_all(self):
        logging.debug(">>> TuckerDB.get_all()")
        return self.db_dict
    
    # get element based on key
    def get(self, key):
        logging.debug(f">>> TuckerDB.get({key})")
        # if dictionary is empty, load data from file
        if self.db_dict is None:
            self.load_data()
        
        # return data from dictionary
        if (key in self.db_dict):
            logging.debug(f"get> Returning: {str(self.db_dict[key])}")
            return self.db_dict[key]
        else:
            logging.debug(f"get> Could not find item with key: {key}")
            return None
    
    # add element based on key
    def add(self, key, data):
        logging.debug(f">>> TuckerDB.set({key},{data})")

        # if dictionary is empty, load data from file
        if self.db_dict is None:
            self.load_data()

        # update data in dictionary
        self.db_dict[key] = data

        # save data to file
        self.save_data()
    
    # update element based on key. In this implementation add and update work the same way, but both are
    # create for consistency, in case we switch to a real database
    def update(self, key, data):
        logging.debug(f">>> TuckerDB.update({key},{data})")

        # if dictionary is empty, load data from file
        if self.db_dict is None:
            self.load_data()

        # update data in dictionary
        self.db_dict[key] = data

        # save data to file
        self.save_data()

    # delete element based on key
    def delete(self, key):
        logging.debug(f">>> TuckerDB.delete({key})")

        # if dictionary is empty, there is nothing to do
        if self.db_dict is None:
            return

        # delete this key from dictionary
        self.db_dict.pop(key, None)

        # save data to file
        self.save_data()



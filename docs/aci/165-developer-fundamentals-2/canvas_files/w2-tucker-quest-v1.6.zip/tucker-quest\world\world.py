'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
from zone import Zone
from area import Area
from location import Location
import logging


class World:
    """ 
    Data class representing the world where the game takes place 
    
    Attributes:
        name (str): The name of the world.
        description (str): A description of the world.
        zones (dict): A dictionary of zones in the world.
        areas (dict): A dictionary of areas in the world.
        starting_location (Location): The starting location of the world.
    """
    def __init__(self, name = None, description = None, zones = None, areas = None, starting_location = None):
        self.name = name
        self.description = description
        self.starting_location = starting_location

        # initialize zones to empty dictionary if not provided
        self.zones = {} if zones is None else zones

        # initialize areas to empty dictionary if not provided
        self.areas = {} if areas is None else areas

    # simple utility to return area based on an area id
    def get_area(self, id):
        logging.debug(f">>> World.get_area({id})")
        # return area in the world, or None if a bad id was passed
        return self.areas.get(id)

    @staticmethod
    # create a World object from a dictionary
    def from_dict(world_dict):
        # iterate through zones data in dictionary to build hash of zones
        zones_dict = {}
        for zone_id, zone_data in world_dict["zones"].items():
            # build a zone object from zone data
            zone_obj = Zone.from_dict(zone_data)

            # add object to zones hash
            zones_dict[zone_id] = zone_obj

        # iterate through areas data in dictionary to build hash of areas
        areas_dict = {}
        for area_id, area_data in world_dict["areas"].items():
            # build a area object from area data
            area_obj = Area.from_dict(area_data)

            # add object to areas hash
            areas_dict[area_id] = area_obj

        # build location object from world_dict dictionary
        starting_location = Location.from_dict(world_dict["starting_location"])
        
        world_obj = World(world_dict["name"], world_dict["description"],
                          zones_dict, areas_dict, starting_location)
        
        logging.debug(f"Constructed World object: ({world_obj})")
        return world_obj

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from scene import Scene
from user_interaction import UserInteraction as ui
import text_utils as tu
from game_types_config import SceneType
from item_db import ItemDB
from game_exception import GameException

class GateScene(Scene):
    def __init__(self, id = None, name = None, description = None, status = None,
                 area1 = None, area2 = None, required_key = None):
        logging.debug(">>> GateScene.__init__()")

        # initialize base class attributes
        super().__init__(id = id, name = name, description = description, status = status)

        # initialize scene type
        self.type = SceneType.GATE_SCENE

        # initialize info on two end of the gate. This attribute is a dictionary with values for 
        # "area_id", and starting position ("row" and "col" attributes)
        self.area1 = area1
        self.area2 = area2

        # key for the gate, or None if it's an open gate
        self.required_key = required_key

    @staticmethod
    # create a gate object from a dictionary
    def from_dict(gate_dict):
        return GateScene(
            id = gate_dict['id'],
            name = gate_dict['name'],
            description = gate_dict['description'],
            status = gate_dict['status'],
            area1 = gate_dict['area1'],
            area2 = gate_dict['area2'],
            required_key = gate_dict['required_key'],
        )
    
    # start this scene
    def start(self):
        logging.debug(">>> GateScene.start()")

        self.status = Scene.IN_PROGRESS

        target_area = None
        # determine target area based on current area
        if (self.area1["id"] == self.player_controller.area.id):
            target_area = self.area2
        else:
            target_area = self.area1

        # check if gate requires key or not, and process accordingly
        if self.required_key is None:
            self.process_open_gate_scene(target_area)
        else:
            self.process_locked_gate_scene(target_area, self.required_key)

        self.status = Scene.NOT_ACTIVE

        
    # process gate scene with an open gate
    def process_open_gate_scene(self, target_area, with_key = False):
        logging.debug(">>> GateScene.process_open_gate_scene()")

        # clear the screen
        tu.clear_screen()

        # ask player whether to go into gate or not
        choice = ui.get_open_gate_option(self.description, with_key)

        # if player wants to go into the gate
        logging.debug(f"GateScene.process_open_gate_scene> Selected option: {choice}")
        if (choice == 1):
            # update player's current position to the other area
            self.player_controller.update_area(target_area["id"], target_area["row"], target_area["col"])

            # print message confirming move
            ui.print_confirm_gate_move(self.player_controller.player.name,
                                       self.player_controller.area.description)

        # else player doesn't want to go in, so move it to an open location
        else:
            self.player_controller.move_to_open_location()

            # print message confirming not to move
            ui.print_confirm_gate_return(self.player_controller.player.name)


    # process gate scene with a locked gate
    def process_locked_gate_scene(self, target_area, key_id):
        logging.debug(">>> GateScene.process_locked_gate_scene()")

        # get reference to player
        player = self.player_controller.player

        # get reference to key object
        item_db = ItemDB()
        key_item = item_db.get(key_id)
        if (key_item is None):
            raise GameException(f"GateScene.process_locked_gate_scene> could not retrieve key with id: {key_id}")
        logging.debug(f"GateScene.process_locked_gate_scene> retrieved key item: {key_item}")

        # if player has the key
        if (player.get_item(key_item) is not None):
            # go through the gate as if it was open, but with the key
            self.process_open_gate_scene(target_area, with_key = True)
        # else tell player they don't have the key
        else:
            # print message confirming not to move
            ui.print_no_key_message(self.description, key_item.description)

            # move player away from the gate
            self.player_controller.move_to_open_location()

    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
from non_player_character import NonPlayerCharacter
import json
from game_types_config import NPCType
from game_text import ITEMS_PROVIDED

class StoryCharacter(NonPlayerCharacter):
    def __init__(self, id = None, name = None, pronoun = None, status = None, description = None, inventory = None, message = None):
        # initialize the Character elements
        NonPlayerCharacter.__init__(self, name = name, pronoun = pronoun, status = status, description = description, id = id, inventory = inventory, message = message)

        # initialize character type
        self.type = NPCType.STORY_CHARACTER

        # initialize values set later
        self.inventory_size = 0

    # pre-action will simply track whether this NPC had items in the inventory initially
    def pre_action(self):
        logging.debug(">>>StoryCharacter.pre_action()")
        self.inventory_size = 0 if self.inventory is None else len(self.inventory)
        logging.debug(f"StoryCharacter.pre_action> Initial inventory: {self.inventory_size}")
        return None

    # this is a place-holder method for any special actions that an NPC performs at the end of a player encounter.
    # This method will be invoked in NPC encounter type scenes. It can be left as is, but if we want to a specialized
    # behavior for certain NPC types, we can override this method.
    def post_action(self):
        logging.debug(">>>StoryCharacter.post_action()")
        
        # if the chracter gave inventory items away, return general message
        curr_inventory_size = 0 if self.inventory is None else len(self.inventory)
        if curr_inventory_size < self.inventory_size:
            logging.debug(f"StoryCharacter.pre_action> {self.inventory_size - curr_inventory_size} were given")
            return ITEMS_PROVIDED
        else:
            return None

    # create an object from a dictionary
    @staticmethod
    def from_dict(char_dict):
        return StoryCharacter(id=char_dict["id"], name=char_dict["name"], pronoun=char_dict["pronoun"], status=char_dict["status"],
                              description=char_dict["description"], inventory = char_dict["inventory"], message=char_dict["message"])
    
    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

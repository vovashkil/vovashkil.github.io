'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from world import World
from quest_giver import QuestGiver
from location import Location
import player_character_config as pcc
from datetime import datetime

class GameSession():
    """ 
    This class is used to store data related to the current game session. It will be used primarily through a global 
    variable initilized in the game_controller module. In addition to being used throughout the game, it will also be
    used to persist data across sessions using the GameSessionDB class.
    
    Attributes:
        player (Player): The player that is currently being used.
        curr_location (Location): The current location of the player.
        enemies_defeated (list): A list of enemies defeated by the player.
        active_quest_givers (list): A list of quest givers that are currently active.
        completed_quests (list): A list of quests that have been completed.
        world (World): The current world. The world itself won't change, but the maps inside the areas will.
    """
    def __init__(self, player = None, curr_location = None, 
                 enemies_defeated = [], active_quest_givers = [], 
                 completed_quests = [], world = None, session_id = None):
        logging.debug(">>> GameSession.__init__()")
        self.player = player
        self.curr_location = curr_location
        self.enemies_defeated = enemies_defeated
        self.active_quest_givers = active_quest_givers
        self.completed_quests = completed_quests
        self.world = world
        
        # if a session id is not provided, then generate one
        if session_id is None:
            # generate a time stamp based on current time
            timestamp = int(datetime.now().timestamp()*1000000)

            # create a mostly unique session id using the timestamp
            # this will be used to differentiate different sessions over time for the same player
            # we only maintain one active session per player, but we can record historical score for different sessions
            self.session_id = str(timestamp)
        else:
            self.session_id = session_id

    @staticmethod
    # Create a object from a dictionary
    # This is more complec than most of the other from_dict functions, because a session is not
    # just a flat data structure. It containes other class objects inside it.
    # The function will rely on the individual classses from_dict methods to create them
    def from_dict(gs_dict):
        logging.debug(">>> GameSession.from_dict()")

        # create a world object from the dictionary inside session JSON
        world = World.from_dict(gs_dict["world"])

        # get player character dictionary from session dictionary
        char_dict = gs_dict["player"]

        # get character type from item dictionary, and make sure it exists
        char_type = char_dict.get("type")
        
        # get reference to the appropriate factory function that creates this character type
        obj_from_dict = pcc.player_from_dict_map[char_type]

        # create appropriate player object from dictionary
        player_obj =  obj_from_dict(char_dict)
        logging.debug(f"GameSession.from_dict> Created player from dictionary: {player_obj}")

        # create a Location object from the dictionary inside session JSON
        curr_location = Location.from_dict(gs_dict["curr_location"])

        # create a list of active quest givers from the dictionary inside session JSON
        active_quest_givers = []
        for quest_giver_dict in gs_dict["active_quest_givers"]:
            active_quest_givers.append(QuestGiver.from_dict(quest_giver_dict))

        return GameSession(player = player_obj, 
                           curr_location = curr_location, 
                           enemies_defeated = gs_dict["enemies_defeated"], 
                           active_quest_givers = active_quest_givers, 
                           completed_quests = gs_dict["completed_quests"], 
                           session_id = gs_dict["session_id"],
                           world = world)
                                      
    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)
    
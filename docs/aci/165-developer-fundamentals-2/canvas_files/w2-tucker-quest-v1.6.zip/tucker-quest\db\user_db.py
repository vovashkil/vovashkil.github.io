'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
import json
from tucker_db import TuckerDB
from user import User


class UserDB():

    # define variables for UserDB database
    TABLE_NAME = "users"

    # make the TuckerDB instance a class variable, so we only have one connection
    tucker_db = None

    def __init__(self):
        logging.debug(">>>  UserDB.__init__()")
        # initalizar TuckerDB instance, if not already done
        if (UserDB.tucker_db is None):
            UserDB.tucker_db = TuckerDB(UserDB.TABLE_NAME)

    # Get user from database
    def get(self, login):
        logging.debug(f">>>  UserDB.get({login})")

        # get user dictionary from UserDB database
        user_dict = UserDB.tucker_db.get(login)

        # if user cannot be found, return None
        if (user_dict is None):
            logging.info(f"Could not find user: {login}")
            return None

        logging.debug(f"Read user from DB: ({user_dict})")

        # create and return object from item dictionary
        return User.from_dict(user_dict)

    # save user to database
    def save(self, user):
        logging.debug(f">>> UserDB.save_user({user})")

        # save used with user id as the key
        UserDB.tucker_db.add(user.login, json.loads(str(user)))



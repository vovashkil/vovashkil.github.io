'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
from non_player_character import NonPlayerCharacter
from fighter import Fighter
import json
from item_db import ItemDB

class Enemy(NonPlayerCharacter, Fighter):
    # defaults max health
    DEFAULT_ENEMY_MAX_HEALTH = 1000

    def __init__(self, id = None, name = None, pronoun = None, status = None, description = None,
                 level = None, max_health = None, attack_item_id = None, defense_item_id = None, inventory = None, message = None):
        logging.debug(">>> Enemy.__init__()")

        # initialize the Character elements
        NonPlayerCharacter.__init__(self, name = name, pronoun = pronoun, status = status, description = description, id = id, inventory = inventory, message = message)

        # initialize the Fighter elements
        Fighter.__init__(self, level = level, max_health = max_health)
        
        # Enemy specific attributes
        self.attack_item_id = attack_item_id
        self.defense_item_id = defense_item_id

        # get reference to DB class to retrieve items
        self.item_db = ItemDB()
        
    @staticmethod
    # create an object from a dictionary
    def from_dict(char_dict):
        return Enemy(id=char_dict["id"], name=char_dict["name"], pronoun=char_dict["pronoun"], status=char_dict["status"],
                    description=char_dict["description"], level=char_dict["level"],
                    max_health=char_dict["max_health"], attack_item_id=char_dict["attack_item_id"],
                    defense_item_id=char_dict["defense_item_id"], inventory=char_dict["inventory"])

    # This will retrieve the item for the enemy to use for attacking, based on the item id
    def equip_attack_item(self):
        logging.debug(">>> Enemy.equip_attack_item()")

        # if there is no item to equip, aquip default
        if self.attack_item_id is None:
            logging.debug("Enemy.equip_attack_item> No attack item so equiping default")
            self.attack_item = self.get_default_attack_item()
            return
        
        # get item from database
        item  = self.item_db.get(self.attack_item_id)
        logging.debug(f"Enemy.equip_attack_item> Retrieved attack item: {item}")

        # set item to the attack item
        self.attack_item = item

    # This will retrieve the item for the enemy to use for defending, based on the item id
    def equip_defense_item(self):
        logging.debug(">>> Enemy.equip_defense_item()")

        # if there is no item to equip, do nothing
        if self.defense_item_id is None:
            logging.debug("Enemy.equip_defense_item> No defense item to equip, so equip default")
            self.defense_item = self.get_default_defense_item()
            return

        # get item from database
        item  = self.item_db.get(self.defense_item_id)
        logging.debug(f"Enemy.equip_defense_item> Retrieved defense item: {item}")

        # set item to the defense item
        self.defense_item = item

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
from applicable_item import ApplicableItem
from game_types_config import ItemType
import logging

class Potion(ApplicableItem):
    def __init__(self, id=None, name=None, description=None, power=None, reusable = False):
        # initialize base class
        super().__init__(id, name, description, reusable)

        # initialize type and category in base class
        self.type = ItemType.POTION_ITEM

        # initialize this class
        self.power = power

    @staticmethod
    # create a object from a dictionary
    def from_dict(item_dict):
        return Potion(id=item_dict["id"], name=item_dict["name"],
                        description=item_dict["description"],
                        power=item_dict["power"], reusable=item_dict["reusable"])
    
    # This methid will apply a healing potion to a player
    def apply_item(self, player):
        logging.debug(">>> Potion.apply_item()")
        
        # make sure there is a player to apply this to
        if (player is None):
            logging.debug("Potion.apply_item> No player to apply this to")
            return

        # increse the player's health by the power of the potion, but not over the max health
        if (player.health + self.power > player.max_health):
            player.health = player.max_health
        else:
            player.health += self.power

        logging.debug(f"Player after applying item: {player}")

        # return a string representing the result of the item application
        return f"{player.name} drinks the healing potion.\nHealth is refreshed to {player.health}."



    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
from tucker_db import TuckerDB
from gate_scene import GateScene

class GateSceneDB():

    # define variables for GateSceneDB database
    TABLE_NAME = "gates"

    # make the TuckerDB instance a class variable, so we only have one connection
    tucker_db = None

    def __init__(self):
        logging.debug(">>> GateSceneDB.__init__()")
        # initalizar TuckerDB instance, if not already done
        if (GateSceneDB.tucker_db is None):
            GateSceneDB.tucker_db = TuckerDB(GateSceneDB.TABLE_NAME)

    # get a gate by id
    def get(self, id):
        logging.debug(f">>> GateSceneDB.get_gate({id})")

        # get item dictionary from GateSceneDB database
        gate_dict = GateSceneDB.tucker_db.get(id)
        logging.debug(f"GateSceneDB> retrieved: {gate_dict}")

        # return gate object based on the dictionary
        return GateScene.from_dict(gate_dict)

'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json

class Location():
    def __init__(self, zone_id = -1, area_id = -1, row = -1, col = -1):
        self.zone_id = zone_id
        self.area_id = area_id
        self.row = row
        self.col = col

    @staticmethod
    # create a Location object from a dictionary
    def from_dict(loc_dict):
        return Location(loc_dict['zone_id'], loc_dict['area_id'], loc_dict['row'], loc_dict['col'])

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)
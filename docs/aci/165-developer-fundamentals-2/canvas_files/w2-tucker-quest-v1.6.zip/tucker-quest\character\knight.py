'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

from player_character import PlayerCharacter
import json
import logging
from game_types_config import PlayerType
from item_config import item_from_dict

class Knight(PlayerCharacter):

    # defaults max health
    DEFAULT_KNIGHT_MAX_HEALTH = 1000

    def __init__(self, id=None, name=None, pronoun = None, status=None, description=None,
                 level=None, max_health=None, sword=None, health=None, inventory=None):
        logging.debug(">>> Knight.__init__()")

        # initialize the PlayerCharacter
        PlayerCharacter.__init__(self, name=name, pronoun = pronoun, status=status, description=description, id=id,
                                 level=level, max_health=max_health, health=health, inventory=inventory)

        # initialize character type
        self.type = PlayerType.KNIGHT

        # initialize values for this class
        self.sword = sword

    @staticmethod
    # create an object from a dictionary
    def from_dict(char_dict):
        logging.debug(f">>> Knight.from_dict({char_dict})")

        # create a list of item objects from the inventory list JSON
        inventory = []
        if (char_dict.get("inventory") is not None):
            for item_dict in char_dict.get("inventory"):
                # use static methos in Item class to build the object of the specific item type, and add to list
                inventory.append(item_from_dict(item_dict))
        logging.debug(f"Knight.from_dict> Created inventory list: {inventory}")

        return Knight(id=char_dict["id"], name=char_dict["name"], pronoun=char_dict["pronoun"], status=char_dict["status"],
                      description=char_dict["description"], level=char_dict["level"],
                      max_health=char_dict["max_health"], sword=char_dict["sword"], health=char_dict["health"],
                      inventory = inventory)

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

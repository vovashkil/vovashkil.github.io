'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from map import Map
import map_config as mc

# this is a string representation for the final chamber in the game
# I essentially use a bunch of random unicode characters to represent "treasures"
# it's not easy to visualize this without running
u_box = u"\u2588"
u_t0 = "$"
u_t1 = u"\u03a8"
u_t2 = u"\u25ca"
u_t3 = u"\u0489"
u_t4 = u"\u046a"
u_t5 = u"\u0466"
t_str1 = " " + u_t0 + " " + u_t5 + "  " + u_t4 + " " + u_t5 + " " + u_t3 
t_str2 = u_t3 + "  " + u_t5 + " " + u_t0 + " " + u_t2 + " " + u_t0 + " "
t_str3 = "  " + u_t1 + " " + u_t4 + " " + u_t0 + " " + u_t2 + " " + u_t5 
t_str4 = " " + u_t5 + " " + u_t3 + "  " + u_t1 + " " + u_t4 + " " + u_t2 
t_str5 = u_t2 + " " + u_t2 + " " + u_t5 + " " + u_t4 + "  " + u_t0 + " "
FINAL_CHAMBER = \
    " ".rjust(6) + u_box.rjust(13, u_box) + " ".rjust(6) + "\n" +\
    " ".rjust(6) + u_box + t_str1.rjust(11) + u_box + " ".rjust(6) + "\n" + \
    " ".rjust(6) + u_box + t_str2.rjust(11) + u_box + " ".rjust(6) + "\n" + \
    u_box.rjust(7,u_box) + t_str3.rjust(11) + u_box.rjust(7,u_box) + "\n" + \
    u_box + t_str5.rjust(11) + t_str1.rjust(12) + u_box + "\n" + \
    u_box + t_str2.rjust(12) + t_str2.rjust(11) + u_box + "\n" + \
    u_box + t_str4.rjust(11) + t_str3.rjust(12) + u_box + "\n" + \
    u_box.rjust(7,u_box) + t_str1.rjust(11) + u_box.rjust(7,u_box) + "\n" + \
    " ".rjust(6) + u_box + t_str3.rjust(11) + u_box + " ".rjust(6) + "\n" + \
    " ".rjust(6) + u_box + t_str4.rjust(11) + u_box + " ".rjust(6) + "\n" + \
    " ".rjust(6) + u_box.rjust(5, u_box) + " ".rjust(3) + u_box.rjust(5, u_box) + " ".rjust(6) + "\n" + \
    " ".rjust(6) + u_box.rjust(5, u_box) + mc.PLAYER_BLOCK_STR + u_box.rjust(5, u_box) + " ".rjust(6)

# stores the map layout for an area in the world, and defines constants for different types of elements
class MapUI:
    """ 
    This class used for all the UI operations related to displaying a map\
    """

    # return the map layout for an area in the world
    @staticmethod
    def display_map_view(area, curr_row, curr_col):
        logging.debug(">>> MapUI.display_map_view()")
        logging.debug(f"MapUI.display_map_view> full_map_view: \n{MapUI.full_map_view(area, curr_row, curr_col)}")
        print(MapUI.filtered_map_view(area, curr_row, curr_col))

    # generate a string representation of the current progresss through the map
    # it is filtered such that it will not show areas not visited
    @staticmethod
    def filtered_map_view(area, curr_row, curr_col):
        logging.debug(">>> MapUI.filtered_map_view()")
        logging.debug(f"MapUI.filtered_map_view> displaying map view for area {area}")

        # get area map and visited objects
        map = area.map
        visited = area.visited

        # initialize map string with a line break
        map_str = "\n"
        # iterate through all cells, and enter appropriate string for each cell
        for row in range(len(map.grid)):
            # at the star of the row, add spaces
            map_str += "  "
            for col in range(len(map.grid[row])):
                # if this is the player location
                if (row == curr_row and col == curr_col):
                    map_str += mc.PLAYER_BLOCK_STR
                # else, if this cell has been visitted, add string corresponding to cell type
                elif (visited[row][col]):
                    map_str += mc.CELL_TYPE_TO_STR_MAP[map.cell_type(row, col)]
                # else, if it's a boundary cell, add string corresponding to cell type
                elif (map.cell_type(row, col) == mc.BOUNDARY_CELL):
                    map_str += mc.BORDER_BLOCK_STR
                # else, which should not happen, add string for unknown
                else:
                    map_str += mc.UNKNOWN_BLOCK_STR
            # at the end of the row, add line break
            map_str += "\n"
                    
        return map_str

    # generate map view which includes un-visited cells
    # primarily for debuggin purposes
    @staticmethod
    def full_map_view(area, curr_row, curr_col):
        logging.debug(">>> MapUI.full_map_view()")
        logging.debug(f"MapUI.full_map_view> displaying map view for area {area}")

        # get area map
        map = area.map

        # iterate through all cells, and enter appropriate string for each cell
        map_str = ""
        for row in range(len(map.grid)):
            for col in range(len(map.grid[row])):
                # if this is the player location
                if (row == curr_row and col == curr_col):
                    map_str += mc.PLAYER_BLOCK_STR
                # else, add string corresponding to cell type
                else:
                    map_str += mc.CELL_TYPE_TO_STR_MAP[map.cell_type(row, col)]

            # at the end of the row, add line break
            map_str += "\n"
                    
        return map_str


'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

'''
This file has configurations to define types for characters
'''

from enemy import Enemy
from story_character import StoryCharacter
from quest_giver import QuestGiver
from warlock import Warlock
from undead import Undead
from beast import Beast
from human_enemy import HumanEnemy
from evil_sherri import EvilSherri

from game_types_config import NPCType

# this maps a non player character type with the factory method that can create it from a JSON based dictionary
npc_from_dict_map = {
    NPCType.STORY_CHARACTER: StoryCharacter.from_dict,
    NPCType.QUEST_GIVER: QuestGiver.from_dict,
    NPCType.WARLOCK: Warlock.from_dict,
    NPCType.UNDEAD: Undead.from_dict,
    NPCType.BEAST: Beast.from_dict,
    NPCType.HUMAN_ENEMY: HumanEnemy.from_dict,
    NPCType.EVIL_SHERRI: EvilSherri.from_dict
}

# This method can create a specific non player character type from a dictionary
# It will leverage the specific npc type from_dict static function, defined in the map above
def npc_from_dict(npc_dict):
    # get npc type from npc dictionary, and make sure it exists
    npc_type = npc_dict.get("type")
    if (npc_type is None):
        return None
    
    # get reference to the from_dict function for this player type
    obj_from_dict = npc_from_dict_map[npc_type]

    # create and return appropriate object from dictionary
    return obj_from_dict(npc_dict)
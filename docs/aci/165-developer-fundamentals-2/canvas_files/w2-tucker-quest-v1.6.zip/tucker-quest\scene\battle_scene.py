'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
from npc_scene import NPCScene
from user_interaction import UserInteraction as ui
from game_exception import GameException
from game_types_config import SceneType
from battle_ui import BattleUI
import game_globals as gg

class BattleScene(NPCScene):

    # This class variable is used to write battle statistics
    # This is not a part of main game functionality. Only used so we can do analysis of player performance offline
    # It will be set in the main program if we want to use it
    stats_f = None

    def __init__(self, npc_id, name = None, description = None, status = None):
        # initialize base class attributes
        super().__init__(npc_id, name, description, status)

        # initialize scene type
        self.type = SceneType.BATTLE_SCENE

        # initialize items set later
        self.player_won = None
        self.battle_ui = None


    # start this scene
    def start(self):
        logging.debug(">>> BattleScene.start()")
        logging.info(f" BattleScene.start> starting fight with {self.id}")

        # initialize scene data (from parent class method)
        self.init_data()

        # initialize object that will handle user interface elements of a battle
        self.battle_ui = BattleUI(self.player, self.npc)

        # print message describing the enemy, and his taunt message
        self.battle_ui.print_enemy_encounter()

        # start battle
        self.battle(self.player, self.npc)

        # if player won, get items from the enemy (from parent class method)
        num_items = 0
        if (self.player_won):
            num_items = self.loot_npc()

        # perform close out activities for this scene (from parent class method)
        self.close_scene()

        # if there were items taken, a message was displayed, so allow user to confirm before continuing
        if (num_items > 0):
            ui.enter_and_clear()

    # start this scene
    def battle(self, player, enemy):
        logging.debug(f">>> BattleScene.battle({self.npc.id} vs {self.player.id})")

        # equip player and enemy items for this battle
        player.equip_defense_item()
        player.equip_attack_item()
        enemy.equip_defense_item()
        enemy.equip_attack_item()
        
        # confirm player is ready to battle, then start
        self.battle_ui.confirm_ready_battle()

        # initialize enemy attack variables to zero, since enemy might be killed in one shot
        enemy_attack = player_defense = enemy_damage = 0

        # loop until there is a winner
        while (self.player_won is None):
            logging.debug("BattleScene.battle> Starting a battle round ...")
            # player attacks enemy (tuple is returned with attack result)
            logging.debug("BattleScene.battle> Player attacks ...")
            player_attack, enemy_defense, player_damage = player.attack(enemy)

            # if enemy is dead ...
            if (enemy.defeated()):
                self.player_won = True
                logging.debug(f" BattleScene.battle> player won battle")

                # add this enemy to the player's list of defeated enemies
                gg.game_session.enemies_defeated.append(enemy.id)

            # start enemy counter attack
            else:
                logging.debug("BattleScene.battle> Enemy attacks ...")
                # enemy attacks player (tuple is returned with attack result)
                enemy_attack, player_defense, enemy_damage = enemy.attack(player)

                # if player is dead, end battle
                if (player.defeated()):
                    self.player_won = False
                    logging.debug(f" BattleScene.battle> enemy won battle")
        
            # display battle round results
            self.battle_ui.display_battle_round(player_attack, player_defense, player_damage,
                                                enemy_attack, enemy_defense, enemy_damage)
            
            # log stats for battle
            BattleScene.log_battle_stats(player.id, player.attack_item.id, player_attack, 
                                         player.defense_item.id, player_defense, player_damage,
                                         enemy.id, enemy.attack_item.id, enemy_attack, 
                                         enemy.defense_item.id,enemy_defense, enemy_damage, self.player_won)
            
        # announce winner (based on whether player won or lost)
        self.battle_ui.display_end_battle(self.player_won)

    @staticmethod
    # These methis logs stats for battles
    # It is not required in any way for application logic
    # Data is strictly used for offline analysis
    def log_battle_stats(player_id, player_attack_item, player_attack, player_defense_item, player_defense, player_damage,
                         enemy_id, enemy_attack_item, enemy_attack, enemy_defense_item, enemy_defense, enemy_damage, player_won):
        logging.debug(f">>> BattleScene.log_battle_stats()")
        
        # if there is not stas file created, do nothing
        if (BattleScene.stats_f == None):
            logging("BattleScene.log_battle_stats()> No stats file")
            return
        
        # Generate CSV string for player attack
        stat_str = f"{gg.game_session.session_id},{enemy_id},{player_id},PLAYER_ATTACK,{player_attack_item},{player_attack},{enemy_defense_item},{enemy_defense},{player_damage}\n"

        # log player attack
        BattleScene.stats_f.write(stat_str)

        # if the enemy attacked (the player did not win)
        if (not player_won):
            # Generate CSV string for player attack
            stat_str = f"{gg.game_session.session_id},{enemy_id},{player_id},ENEMY_ATTACK,{enemy_attack_item},{enemy_attack},{player_defense_item},{player_defense},{enemy_damage}\n"

            # log player attack
            BattleScene.stats_f.write(stat_str)
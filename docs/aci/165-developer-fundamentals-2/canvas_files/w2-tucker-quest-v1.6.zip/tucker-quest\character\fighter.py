'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from player_interaction import PlayerInteraction as pui
from item_config import DEFAULT_ATTACK_ITEM,DEFAULT_DEFENSE_ITEM
from item_db import ItemDB

class Fighter():

    # defaults max health
    DEFAULT_MAX_HEALTH = 1000
    DEFAULT_ATTACK_POWER = 5

    def __init__(self, level = None, max_health = None, attack_item = None, defense_item = None, health = None):
        # initialize values from arguments
        self.level = level
        self.max_health = max_health
        self.attack_item = attack_item
        self.defense_item = defense_item

        # if no max health was specified, use the default
        if (max_health is None):
            self.max_health = Fighter.DEFAULT_MAX_HEALTH
            self.health = self.max_health

        # set health, and if not specified, initially set to max health
        self.health = health if health else self.max_health

    # this default implementation can be overridden by specific player types for specialized behavior
    def attack(self, opponent):
        logging.debug(">>> Fighter.attack()")
        logging.debug(f"attack> {self.id} attacks {opponent.id} with health {opponent.health}")    

        # get attack power for this fighter (use default if no attack item is equipped)
        attack_power = Fighter.DEFAULT_ATTACK_POWER
        if (self.attack_item is not None):
            attack_power = self.attack_item.generate_attack() 

        # invoke enemy's defense function to determine damage
        defense_power = opponent.defense(attack_power)
        logging.debug(f"attack> attack power: {attack_power}, defense power: {defense_power}")

        # calculate damage of this attack (if defense is greater than attack, set damage to 0)
        damage =  (attack_power - defense_power) if (defense_power < attack_power) else 0

        # reduce openents health by the damage
        opponent.decrease_health(damage)
        logging.debug(f"attack> Damage applied: {damage}, Opponent health: {opponent.health}")

        # return tuple to indicate result of the attack
        return (attack_power, defense_power, damage)

    # this default implementation can be overridden by specific player types for specialized behavior
    # by default it will simply return the generated attack from the equipped defense item
    # attack power is passed in in case we want to generate defense proportional to attack (not used in the default)
    def defense(self, attack_power):
        logging.debug(f">>> Fighter.defense({attack_power})")

        defense_power = 0
        if (self.defense_item is not None):
            defense_power = self.defense_item.generate_defense()
        
        logging.debug(f"defense> returning defense power: {defense_power}")
        return defense_power

    # simple boolean function to determine if fighter is alive
    def defeated(self):
        return self.health <= 0
    
    # Decrease fighter health by the specified amount
    # Reset health to 0 if less than zero
    def decrease_health(self, amount):
        self.health -= amount
        if (self.health < 0):
            self.health = 0

    # Increase fighter health by the specified amount
    # Reset to max_health if health greater than max_health
    # If nothing is passed, et to max_health
    def increase_health(self, amount = None):
        if (amount is None):
            amount = self.max_health
        else:
            self.health += amount
            if (self.health > self.max_health):
                self.health = self.max_health
      
    # This utility method retrieves the default attack item from the database
    # it can be used by either players or enemies when the have no item to attack
    def get_default_attack_item(self):
        logging.debug(">>> Fighter.get_default_attack_item()")

        # get reference to DB class to retrieve items
        item_db = ItemDB()

        # return item matching default it
        return item_db.get(DEFAULT_ATTACK_ITEM)
    
    # This utility method retrieves the default defense item from the database
    # it can be used by either players or enemies when the have no item to defend
    def get_default_defense_item(self):
        logging.debug(">>> Fighter.get_default_defense_item()")

        # get reference to DB class to retrieve items
        item_db = ItemDB()

        # return item matching default it
        return item_db.get(DEFAULT_DEFENSE_ITEM)
    
    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

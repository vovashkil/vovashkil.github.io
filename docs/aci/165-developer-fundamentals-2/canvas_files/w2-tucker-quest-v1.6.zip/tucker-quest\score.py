'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from datetime import datetime

ENEMIES_DEFEATED_WEIGHT = 120
COMPLETED_QUESTS_WEIGHT = 110
CELLS_VISITED_WEIGHT = 50
ITEMS_COLLECTED_WEIGHT = 90

class Score():
    def __init__(self, session_id, player_id, game_result):
        logging.debug(">>> Score.__init__()")

        # set base attributes
        self.session_id = session_id
        self.player_id = player_id
        self.game_result = game_result

        # set the user login by parsing the player id (the id has a format "login.name")
        self.login = player_id.split(".")[0]

        # initialize other attributes which are set later
        self.score = None
        self.date = None
        self.enemies_defeated = None
        self.completed_quests = None
        self.cells_visited = None
        self.items_collected = None


    # This method is used to calculate the score based on a game session
    # Right now this uses a very simplistic algorithm, but it could be expanded
    def calculate_score(self, game_session):
        logging.debug(f">>> Score.calculate_score({game_session})")

        # update data based on game session
        self.enemies_defeated = len(game_session.enemies_defeated)
        self.completed_quests = len(game_session.completed_quests)
        self.items_collected = len(game_session.player.inventory)
        self.cells_visited = self.count_visited(game_session.world)

        # set the score date to the current date and time (store ISO string)
        self.date = datetime.now().isoformat()

        logging.debug(f"Score.calculate_score> Calculating score for {self.player_id} session {self.session_id}")
        logging.debug(f"Score.calculate_score> Calculating score based on ({self.enemies_defeated},{self.completed_quests}, {self.cells_visited},{self.items_collected})")
        
        # now calculate the score using an arbitrary rules based on weights
        self.score = \
            ENEMIES_DEFEATED_WEIGHT * self.enemies_defeated + \
            COMPLETED_QUESTS_WEIGHT * self.completed_quests + \
            CELLS_VISITED_WEIGHT * self.cells_visited + \
            ITEMS_COLLECTED_WEIGHT * self.items_collected

        logging.debug(f"Score.calculate_score> Final score for {self.session_id}: {self.score}")
        return self.score

    # This method counts how many cells have been visited in the world
    def count_visited(self, world):
        logging.debug(">>> Score.count_visited()")
        # count number of cells visited across all areas in the world
        count = 0
        for area in world.areas.values():
            visited_array = area.visited
            # if there is not visited array in this area, then skip this area
            if visited_array == None:
                continue
            # count number of cells visited in this area
            for row in range(len(visited_array)):
                for col in range(len(visited_array[row])):
                    if (visited_array[row][col]):
                        count = count + 1
        logging.debug(f"Score.count_visited> total visited: {count}")
        return count

    @staticmethod
    # create an object from a dictionary
    def from_dict(score_dict):
        logging.debug(f">>> Score.from_dict({score_dict})")

        # create empty object
        score = Score()

        # set object attributes from dictionary data
        score.id = score_dict["id"]
        score.login = score_dict["login"]
        score.score = score_dict["score"]
        score.date = score_dict["date"]
        score.player_id = score_dict["player_id"]
        score.enemies_defeated = score_dict["enemies_defeated"]
        score.completed_quests = score_dict["completed_quests"]
        score.cells_visited = score_dict["cells_visited"]
        score.items_collected = score_dict["items_collected"]
        score.game_result = score_dict["game_result"]

        logging.debug(f">>> Score.from_dict({score})")

        return score

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)
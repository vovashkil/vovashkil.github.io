'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import map_config as mc
from game_exception import GameException
import logging

# stores the map layout for an area in the world, and defines constants for different types of elements
class Map:

    # value used for open cells
    OPEN_CELL_VALUE = "     "

    def __init__(self, grid = []):
        # two dimensional array storing map
        self.grid = grid
        self.num_rows = len(grid)
        self.num_cols = len(grid[0])

    # update map grid
    def set_grid(self, grid):
        self.grid = grid
        self.num_rows = len(grid)
        self.num_cols = len(grid[0])

    # return the type of a cell
    # This relies on the fact that the first character in the string is enough to identify the type
    def cell_type(self, row, col):
        cell = self.grid[row][col]
        # get cell_type and make sure it is valid
        cell_type = mc.CELL_TYPE_MAP.get(cell[0])
        if (cell_type is None):
            raise GameException(f"Map.cell_type> No cell type for cell: {cell}")

        return mc.CELL_TYPE_MAP[cell[0]]
    
    # return cell value at a row and clum
    def get(self, row, col):
        return self.grid[row][col]
    
    @staticmethod
    # create a Map object from a dictionary
    def from_dict(map_dict):
        return Map(map_dict["grid"])

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

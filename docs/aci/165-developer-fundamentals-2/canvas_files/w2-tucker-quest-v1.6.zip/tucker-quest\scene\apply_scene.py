'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from scene import Scene
from user_interaction import UserInteraction as ui
from game_exception import GameException
from game_types_config import SceneType
from item_db import ItemDB

# This scene simply allows a user to use an item from their current inventory, therefore it doesn't take any arguments
class ApplyScene(Scene):
    def __init__(self):
        # initialize base class attributes
        super().__init__()

        # get reference to DB class to retrieve NPC items
        self.item_db = ItemDB()

    # start this scene
    def start(self):
        logging.debug(">>> ApplyScene.start()")

        # get reference to player
        player = self.player_controller.player

        # get list of applicable items from player
        applicable_items = player.get_applicable_items()

        # if there are no applicable items, print message
        if (len(applicable_items) == 0):
            logging.info(f"ApplyScene.start> No applicable items")
            ui.print_no_applicable_items(player.name)
            return

        # select item from list of applicable items
        item_idx = ui.select_item(applicable_items)
        item = applicable_items[item_idx]

        # apply this item to the player, and get string representing result
        apply_result = item.apply_item(player)

        ui.print_apply_result(apply_result)

        # unless this was a reusable item, remove it from the player's inventory
        if (not item.reusable):
            player.remove_inventory_item(item)

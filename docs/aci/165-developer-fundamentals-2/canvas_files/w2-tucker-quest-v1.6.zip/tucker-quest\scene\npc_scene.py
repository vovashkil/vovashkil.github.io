'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from scene import Scene
from non_player_character_db import NonPlayerCharacterDB
from user_interaction import UserInteraction as ui
from game_exception import GameException
from game_types_config import SceneType
from item_db import ItemDB

class NPCScene(Scene):
    def __init__(self, npc_id, npc_row = None, npc_col = None,name = None, description = None, status = None):
        # initialize base class attributes
        super().__init__(npc_id, name, description, status)

        # create DB object to retrieve NonPlayerCharacterDB
        self.npc_db = NonPlayerCharacterDB()

        # get reference to DB class to retrieve NPC items
        self.item_db = ItemDB()

        # initialize object data
        self.npc_row = npc_row
        self.npc_col = npc_col
        self.npc = None
        self.player = None

    # intialize this NPC scene data
    def init_data(self):
        logging.debug(">>> NPCScene.init_data()")

        # get reference to player
        self.player = self.player_controller.player

        # if an npc has not been loaded it, do it now
        if (self.npc is None):
            # get npc from database
            self.npc = self.npc_db.get(self.id)

            # if could not retrieve the npc, raise exception
            if (self.npc is None):
                raise GameException(f"NPCScene.init_data> could not retrieve npc with id: {self.id}")
            logging.info(f"NPCScene.start> retrieved npc: {self.npc}")

        # invoke the pre_action method for this NPC (this may do nothing if there is no pre_action required)
        # if the action returns a message, print it
        pre_message = self.npc.pre_action()
        if (pre_message is not None):
            ui.print_message(pre_message)

    # Execute general close out activities for an NPC scene 
    def close_scene(self, remove_npc = True):
        logging.debug(">>> NPCScene.close_scene()")

        # invoke the post_action method for this NPC (this may do nothing if there is no pre_action required)
        # if the action returns a message, print it
        post_message = self.npc.post_action()
        if (post_message is not None):
            ui.print_message(post_message)

        # unless otherwise specified, remove the npc from the map
        if (remove_npc):
            self.player_controller.area.clear_location(self.npc_row, self.npc_col)


    # Loot the NPC, meaning, take its items and give them to the player
    # Returns the number of items taken
    def loot_npc(self):
        logging.debug(">>> NPCScene.loot_npc()")

        # if there are no items in npc's inventory, return
        if ((self.npc.inventory is None) or len(self.npc.inventory) == 0):
            logging.info(f"NPCScene.loot_npc> Nothing in NPC inventory to loot")
            return 0

        # get list of items from npc
        npc_items = self.item_db.query_ids(self.npc.inventory)

        # get list of items that player can use
        player_items = self.player.items_can_use(npc_items)
        logging.info(f"NPCScene.loot_npc> Items player can use: {player_items}")

        # if there are no items that player can use, return
        if (len(player_items) == 0):
            logging.info(f"NPCScene.loot_npc> No items this player can use")
            return 0

        # print message the list of items taken, different based on the type of scene
        if (self.type == SceneType.BATTLE_SCENE):
            ui.print_enemy_items_taken(self.player.name, player_items)
        else:
            ui.print_npc_items_taken(self.player.name, player_items)

        # add items to player inventory
        self.player.inventory.extend(player_items)
        logging.info(f"NPCScene.loot_npc> Updated player inventory: {self.player.inventory}")

        # remove items that were given from npc inventory
        items_given = [item.id for item in player_items]
        self.npc.inventory = [item_id for item_id in self.npc.inventory if item_id not in items_given]

        return len(player_items)

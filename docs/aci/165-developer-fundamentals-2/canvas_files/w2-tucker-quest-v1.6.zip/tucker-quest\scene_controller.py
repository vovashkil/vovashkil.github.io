'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from player_controller import PlayerController
from scene import Scene
from map_ui import MapUI
from gate_scene_db import GateSceneDB
from item_scene import ItemScene
from battle_scene import BattleScene
from encounter_scene import EncounterScene
from apply_scene import ApplyScene
from quest_scene import QuestScene
from end_scene import EndScene
from game_utils import normal_exit
from user_interaction import UserInteraction as ui
import text_utils as tu
from game_types_config import SceneType
from game_session_db import GameSessionDB
import game_globals as gg

# used to support quest scenes
MIN_SCENE_MOVE_INTERVAL = 3

class SceneController():

    # constants to indicate the result of the game
    IN_PROGRESS_GAME = 0
    QUIT_GAME = 1
    WON_GAME = 2
    LOST_GAME = 3

    def __init__(self, curr_scene = None):
        logging.debug(">>> SceneController.__init__()")
        
        # inialize attributes
        self.curr_scene = curr_scene
        self.player_controller = None
        self.gate_scene_db = None
        self.game_session_db = None
        self.game_result = SceneController.IN_PROGRESS_GAME

        # keep track of current scene
        self.curr_scene = None

        # track number of moves, and moves for relevant scenes
        # this is used for certain scenes, where we want to prevent repeated initiations
        self.move_counter = 0
        self.last_scene_move = -MIN_SCENE_MOVE_INTERVAL

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

    # Initialize resources needed for main event loop
    def init(self):
        # initialize database objects
        self.gate_scene_db = GateSceneDB()
        self.game_session_db = GameSessionDB()

        # create an object to control player movements
        self.player_controller = PlayerController()

    # main event loop transitioning through scenere
    def event_loop(self):
        logging.debug(">>> SceneController.event_loop()")

        # initialize resources needed for main event loop
        self.init()

        # Go into out main event loop. We stay in the loop until a condition inside it causes a return
        choice = ""
        while (True):
            # evaluate current player position to check if it triggers a new scene
            # evaluate_position returns a tuple: (scene type, scene data)
            scene_type, scene_data = self.player_controller.evaluate_position()

            # if there is no special scene get player option
            if (scene_type == SceneType.NO_SCENE):
                choice = self.process_standard_options()
                
            # if we reach a gate, process gate scene
            elif (scene_type == SceneType.GATE_SCENE):
                # process gate scene, passing gate id
                self.process_gate_scene(scene_data)

                # after passing through a gate, we should imediatelly check for standard options
                choice = self.process_standard_options()

            # if we found an item, process item scene
            elif (scene_type == SceneType.ITEM_SCENE):
                # process item scene
                self.process_item_scene(scene_data)

            # if we encountered an story character NPC
            elif (scene_type == SceneType.ENCOUNTER_SCENE):
                # process encounter scene, passing npc data
                self.process_encounter_scene(scene_data)

            # if we encountered a quest giver character
            elif (scene_type == SceneType.QUEST_SCENE):
                # check if we have moved enough to process a quest scene
                # this is done to prevent the same quest giver repeatedley, since they 
                # are not removed from the map
                logging.debug(f"SceneController.event_loop()> {self.move_counter - self.last_scene_move} moves since last quest scene")
                if (self.move_counter - self.last_scene_move >= MIN_SCENE_MOVE_INTERVAL):
                    # process encounter scene, passing npc data
                    self.process_quest_scene(scene_data)

                # after a quest encounter, we should imediatelly check for standard options
                self.process_standard_options()

            # if we encountered the end scene
            elif (scene_type == SceneType.END_SCENE):
                # process the end scene
                self.process_end_scene(scene_data)

                # if player won, then quit the event loop with appropriate code
                if (self.game_result == SceneController.WON_GAME):
                    logging.debug(f"SceneController.event_loop()> Game won. Exiting event loop")
                    return self.game_result
                # else, we must be near the end gate, but not on it, so process standard options
                else:
                    choice = self.process_standard_options()

            # if we are facing any so processs battle scene
            elif (scene_type == SceneType.BATTLE_SCENE):
                # process battle scene, passing enemy data
                self.process_battle_scene(scene_data)
                # if player lost, then quit the event loop with appropriate code
                if (self.curr_scene.player_won is False):
                    self.game_result = SceneController.LOST_GAME
                    return self.game_result

            # if a choice was made to quit, then exit event_loop with appropriate vode
            if (choice == ui.QUIT):
                logging.debug("SceneController.event_loop()> User decided to quit")
                self.game_result = SceneController.QUIT_GAME
                return self.game_result
            

    # get option for move from player and return it. 
    # also check for option to quit and get help 
    def process_standard_options(self):
        logging.debug(">>> SceneController.move_option()")

        # clear the screen
        tu.clear_screen()

        # display current map
        self.display_player_map()

        # stay in this loop until a valid choice is made or we exit
        choice = ""
        valid_move = False
        while (not valid_move):

            # ask player where to move
            choice = ui.get_player_move()

            # if player wants to quit, then return that choice
            if (choice == ui.QUIT):
                return choice
            # if user asked for help
            elif (choice == ui.HELP):
                # display help screen and wait for user to continue
                ui.print_help()
                # redisplay display current map and go back to the top to ask for move
                self.display_player_map()
                continue
            # if user asked for save game
            elif (choice == ui.SAVE):
                # process save game
                self.process_save_game()
                # redisplay display current map and go back to the top to ask for move
                self.display_player_map()
                continue
            # if player wants to view the inventory, then display inventory
            elif (choice == ui.INVENTORY):
                ui.display_inventory(self.player_controller.player.inventory)
                # redisplay display current map and go back to the top to ask for move
                self.display_player_map()
                continue
            # if player wants to use an item ...
            elif (choice == ui.USE):
                # process item apply scene
                self.process_apply_scene()

                # redisplay display current map and go back to the top to ask for move
                self.display_player_map()
                continue

            # if user made a valid move choice, try to move player
            elif (self.player_controller.is_valid_move(choice)):
                logging.debug(f"SceneController.move_option()> Move option: {choice}")
                valid_move = True
                self.player_controller.move(choice)

                # increment move counter
                self.move_counter += 1
                
            # else, print error message and ask player to try again
            else:
                ui.print_bad_move()

        return choice


    # simple utility function to display the map based on the player's current location
    def display_player_map(self):
        logging.debug(">>> SceneController.display_player_map()")

        MapUI.display_map_view(self.player_controller.area, 
                               self.player_controller.location.row, 
                               self.player_controller.location.col)
        

    # process a gate scene
    def process_gate_scene(self, cell_data):
        logging.debug(f">>> SceneController.process_gate_scene({cell_data})")

        # get gate scene from database (the gate id is the first element in the cell data))
        self.curr_scene = self.gate_scene_db.get(cell_data[0])

        # set the player controller for the player
        self.curr_scene.player_controller = self.player_controller

        # start the scene
        self.curr_scene.start()


    # process an item scene
    def process_item_scene(self, cell_data):
        logging.debug(f">>> SceneController.process_item_scene({cell_data})")

        # create item scene from item (the item id is the first element in the cell data)
        self.curr_scene = ItemScene(cell_data[0])

        # set the player controller for the player
        self.curr_scene.player_controller = self.player_controller

        # start the scene
        self.curr_scene.start()

    # process an item scene
    def process_apply_scene(self):
        logging.debug(f">>> SceneController.process_apply_scene()")

        # create item scene from item
        self.curr_scene = ApplyScene()

        # set the player controller for the player
        self.curr_scene.player_controller = self.player_controller

        # start the scene
        self.curr_scene.start()


    # process a battle scene
    def process_battle_scene(self, enemy_data):
        logging.debug(f">>> SceneController.process_battle_scene({enemy_data})")

        # clear the screen and redisplay map so player can visualize oponent
        tu.clear_screen()
        self.display_player_map()

        # from the enemy data, get the enemy id, and enemy map location
        enemy_id, enemy_row, enemy_col = enemy_data

        # create battle scene from the enemy id. The enemy id will be the id for the battle scene.
        self.curr_scene = BattleScene(enemy_id, enemy_row, enemy_col)

        # set the player controller for the player and the location of the enemy
        self.curr_scene.player_controller = self.player_controller

        # start the scene
        self.curr_scene.start()


    # process an NPC encounter scene
    def process_encounter_scene(self, npc_data):
        logging.debug(f">>> SceneController.process_encounter_scene({npc_data})")

        # clear the screen and redisplay map so player can visualize NPC
        tu.clear_screen()
        self.display_player_map()

        # from the NPC data, get the npc id, and npc map location
        npc_id, npc_row, npc_col = npc_data

        # create encounter scene from the NPC id. The NPC id will be the id for the encounter scene.
        self.curr_scene = EncounterScene(npc_id, npc_row, npc_col)

        # set the player controller for the player and the location of the enemy
        self.curr_scene.player_controller = self.player_controller

        # start the scene
        self.curr_scene.start()

    # process an quest  scene
    def process_quest_scene(self, npc_data):
        logging.debug(f">>> SceneController.process_quest_scene({npc_data})")

        # update the move counter for quest scenes
        self.last_scene_move = self.move_counter

        # clear the screen and redisplay map so player can visualize quest giver
        tu.clear_screen()
        self.display_player_map()

        # from the NPC data, get the npc id, and npc map location
        npc_id, npc_row, npc_col = npc_data

        # create quest scene from the quest giver id. The  id will be the id for the quest scene.
        self.curr_scene = QuestScene(npc_id, npc_row, npc_col)

        # set the player controller for the player and the location of the enemy
        self.curr_scene.player_controller = self.player_controller

        # start the scene
        self.curr_scene.start()

    # process end scene
    def process_end_scene(self, cell_data):
        logging.debug(f">>> SceneController.process_end_scene({cell_data})")

        # clear the screen and redisplay map so player can visualize the exit
        tu.clear_screen()
        self.display_player_map()

        # create and initilize object to handle end scene
        self.curr_scene = EndScene()
        self.curr_scene.player_controller = self.player_controller

        # check if player is AT the end cell (cell_data has the end gate location)
        if (self.player_controller.location.row == cell_data[1] and self.player_controller.location.col == cell_data[2]):
            logging.debug(f"SceneController.process_end_scene> Player is at end, so starting end scene")
            # start end scene
            self.curr_scene.start()

            # set the game result to won
            self.game_result = SceneController.WON_GAME

        # else, player is near the end cell, so scene will display a message, but game does not end
        else:
            logging.debug(f"SceneController.process_end_scene> Player near the end")
            # start a special pre-start action
            self.curr_scene.pre_start()

    # process saving the game
    def process_save_game(self):
        logging.debug(f">>> SceneController.process_save_game()")

        # save current session into database
        self.game_session_db.save(gg.game_session)
        logging.debug(f"SceneController.process_save_game> saved session")

        ui.print_save_confirmation()

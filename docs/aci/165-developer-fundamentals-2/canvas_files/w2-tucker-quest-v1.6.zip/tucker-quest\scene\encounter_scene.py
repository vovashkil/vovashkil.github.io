'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
from npc_scene import NPCScene
from user_interaction import UserInteraction as ui
from game_types_config import SceneType

class EncounterScene(NPCScene):
    def __init__(self, npc_id, name = None, description = None, status = None):
        # initialize base class attributes
        super().__init__(npc_id, name, description, status)

        # initialize scene type
        self.type = SceneType.ENCOUNTER_SCENE

    # start this scene
    def start(self):
        logging.debug(">>> EncounterScene.start()")
        logging.info(f"EncounterScene.start> starting encounter with {self.id}")

        # initialize scene data (from parent class method)
        self.init_data()

        # print message describing the npc, and his message
        ui.print_npc_encounter(self.npc.pronoun, self.npc.description, self.npc.message)

        # get items from npc (from parent class method)
        self.loot_npc()

        # perform close out activities for this scene (from parent class method)
        self.close_scene()
        
        # confirm and clear screen
        ui.enter_and_clear()


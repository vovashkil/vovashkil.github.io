'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
from tucker_db import TuckerDB
import json
from score import Score

class ScoreDB():
    """ 
    This class is used to persist scores in a database.
    
    Attributes:
        TABLE_NAME (str): The name of the table in the database.
    """

    # define variables for ScoreDB database
    TABLE_NAME = "scores"

    # make the TuckerDB instance a class variable, so we only have one connection
    tucker_db = None

    def __init__(self):
        logging.debug(">>> ScoreDB.__init__()")
        # initalizar TuckerDB instance, if not already done
        if (ScoreDB.tucker_db is None):
            ScoreDB.tucker_db = TuckerDB(ScoreDB.TABLE_NAME)

    # get an score by id
    def get(self, id):
        logging.debug(f">>> ScoreDB.get({id})")

        # get score dictionary from ScoreDB database
        score_dict = ScoreDB.tucker_db.get(id)

        # if score cannot be found, return None
        if (score_dict is None):
            logging.info(f"ScoreDB.get> Could not find score: {id}")
            return None

        # build a Score object from the dictionary
        score_obj =  Score.from_dict(score_dict)
        logging.debug(f"ScoreDB.get> Created object from dictionary: {score_obj}")

        # return the appropriate object base on the score type
        return score_obj
    
    # Save score to database. The session id is used as the key.
    # If the session id already exists, it will be overwritten. So we only maintain one score per active session.
    def save(self, score_obj):
        logging.debug(f">>> ScoreDB.save({score_obj.session_id},{score_obj})")

        # save session using player id as the key
        ScoreDB.tucker_db.add(score_obj.session_id, json.loads(str(score_obj)))

    # get all scores from database
    def get_all(self):
        logging.debug(f">>> ScoreDB.get_all({id})")

        # get all scores dictionary from ScoreDB database
        all_scores_dict = ScoreDB.tucker_db.get_all()

        score_list = [Score.from_dict(score_dict).name for score_dict in all_scores_dict.values()]
        logging.debug(f"ScoreDB.get_all> Returning {len(score_list)} scores")

        return score_list

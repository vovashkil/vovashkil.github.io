'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

'''
This class handles interactions for common player actions.
This is split up from the UserInteraction class, because if we want to add more custom player interactions,
we can do so without having to change the standard game interactions in the UserInteraction class.
'''
import logging

from game_text import *
import text_utils as tu


class PlayerInteraction():

    @staticmethod
    def select_defense_item(item_names):
        print()
        print()
        # ask user to select a player from a numbered list
        choice = tu.ask_numbered_choices(item_names, question_intro = "Select a defense item")

        # return selection postion (adjust the index to normal range starting with 0)
        return choice - 1

    @staticmethod
    def select_attack_item(item_names):
        print()
        print()
        # ask user to select a player from a numbered list
        choice = tu.ask_numbered_choices(item_names, question_intro = "Select an attack item")

        # return selection postion (adjust the index to normal range starting with 0)
        return choice - 1

    @staticmethod
    def confirm_attack_item(item_name, min_power, max_power):
        print()
        print(CONFIRM_ATTACK_ITEM.format(item_name, min_power, max_power))

    @staticmethod
    def confirm_defense_item(item_name, min_power, max_power):
        print()
        print(CONFIRM_DEFENSE_ITEM.format(item_name, min_power, max_power))

    @staticmethod
    def confirm_no_defense_item():
        print()
        print(CONFIRM_NO_DEFENSE_ITEM)

    @staticmethod
    def confirm_no_attack_item():
        print()
        print(CONFIRM_NO_ATTACK_ITEM)



        


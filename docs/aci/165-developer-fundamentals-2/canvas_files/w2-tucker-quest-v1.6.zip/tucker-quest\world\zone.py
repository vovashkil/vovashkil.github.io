'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json

# stores the map layout for an area in the world, and defines constants for different types of elements
class Zone:
    def __init__(self, id = None, name = None, description = None, areas: dict = None):
        self.id = id
        self.name = name
        self.description = description
        self.areas = areas

    @staticmethod
    # create an zone object from a dictionary
    def from_dict(zone_dict):
        return Zone(
            id = zone_dict['id'],
            name = zone_dict['name'],
            description = zone_dict['description'],
            areas = zone_dict['areas']
        )

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)


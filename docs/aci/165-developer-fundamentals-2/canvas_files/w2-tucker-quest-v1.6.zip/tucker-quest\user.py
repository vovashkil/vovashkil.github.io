'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging

# stores the map layout for an area in the world, and defines constants for different types of elements
class User:
    def __init__(self, login = None, first_name = None, last_name = None, characters = None):
        logging.debug(f">>> User.__init__({login},{first_name}, {last_name}, {characters})")

        # initialiaze attributes
        self.login = login
        self.first_name = first_name
        self.last_name = last_name
        self.characters = characters

    @staticmethod
    # create an object from a dictionary
    def from_dict(user_dict):    
        return User(user_dict["login"], user_dict["first_name"], user_dict["last_name"], user_dict["characters"])
    
    # this utility method adds a character to the user's list of characters
    def add_character(self, char_type, char_id):
        logging.debug(f">>> User.add_character({char_type},{char_id})")

        # type in character structure is in string form, so convert before checking
        char_type_str = str(char_type)

        # if there is a character of this type already, add to the list of ids
        if char_type_str in self.characters:
            logging.debug(f"User.add_character> Adding {char_id} to list of {char_type_str} characters)")
            self.characters[char_type_str].append(char_id)
        # else, create a new list of ids for this type
        else:
            logging.debug(f"User.add_character> Creating list of {char_type_str} characters) with {char_id}")
            self.characters[char_type_str] = [char_id]
    
    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)


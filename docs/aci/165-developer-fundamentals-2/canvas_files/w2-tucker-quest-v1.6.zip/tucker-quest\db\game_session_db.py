'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
import json
from tucker_db import TuckerDB
from game_exception import GameException
from game_session import GameSession

class GameSessionDB():
    """ 
    This class is used to persist game sessions in a database. Each player may only have one active session,
    so the player id is used as the primary key.
    
    Attributes:
        TABLE_NAME (str): The name of the table in the database.
    """

    # define variables for GameSessionDB database
    TABLE_NAME = "game_sessions"

    # make the TuckerDB instance a class variable, so we only have one connection
    tucker_db = None

    def __init__(self):
        logging.debug(">>> GameSessionDB.__init__()")
        # initalizar TuckerDB instance, if not already done
        if (GameSessionDB.tucker_db is None):
            GameSessionDB.tucker_db = TuckerDB(GameSessionDB.TABLE_NAME)

    # get an game session by player id
    def get(self, id):
        logging.debug(f">>> GameSessionDB.get({id})")

        # get game session dictionary from GameSessionDB database
        gs_dict = GameSessionDB.tucker_db.get(id)

        # if game session cannot be found, return None
        if (gs_dict is None):
            logging.info(f"GameSessionDB.get> Could not find game session: {id}")
            return None

        logging.debug(f"GameSessionDB.get> Read game session from DB: ({gs_dict})")

        # create appropriate game session object from dictionary
        gs_obj = GameSession.from_dict(gs_dict)
        logging.debug(f"GameSessionDB.get> Created object from dictionary: {gs_obj}")

        # return the appropriate object base on the game session type
        return gs_obj
    
        
    # Save session to database. 
    # Although there is a session_id attribute, we are only saving one active session per player
    # Therefore, the player id is used as the key.
    def save(self, gs_obj):
        logging.debug(f">>> GameSessionDB.save({gs_obj.player.id},{gs_obj})")

        # save session using player id as the key
        GameSessionDB.tucker_db.add(gs_obj.player.id, json.loads(str(gs_obj))) 

    # delete session from database
    def delete(self, gs_obj):
        logging.debug(f">>> GameSessionDB.delete({gs_obj.player.id})")

        # delete session using player id as the key
        GameSessionDB.tucker_db.delete(gs_obj.player.id)


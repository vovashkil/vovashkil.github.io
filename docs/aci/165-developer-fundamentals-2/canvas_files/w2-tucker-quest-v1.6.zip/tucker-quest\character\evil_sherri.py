'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
from enemy import Enemy
import json
from game_types_config import NPCType,ItemType
import game_globals as gg

class EvilSherri(Enemy):
    def __init__(self, id=None, name=None, pronoun = None, status=None, description=None,
                 level=None, max_health=None, attack_item_id=None, defense_item_id=None, inventory = None, message=None):

        # initialize the Enemy elements
        Enemy.__init__(self, name=name, pronoun = pronoun, status=status, description=description, id=id,
                       level=level, max_health=max_health, attack_item_id = attack_item_id, defense_item_id = defense_item_id,
                       inventory = inventory, message=message)

        # initialize character type
        self.type = NPCType.EVIL_SHERRI

    # EvilSherri has special powers that are triggered if a player does not have any holy water
    # If the player has holy water, she will follow a normal attack with the weapon she has
    # But if the player has no holy water, she will wipe the player out with a huge attack
    def attack(self, opponent):
        logging.debug(">>> EvilSherri.attack()")
 
        # if the player has holy water, use the normal attack
        if self.player_has_holy_water():
            logging.debug("EvilSherri.attack> Player has holy water, so using normal attack")    
            return super().attack(opponent)
        
        # else, attack the player with two times their maximum health, and no defense, to guarantee an epic win
        else:
            logging.debug("EvilSherri.attack> Player does not have holy water, so attacking with huge attack")
            attack_power = opponent.max_health * 2
            defense_power = 0
            damage = attack_power

            # reduce openents health by the damage
            opponent.decrease_health(damage)
            logging.debug(f"EvilSherri.attack> Damage applied: {damage}, Opponent health: {opponent.health}")

            # return tuple to indicate result of the attack
            return (attack_power, defense_power, damage)

    # EvilSherri has special powers that are triggered if a player does not have any holy water
    # If the player has holy water, the player attack will be conpletely neutralized
    def defense(self, attack_power):
        logging.debug(">>> EvilSherri.defense()")
 
        # if the player has holy water, use the normal defense
        if self.player_has_holy_water():
            logging.debug("EvilSherri.defense> Player has holy water, so using normal defense")    
            return super().defense(attack_power)
        
        # else, defend with the same attack_power passed in, which will render it useless
        else:
            logging.debug("EvilSherri.defense> returning attack power as the defense power")
            return attack_power

    # Since the player having holy water will impact both attack and defense, we have a utility method
    # that can check for that and be reused in both cases
    def player_has_holy_water(self):
        logging.debug(">>> EvilSherri.player_has_holy_water()")

        # get a reference to the current player
        player = gg.game_session.player

        for item in player.inventory:
            if item.type == ItemType.HOLY_WATER_ITEM:
                logging.debug("EvilSherri.player_has_holy_wate> HolyWater found in player inventory")
                return True
            
        logging.debug("EvilSherri.player_has_holy_wate> HolyWater NOT found in player inventory")
        return False

    # create an object from a dictionary
    @staticmethod
    def from_dict(char_dict):
        return EvilSherri(id=char_dict["id"], name=char_dict["name"], pronoun=char_dict["pronoun"], status=char_dict["status"],
                          description=char_dict["description"], level=char_dict["level"],
                          max_health=char_dict["max_health"], inventory = char_dict["inventory"], message=char_dict["message"],
                          attack_item_id=char_dict["attack_item_id"], defense_item_id=char_dict["defense_item_id"])

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

GAME_WELCOME = \
    "Hello! Welcome to Tucker Quest.\n"

GAME_QUIT = \
    "You decide to quit. You can't take another step.\n"\
    "Hum ... what's that you hear ..."\
    " ... no ... NO ..."\
    "Ahhhhhhhhhhhh!!!!!!!!!!!!!!!\n"\
    "\nGame Over"

ASK_USER_LOGIN = \
    "Enter your user login (maximum 16 alphanumeric characters). If you are a new user, a new profile will be created for you."

SELECT_PLAYER = \
    "Select one of your characters."

USER_WELCOME = \
    "\nWelcome back {}!\n\n"

NEW_USER_WELCOME = \
    "\nI don't see a user registered with the login {}, so you must be new.\n"\
    "Glad to have you join our game. Let's go ahead an create a user record for you."

ASK_NEW_USER_FNAME = \
    "Please enter your first name: "

ASK_NEW_USER_LNAME = \
    "Please enter your last name: "

ASK_CHARACTER_TYPE = \
    "Select the type of character you want to create."

ASK_CHARACTER_NAME = \
    "Enter the name of your character (maximum 16 alphanumeric characters ): "

ASK_CHARACTER_PRONOUN = \
    "Please enter your character's pronoun (e.g. he, she, it, they): "

GAME_PRE_START = \
    "Ok {}. You are ready to start your adventure"
    
GAME_START = \
    "Welcome brave {}. You have taken on a mighty challenge\n"\
    "\n"\
    "For centuries legends have been foretold of the hidden Temple of Lonarra\n"\
    "Lonarra, the ancient queen of the Marconians hid her secret treasure \n"\
    "in the depths of her temple somewhere. After years of searching, you have\n"\
    "finally located her secret temple.\n"\
    "\n"\
    "You open the stone door, and walk in to a dark hallway. Just as you cross the\n"\
    "threshold, a stone wall falls behind you, closing the way behind you.\n"\
    "\n"\
    "You light up a torch, and now you can see the areas immediately surrounding \n"\
    "you. The way back is blocked. Now the only way out, is to go deeper in, and \n"\
    "and face the challenges of the Temple of Lonarra ..."

GAME_CONGRATS = \
    "Congratulations {}!!!"\
    "\n"\
    "You have mastered the secrets of the Temple of Lonarra!\n"\
    "\n"\
    "You win the game!\n"\
    "\n"\
    "Fame and fortune awaits you!"

GAME_LOST = \
    "Sorry {}, but you have been defeated :-("\
    "\n"\
    "Don't be discouraged. Many heroes have fallen inside the Temple of Lonarra!\n"\
    "But the real heroes pick themselves up, and try again.\n"\
    "\n"\
    "So we hope to see you back here soon!"

TEMPLE_FOUND = \
    "You enter this chamber ... and you see riches everywhere!!"\
    "\n"\
    "Gold, diamonds, precious artifact, and magical items.\n"\
    "\n"\
    "{}\n\n"\
    "You have found the secret Temple of Lonarra!!!\n"\
    "\n"\
    "Tears fill your eyes as you recall the perils of your journey."

TEMPLE_NEAR = \
    "You see an ornate gate near you\n"\
    "\n"\
    "Around the gate edges, you can see light shining through.\n"\
    "\n"\
    "What might that be?"\

GAME_INSTRUCTIONS = \
    "                         INSTRUCTIONS\n"\
    "\n"\
    "In order to navigate the through the Temple of Lonarra, you'll be provided \n"\
    "with a view of your current sourroundings (your torch can only illuminate\n"\
    "so far), as well as locations you've already been on in the current section \n"\
    "of the temple.\n"\
    "\n"\
    "At each step, you'll be asked which direction to move relative to the map:\n"\
    "  'w' to move up\n"\
    "  'a' to move left\n"\
    "  's' to move down\n"\
    "  'd' to move right\n"\
    "\n"\
    "In most placed you will also always have the option of entering:\n"\
    "  'i' to view your current inventory\n"\
    "  'u' to use an item\n"\
    "  'q' to quit the game\n"\
    "  'S' (upper case 'S') to save the game\n"\
    "  'h' to display help on the options\n"\
    "\n"\
    "During battles and other challenges, options will also be given as a \n"\
    "numbered list"

MOVE_INSTRUCTIONS = \
    "                         MOVING AROUND\n"\
    "\n"\
    "At each step, you'll be asked which direction to move relative to the map:\n"\
    "  'w' to move up\n"\
    "  'a' to move left\n"\
    "  's' to move down\n"\
    "  'd' to move right\n"\
    "\n"\
    "You will also have the option of entering:\n"\
    "  'i' to view your current inventory\n"\
    "  'u' to use an item\n"\
    "  'S' to save the game\n"\
    "  'q' to quit the game\n"\
    "  'h' to display help on the options"

PLAYER_MOVE_PROMPT = "Enter your move (w/a/s/d) or other option (i/u/S/q/h): "

PLAYER_BAD_MOVE = "Ooops! You can't go that way. Try again."

OPEN_GATE_QUESTION = \
    "You are standing in front of {}. \n\n"\
    "You can either go into to it, and see where it leads, or step back."

OPEN_GATE_WITH_KEY_QUESTION = \
    "You are standing in front of {}.\n"\
    "It is locked, but you have the key for it. \n\n"\
    "You can either go into to it, and see where it leads, or step back."

GATE_NO_KEY_MESSAGE = \
    "You are standing in front of {}.\n"\
    "Unfortunately it is locked, and you don't have the key for it. \n"\
    "You need {} to open this gate.\n"\
    "You will need to search around for this key, or get it from someone."

CONFIRM_GATE_MOVE = \
    "Ok {}, you may continue to a new area, and seek new adventures.\n"\
    "\nYou step through ..."\
    "\n\n"\
    "{}"

CONFIRM_GATE_RETURN = \
    "Ok {}, stay where you are, and continue your search\n"\
    "\nYou take a step back.\n"

ITEM_FOUND = \
    "You look down, and you see something on the ground.\n"\
    "It's {}."

ITEM_CANNOT_USE = \
    "This is not an item you can use, so you toss it aside."

ITEM_CAN_USE = \
    "You can use this, so you pick it up."

ATTACK_POWER = \
    "With your renowned expertise, you estimate this has an attack power\n"\
    "between {} and {} units."

DEFENSE_POWER = \
    "With your renowned expertise, you estimate this has a defense power\n"\
    "between {} and {} units."

ENEMY_ENCOUNTER = \
    "Danger! You approach {}\n\n"\
    "You're not sure what to think, but then your opponent says: \n"\
    "{}\n"\
    "\nLooks have you will have to fight."

ATTACK_ACTION = \
    "{} attacks with {} >>>>>>>>"

COUNTER_ATTACK_ACTION = \
    "<<<<<<<< {} attacks with {}"

ATTACK_RESULT = \
    "Attacker power: {}   -   Opponent defense power: {}   -   Damage: {}\n"\
    "{} health points: {}"

PLAYER_DEATH = \
    "{} succumbs to a final blow, and dies."

OPPONENT_DEATH = \
    "With this last attack, you have defeated {}." 

BATTLE_CONTINUES = \
    "The battle to the death continues ..." 

COUNTER_ATTACK = \
    "Now comes the counter attack ...\n" 

CONFIRM_DEFENSE_ITEM =  \
    "You will be using {} in your defense. This will give you a defense power between {} and {}"

CONFIRM_ATTACK_ITEM = \
    "You will be using {} in your attack. This will give you an attack power between {} and {}"

CONFIRM_NO_DEFENSE_ITEM =  \
    "You have no defensive items in your inventory. You'll be relying strictly on your health."

CONFIRM_NO_ATTACK_ITEM =  \
    "You have no attack items in your inventory. You're forced to use your own wrists."

NPC_ENCOUNTER = \
    "You approach {}. You wait ..."

NPC_MESSAGE = \
    "{} says: \n"\
    "{}\n"

RECEIVE_ITEMS = \
    "You bow in appreciation, and receive these items:\n"

LOOT_ITEMS = \
    "You search your opponent's body, and find some things you can use:\n"

ITEM_NAME_DESCRIPTION = \
    "{} - {}"

NO_APPLICABLE_ITEMS = \
    "Sorry {}, but you have no items you can use right now\n"

ITEMS_PROVIDED = \
    "I hope what I gave you will help you on your quest."

QUEST_DEFAULT_COMPLETE_MSG = \
    "I see you completed your tasks.\nTake these items to assist you in your quest."

QUEST_DEFAULT_INCOMPLETE_MSG = \
    "I am happy to see you again, but you still have not completed all your tasks.\n"\
    "Please complete these remaining tasks and come back when you are done."

INVENTORY_ITEMS = \
    "You are currently carrying these items:"

QUEST_ITEMS_LABEL = \
    "Retrieve these items:"

QUEST_ENEMIES_LABEL = \
    "Defeat these enemies:"

QUEST_GIVER_RETURN = \
    "Once again, you approach {}."

CONFIRM_SAVE_GAME = \
    "Your game progress has been saved.\n\n"\
    "If you quit and restart Tucker Quest, you can start from this point."

ASK_SAVE_GAME = \
    "Would you like to save your game progress? (y/n): "

GAME_GOODBYE = \
    "Thanks for playing Tucker Quest!\n\n"\
    "Come back and play again soon."

ASK_USE_SESSION_INTRO = \
    "We found an existing game session for {}\n"\
    "You can continue from where you were, or start a brand new session.\n"

ASK_USE_SESSION_PROMPT = \
    "Would you like to continue the existing game? (y/n): "

ASK_CONFIRM_NEW_SESSION_INTRO = \
    "Please note that if you start a new session, your old progress deleted.\n"

ASK_CONFIRM_NEW_SESSION_PROMPT = \
    "Are you sure you want to start a new session? (y/n): "

REVERT_TO_USE_SESSION = \
    "\nOk, we will reuse your existing session in then.\n"

CONFIRM_SESSION_LOADED = \
    "Ok {}, your previous session has been restored.\n\n"\
    "You will be re-starting the game where you were when you last saved."

GAME_STATS = \
    "Here are your {} stats: \n"\
    "   Enemies defeated: {}\n"\
    "   Quests completed: {}\n"\
    "   Items collected: {}\n"\
    "   Rooms visited: {}\n"

GAME_SCORE = \
    "Your {} score is {}.\n"

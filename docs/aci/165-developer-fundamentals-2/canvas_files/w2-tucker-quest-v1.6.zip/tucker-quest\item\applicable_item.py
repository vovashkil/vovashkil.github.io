'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''
import json
import random
from item import Item
from game_types_config import ItemType

class ApplicableItem(Item):
    def __init__(self, id = None, name = None, description = None, reusable = None):
        # initialize base class
        super().__init__(id, name, description)

        # initialize base items
        self.category = ItemType.APPLICABLE_ITEM
        self.reusable = reusable

    # base class definition for this method does nothing
    # This should be specialized by the child class
    def apply_item(self, player = None):
        return None
    

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)
    



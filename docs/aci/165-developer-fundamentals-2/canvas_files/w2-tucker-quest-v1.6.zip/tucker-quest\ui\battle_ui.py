'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
from user_interaction import UserInteraction as ui
import time

# This class handles the user interface aspects of a battle scene in the game
class BattleUI():

    def __init__(self, player = None, enemy = None):
        # initialize attributes
        self.player = player
        self.enemy = enemy


    # print message describing the enemy, and his taunt message
    def print_enemy_encounter(self):
        ui.print_enemy_encounter(self.enemy.description, self.enemy.message)

    def confirm_ready_battle(self):
        ui.confirm_ready_battle()

    # display results of round in the screen
    def display_battle_round(self, player_attack, player_defense, player_damage, enemy_attack, enemy_defense, enemy_damage):
        logging.debug(f">>> BattleScene.display_battle_round(player_attack={player_attack}, player_defense={player_defense}, enemy_attack={enemy_attack}, enemy_defense={enemy_defense})")

        # this generates a message indicating the type of player attack action
        ui.announce_attack(self.player.name, self.enemy.name, self.player.attack_item.name)
        time.sleep(1)

        # print the results of the player attack
        ui.print_attack_results(self.player.name, self.enemy.name, player_attack, enemy_defense, player_damage, self.enemy.health)

        # if there was a player counter attack
        if (not self.enemy.defeated()):
            # put a small delay before enemy counterattack
            ui.print_counter_attack()
            time.sleep(1)

            # this generates a message indicating the type of enemy attack action
            ui.announce_counter_attack(self.enemy.name, self.player.name, self.enemy.attack_item.name)
            time.sleep(1)

            # print the results of the enemy attack
            ui.print_attack_results(self.enemy.name, self.player.name, enemy_attack, player_defense, enemy_damage, self.player.health,
                                    rjust = True)

            # the battle continues
            ui.battle_continues(self.player.health > 0)
    
    # Display end result depending on who won
    def display_end_battle(self, player_won):
        # announce winner
        if (player_won):
            ui.print_opponent_death(self.enemy.name)
        else:
            ui.print_player_death(self.player.name)


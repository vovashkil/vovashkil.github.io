'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

from non_player_character import NonPlayerCharacter
import json
from game_types_config import NPCType
import logging
import game_globals as gg

class QuestGiver(NonPlayerCharacter):

    NEW_QUEST = 0
    QUEST_IN_PROGRESS = 1
    QUEST_COMPLETED = 2

    def __init__(self, id = None, name = None, pronoun = None, status = None, description = None, inventory = None, message = None, 
                 complete_message = None, incomplete_message = None, tasks = None, quest_status = None):
        # initialize the Character elements
        NonPlayerCharacter.__init__(self, name = name, pronoun = pronoun, status = status, description = description, id = id, inventory = inventory, message = message)

        # initialize character type
        self.type = NPCType.QUEST_GIVER

        # initialize quest data
        self.complete_message = complete_message
        self.incomplete_message = incomplete_message
        self.tasks = tasks
        self.quest_status = quest_status


    # verify if this quest is completed by comparing the task requirements with the current session information available
    # the method returns any missing tasks, or None if all tasks are completed
    def verify_quest(self):
        logging.debug(f">>> QuestGiver.verify_quest({self.id})")
        logging.debug(f"QuestGiver.verify_quest> player: {gg.game_session.player}")

        # initialize missing tasks
        missing_tasks = {
            "items": [],
            "enemies": []
        }

        # if the task requires items, check for items in the user inventory
        if (self.tasks["items"]):
            # extract list of item ids from player inventory
            player_inventory_ids = gg.game_session.player.inventory_ids()
            logging.debug(f"QuestGiver.verify_quest> player inventory: {player_inventory_ids}")

            # set missing list to any tast item which is not in player inventory
            missing_tasks["items"] = [item for item in self.tasks["items"] 
                                      if item not in player_inventory_ids]
            logging.debug(f"QuestGiver.verify_quest> missing items: {missing_tasks['items']}")

        # if the task requires enemies, check for enemies in the user session
        if (self.tasks["enemies"]):
            logging.debug(f"QuestGiver.verify_quest> Defeated enemies: {gg.game_session.enemies_defeated}")
            # set missing list to any tast enemy which is not in the session list of enemies defeated
            missing_tasks["enemies"] = [enemy for enemy in self.tasks["enemies"] 
                                        if enemy not in gg.game_session.enemies_defeated]
            logging.debug(f"QuestGiver.verify_quest> missing enemies: {missing_tasks['enemies']}")

        # if there are no missing tasks, mark task completed and return None
        if (len(missing_tasks["items"]) == 0 and len(missing_tasks["enemies"]) == 0):
            logging.info(f"QuestGiver.verify_quest> {self.id} Quest completed")
            self.quest_status = QuestGiver.QUEST_COMPLETED
            return None
        
        # else return missing tasks
        else:
            logging.debug(f"QuestGiver.verify_quest> Quest still progress")
            return missing_tasks

    # create an object from a dictionary
    @staticmethod
    def from_dict(char_dict):
        return QuestGiver(id=char_dict["id"], name=char_dict["name"], pronoun=char_dict["pronoun"], status=char_dict["status"],
                          description=char_dict["description"], inventory = char_dict["inventory"], message=char_dict["message"],
                          complete_message = char_dict["complete_message"], incomplete_message = char_dict["incomplete_message"],
                          tasks = char_dict["tasks"], quest_status = char_dict["quest_status"])


    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

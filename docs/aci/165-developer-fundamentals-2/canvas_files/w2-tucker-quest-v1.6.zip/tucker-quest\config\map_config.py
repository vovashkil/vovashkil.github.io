'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

'''
This file has configurations to define map cell types, and various mappings to items and scenes
they appear on the map
'''

from game_types_config import SceneType


# map cell types
OPEN_CELL = 0
WALL_CELL = 1
BOUNDARY_CELL = 2
END_CELL = 3
START_CELL = 4
ENEMY_CELL = 6
QUEST_CELL = 7
GATE_CELL = 8
ITEM_CELL = 9,
SWORD_CELL = 10,
TREASURE_CELL = 11,
SPELL_CELL = 12,
PROTECTION_SPELL_CELL = 13,
ARMOR_CELL = 14,
KEY_CELL = 15,
POTION_CELL = 16,
STORY_CHARACTER_CELL = 17


# String represenations of map elements
WALL_BLOCK_STR = u"\u2588" + u"\u2588" + u"\u2588"
UNKNOWN_BLOCK_STR = u"\u2591" + u"\u2591" + u"\u2591"
START_BLOCK_STR = " " + u"\u25B2" + " "
END_BLOCK_STR = u"\u250c" + u"\u03a0" + u"\u2510"
BORDER_BLOCK_STR = u"\u2593" + u"\u2593" + u"\u2593"
PLAYER_BLOCK_STR = " " + u"\u0178" + " " 
OPEN_BLOCK_STR = " . "
SWORD_BLOCK_STR = " " + u"\u2020" + " "
SPELL_BLOCK_STR = " " + u"\u0424" + " "
ARMOR_BLOCK_STR = " " + u"\u0460" + " "
PROTECTION_SPELL_BLOCK_STR = " " + u"\u00A7" + " "
GATE_BLOCK_STR = " " + u"\u038f" + " "
ENEMY_BLOCK_STR = " " + u"\u04DC" + " "
KEY_BLOCK_STR = " " + u"\u0191" + " "
TREASURE_BLOCK_STR = " " + "$" + " "
POTION_BLOCK_STR = " " + u"\u03ea" + " "
STORY_CHARACTER_BLOCK_STR = " " + u"\u263a" + " "
QUEST_BLOCK_STR = " " + "?" + " "

# This is a list of cell types that represent non player characters
PROXIMITY_CELL_TYPES = [ENEMY_CELL, QUEST_CELL, STORY_CHARACTER_CELL, END_CELL]

# map cell types to map string represenations
CELL_TYPE_TO_STR_MAP = {
    WALL_CELL: WALL_BLOCK_STR,
    OPEN_CELL: OPEN_BLOCK_STR,
    END_CELL: END_BLOCK_STR,
    START_CELL: START_BLOCK_STR,
    GATE_CELL: GATE_BLOCK_STR,
    SWORD_CELL: SWORD_BLOCK_STR,
    SPELL_CELL: SPELL_BLOCK_STR,
    KEY_CELL: KEY_BLOCK_STR,
    TREASURE_CELL: TREASURE_BLOCK_STR,
    POTION_CELL: POTION_BLOCK_STR,
    ENEMY_CELL: ENEMY_BLOCK_STR,
    ARMOR_CELL: ARMOR_BLOCK_STR,
    PROTECTION_SPELL_CELL: PROTECTION_SPELL_BLOCK_STR,
    BOUNDARY_CELL: BORDER_BLOCK_STR,
    STORY_CHARACTER_CELL: STORY_CHARACTER_BLOCK_STR,
    QUEST_CELL: QUEST_BLOCK_STR
}

# map to first character of an id to a cell time
# This relies on the fact that the first character in the id string is enough to identify the type
CELL_TYPE_MAP = {
    "W": WALL_CELL,
    " ": OPEN_CELL,
    "X": END_CELL,
    "B": BOUNDARY_CELL,
    "S": START_CELL,
    "E": ENEMY_CELL,
    "G": GATE_CELL,
    "Q": QUEST_CELL,
    "N": STORY_CHARACTER_CELL,
    "s": SWORD_CELL,
    "t": TREASURE_CELL,
    "k": KEY_CELL,
    "p": PROTECTION_SPELL_CELL,
    "a": ARMOR_CELL,
    "h": POTION_CELL,
    "m": SPELL_CELL
}

# map cell types to scene types
CELL_TYPE_TO_SCENE_MAP = {
    OPEN_CELL: SceneType.NO_SCENE,
    WALL_CELL: SceneType.NO_SCENE,
    BOUNDARY_CELL: SceneType.NO_SCENE,
    START_CELL: SceneType.NO_SCENE,
    QUEST_CELL: SceneType.QUEST_SCENE,
    SWORD_CELL: SceneType.ITEM_SCENE,
    ITEM_CELL: SceneType.ITEM_SCENE,
    SPELL_CELL: SceneType.ITEM_SCENE,
    KEY_CELL: SceneType.ITEM_SCENE,
    TREASURE_CELL: SceneType.ITEM_SCENE,
    ARMOR_CELL: SceneType.ITEM_SCENE,
    PROTECTION_SPELL_CELL: SceneType.ITEM_SCENE,
    POTION_CELL: SceneType.ITEM_SCENE,
    GATE_CELL: SceneType.GATE_SCENE,
    ENEMY_CELL: SceneType.BATTLE_SCENE,
    STORY_CHARACTER_CELL: SceneType.ENCOUNTER_SCENE,
    END_CELL: SceneType.END_SCENE
}



'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from scene import Scene
from user_interaction import UserInteraction as ui
from item_db import ItemDB
from game_types_config import SceneType
from item_config import ItemType

class ItemScene(Scene):
    def __init__(self, id):
        # initialize base class attributes
        super().__init__(id = id)

        # initialize scene type
        self.type = SceneType.ITEM_SCENE

        # get reference to DB class to retrieve this item type
        self.item_db = ItemDB()

        # get item from database
        self.item  = self.item_db.get(id)

        # initialize scene attributes
        self.name = self.item.name
        self.description = self.item.description

    # start this scene
    def start(self):
        logging.debug(">>> ItemScene.start()")
        logging.info(f"ItemScene> checking up item: {self.item.name}")

        # for now, just print the item
        ui.print_item_found(self.item.description)

        # get reference to player
        player = self.player_controller.player

        # print custom message depending on the type of item
        logging.debug(f"start> Item category: {self.item.category}")
        if (self.item.category == ItemType.ATTACK_ITEM):
            ui.print_attack_power(self.item.min_power, self.item.max_power)
        elif (self.item.category == ItemType.DEFENSE_ITEM):
            ui.print_defense_power(self.item.min_power, self.item.max_power)
        
        # check if player can use this item
        if (player.can_use(self.item.type)):
            # add item to players inventory
            player.inventory.append(self.item)
            ui.print_item_can_use()
        else:
            ui.print_item_cannot_use()

        logging.debug(f"start> player after item: {player}")

        # remove item from current loction in map
        curr_row = self.player_controller.location.row
        curr_col = self.player_controller.location.col
        self.player_controller.area.clear_location(curr_row, curr_col)


    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

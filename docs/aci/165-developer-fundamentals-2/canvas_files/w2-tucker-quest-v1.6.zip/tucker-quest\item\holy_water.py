'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
from potion import Potion
from game_types_config import ItemType
import logging

class HolyWater(Potion):
    def __init__(self, id=None, name=None, description=None, power=None, reusable = False):
        # initialize base class
        super().__init__(id, name, description, power, reusable)

        # initialize type and category in base class
        self.type = ItemType.HOLY_WATER_ITEM


    @staticmethod
    # create a object from a dictionary
    def from_dict(item_dict):
        return HolyWater(id=item_dict["id"], name=item_dict["name"],
                         description=item_dict["description"],
                         power=item_dict["power"], reusable=item_dict["reusable"])
    
    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
from item import Item
from game_types_config import ItemType

class Treasure(Item):
    def __init__(self, id=None, name=None, description=None, value=None):
        # initialize base class
        super().__init__(id, name, description)

        # initialize type in base class
        self.type = ItemType.TREASURE_ITEM

        # initialize this class
        self.value = value

    @staticmethod
    # create object from a dictionary
    def from_dict(item_dict):
        return Treasure(id=item_dict["id"], name=item_dict["name"],
                        description=item_dict["description"],
                        value=item_dict["value"])

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)

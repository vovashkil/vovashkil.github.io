'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
import json
from map import Map
import game_globals as gg
from user_interaction import UserInteraction as ui
from game_exception import GameException
import map_config as mc
from game_types_config import SceneType

class PlayerController():

    def __init__(self):
        logging.debug(">>> PlayerController.__init__()")

        # inialize attributes from current game session
        self.player = gg.game_session.player
        self.location = gg.game_session.curr_location
        self.area = gg.world.get_area(gg.game_session.curr_location.area_id)

        # update cells visited based on starting position
        self.update_visited_map()

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)
    
    # Update map of visited locations based on current location    
    def update_visited_map(self):
        logging.debug(">>> PlayerController.update_visited_map()")
        logging.debug(f"PlayerController> updating visited map for area {self.area}")

        # get area map and visited objects
        visited = self.area.visited

        # get current row and colum
        curr_row = self.location.row
        curr_col = self.location.col

        # mark current location an asjecent squares, as having been visited
        # we don't need to check for out of bounds, because all maps are designed with 
        # an extra border of rows and columns in each end
        visited[curr_row][curr_col-1] = True
        visited[curr_row][curr_col] = True
        visited[curr_row][curr_col+1] = True
        visited[curr_row+1][curr_col-1] = True
        visited[curr_row+1][curr_col] = True
        visited[curr_row+1][curr_col+1] = True
        visited[curr_row-1][curr_col-1] = True
        visited[curr_row-1][curr_col] = True
        visited[curr_row-1][curr_col+1] = True    

    # simple utility to check if a location is a wall or boundary
    def is_wall(self, row, col):
        return (self.area.map.cell_type(row, col) == mc.WALL_CELL or
                self.area.map.cell_type(row, col) == mc.BOUNDARY_CELL)
    
    # simple utility to check if a location is open
    def is_open(self, row, col):
        return (self.area.map.cell_type(row, col) == mc.OPEN_CELL)
    
    # simple utility to check type of a cell
    # it will check the current cell if no row or column are passed
    def cell_type(self, row = None, col = None):
        if (row == None):
            return self.area.map.cell_type(self.location.row, self.location.col)
        else:
            return self.area.map.cell_type(row, col)
        
    # simple utility to check if either current position or positions directly around for cells types
    # that activitate on proximity. If one is found, return a tupple of the cell text (which is the id 
    # for the element in that cell) and location found
    def check_around(self, row, col):
        logging.debug(f">>> PlayerController.check_npc({row},{col})")
        # get reference to map
        map = self.area.map

        if (map.cell_type(row, col) in mc.PROXIMITY_CELL_TYPES):
            return (map.get(row,col),row,col)
        elif (map.cell_type(row + 1, col) in mc.PROXIMITY_CELL_TYPES):
            return (map.get(row + 1,col), row + 1, col)
        elif (map.cell_type(row - 1, col) in mc.PROXIMITY_CELL_TYPES):
            return (map.get(row - 1, col), row - 1, col)
        elif (map.cell_type(row, col + 1) in mc.PROXIMITY_CELL_TYPES):
            return (map.get(row, col + 1), row, col + 1)
        elif (map.cell_type(row, col - 1) in mc.PROXIMITY_CELL_TYPES):
            return (map.get(row, col - 1), row, col - 1)
        else:
            return None      
    
    # check if player can move in the direction provided    
    def is_valid_move(self, direction):
        logging.debug(f">>> PlayerController.is_valid_move({direction})")

        # get current row and colum
        curr_row = self.location.row
        curr_col = self.location.col

        # Check for moves unto wallks
        if (direction == ui.LEFT and self.is_wall(curr_row, curr_col - 1)):
            return False
        elif direction == ui.RIGHT and self.is_wall(curr_row, curr_col + 1):
            return False
        elif direction == ui.UP and self.is_wall(curr_row - 1, curr_col):
            return False
        elif direction == ui.DOWN and self.is_wall(curr_row + 1, curr_col):
            return False
        else:
            logging.debug(f"PlayerController> Valid direction {direction}")
            return True
        
    # move player in the direction provided    
    def move(self, direction):
        logging.debug(f">>> PlayerController.move({direction})")

        # update location based on direction
        if direction == ui.LEFT:
            self.location.col = self.location.col - 1
        elif direction == ui.RIGHT:
            self.location.col = self.location.col + 1
        elif direction == ui.UP:
            self.location.row = self.location.row - 1
        elif direction == ui.DOWN:
            self.location.row = self.location.row + 1
        else:
            logging.critical(f"PlayerController> Invalid direction {direction}")
            raise GameException(f"Invalid direction {direction}")

        logging.debug(f"PlayerController> Player moved to ({self.location.row},{self.location.col})")

        # update cells visited based on current location
        self.update_visited_map()

    # Evaluate current position to see if it triggets any special SCENES
    # It will return a tuple with the format (scene_type, cell_data)
    # Where: 
    #    scene_type is a SceneType enum
    #    cell_data is a tuple with the format (cell_text, row, col) or None if there is no scene
    def evaluate_position(self):
        logging.debug(">>> PlayerController.evaluate_position()")

        # start by checking the call we are on top of
        cell_type = self.cell_type()
        cell_data = (self.area.map.get(self.location.row, self.location.col), self.location.row, self.location.col)
        logging.debug(f"PlayerController.evaluate_position> current cell type/value: ({cell_type}/({cell_data}))")

        # map the cell type to a scene type
        scene_type = mc.CELL_TYPE_TO_SCENE_MAP[cell_type]

        # If player is on top of a cell associated with a scene, return it along with value
        if (scene_type !=  SceneType.NO_SCENE):
            logging.info(f"PlayerController.evaluate_position> Player is on top of a scene cell ({cell_data})")
            return (scene_type, cell_data)
        
        # we also need to check if player is near a cell that activates based on proximity to it
        cell_data = self.check_around(self.location.row, self.location.col)
        # if we found a cell around that initiates a scene
        if (cell_data != None):
            logging.info(f"PlayerController.evaluate_position> Scene cell found near: ({cell_data})")
            # return appropriate scene depending on the type of the map cell (cell_data has their location)
            cell_type = self.cell_type(cell_data[1], cell_data[2])
            scene_type = mc.CELL_TYPE_TO_SCENE_MAP[cell_type]
            return (scene_type, cell_data)
        
        # if we got here, than no special scenes were found
        return (SceneType.NO_SCENE, None)
    
    # Move player to a new are  
    def update_area(self, area_id, row, col):
        logging.debug(f">>> PlayerController.update_area({area_id}, {row}, {col})")

        # retrieve full are object corresponding to this area_id
        new_area = gg.world.get_area(area_id)

        # update current player location object
        self.location.area_id = area_id
        self.location.row = row
        self.location.col = col
        self.location.zone_id = new_area.zone_id

        # update current area object
        self.area = new_area

        # update cells visited based on current position
        self.update_visited_map()

    # Move player to an open adjecent location 
    def move_to_open_location(self):
        logging.debug(f">>> PlayerController.move_to_open_location()")

        # get current row and colum
        curr_row = self.location.row
        curr_col = self.location.col

        # update player to the first adjecent open cell found
        if (self.is_open(curr_row, curr_col + 1)):
            self.location.col = curr_col + 1
        elif (self.is_open(curr_row + 1, curr_col)):
            self.location.row = curr_row + 1
        elif (self.is_open(curr_row, curr_col - 1)):
            self.location.col = curr_col - 1
        elif (self.is_open(curr_row - 1, curr_col)):
            self.location.row = curr_row - 1

        # update cells visited based on current position
        self.update_visited_map()

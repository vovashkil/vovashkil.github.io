'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
from npc_scene import NPCScene
from quest_giver import QuestGiver
from user_interaction import UserInteraction as ui
from game_types_config import SceneType
from game_text import QUEST_DEFAULT_COMPLETE_MSG, QUEST_DEFAULT_INCOMPLETE_MSG
import game_globals as gg

class QuestScene(NPCScene):
    def __init__(self, npc_id, name = None, description = None, status = None):
        # initialize base class attributes
        super().__init__(npc_id, name, description, status)

        # initialize scene type
        self.type = SceneType.QUEST_SCENE

    # start this scene
    def start(self):
        logging.debug(">>> QuestScene.start()")
        logging.info(f"QuestScene.start> starting quest with {self.id}")

        # check the game session to see if there is an in progress quest for this quest giver and retrieve it
        for qg in gg.game_session.active_quest_givers:
            if (qg.id == self.id):
                self.npc = qg
                logging.info(f"QuestScene.start> Retrieved active quest giver: {self.npc}")
                break

        # initialize scene data (from parent class method)
        self.init_data()
      
        # cif this is a new quest ...
        if (self.npc.quest_status == QuestGiver.NEW_QUEST):
             self.process_new_quest(self.npc)
        else:
            logging.info(f"QuestScene.start> continuing a quest with {self.npc.id}")
            self.process_continue_quest(self.npc)

    # process a new quest
    def process_new_quest(self, quest_giver):
        logging.debug(">>> QuestScene.process_new_quest()")

        # update the quest status to indicate quest is now in progress
        quest_giver.quest_status = QuestGiver.QUEST_IN_PROGRESS

        # print message describing the quest giver, and his message
        ui.print_npc_encounter(self.npc.pronoun, self.npc.description, self.npc.message)

        # get list of quest items and enemies from quest giver tasks
        item_names, enemy_names = self.get_task_names(quest_giver.tasks)

        # print message with tasks of items to retrieve and enemies to defeat
        ui.print_quest_tasks(item_names, enemy_names)

        # add this quest giver to the game session in progress quests
        gg.game_session.active_quest_givers.append(quest_giver)

        # perform close out activities for this scene, but do not remove quest_giver
        self.close_scene(remove_npc = False)


    # process a continuing quest
    def process_continue_quest(self, quest_giver):
        logging.debug(">>> QuestScene.process_continue_quest()")

        # us quest giver to verify quest status
        missing_tasks = quest_giver.verify_quest()

        # if quest was completed ...
        if (quest_giver.quest_status == QuestGiver.QUEST_COMPLETED):
            # get a completion message from quest giver of use default if there isn't one
            complete_message = quest_giver.complete_message if quest_giver.complete_message else QUEST_DEFAULT_COMPLETE_MSG

            # print message indicating completion
            ui.print_quest_complete(complete_message)

            # get items from quest giver
            self.loot_npc()

            # remove this quest giver from the game session in progress quests
            gg.game_session.active_quest_givers.remove(quest_giver)
            gg.game_session.completed_quests.append(quest_giver.id)

            # perform close out activities for this scene and remove quest_giver
            self.close_scene()

            # confirm and clear screen
            ui.enter_and_clear()
        
        # else, if quest was not completed, then print message describing missing items
        else:
            # get an incompletion message from quest giver of use default if there isn't one
            incomplete_message = quest_giver.incomplete_message if quest_giver.incomplete_message else QUEST_DEFAULT_INCOMPLETE_MSG

            # get list of quest items and enemies from quest giver missing tasks
            item_names, enemy_names = self.get_task_names(missing_tasks)

            # print message listing the missing tasks
            ui.print_quest_continue(quest_giver.name, incomplete_message, item_names, enemy_names)
            
            # perform close out activities for this scene (from parent class method)
            self.close_scene(remove_npc = False)


    # retrieve item names and enemy names from quest giver tasks
    def get_task_names(self, tasks):
        # get list of quest items and enemies from quest giver
        quest_item_ids = tasks["items"]
        quest_enemy_ids = tasks["enemies"]

        # if there are item tasks, retrieve item objects from database
        item_names = None
        if (len(quest_item_ids) > 0):
            # get list of items from npc
            items = self.item_db.query_ids(quest_item_ids)
            item_names = [item.name for item in items]

        # if there are enemies tasks, retrieve enemie objects from database
        enemy_names = None
        if (len(quest_enemy_ids) > 0):
            # get list of items from npc
            enemies =  self.npc_db.query_ids(quest_enemy_ids)
            enemy_names = [enemy.name for enemy in enemies]

        return item_names, enemy_names
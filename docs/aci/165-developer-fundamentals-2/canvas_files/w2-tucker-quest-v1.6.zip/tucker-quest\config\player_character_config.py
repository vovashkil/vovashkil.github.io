'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

'''
This file has configurations to define types for characters
'''

from knight import Knight
from wizard import Wizard

from game_types_config import ItemType, PlayerType

# this maps a character type with the factory method that can create it from a JSON based dictionary
player_from_dict_map = {
    PlayerType.KNIGHT: Knight.from_dict,
    PlayerType.WIZARD: Wizard.from_dict
}

# This method can create a specific player type from a dictionary
# It will leverage the specific player type from_dict static function, defined in the map above
def player_from_dict(player_dict):
    # get player type from player dictionary, and make sure it exists
    player_type = player_dict.get("type")
    if (player_type is None):
        return None
    
    # get reference to the from_dict function for this player type
    obj_from_dict = player_from_dict_map[player_type]

    # create and return appropriate object from dictionary
    return obj_from_dict(player_dict)

# this maps a character type with an empty object of the appropriate character class
player_object_map = {
    PlayerType.KNIGHT: Knight(),
    PlayerType.WIZARD: Wizard()
}

# maps charcter types with types of battle items they can use
character_can_use_map = {
    PlayerType.KNIGHT: [ItemType.SWORD_ITEM, 
                        ItemType.ARMOR_ITEM, 
                        ItemType.TREASURE_ITEM, 
                        ItemType.POTION_ITEM,
                        ItemType.HOLY_WATER_ITEM, 
                        ItemType.KEY_ITEM],
    PlayerType.WIZARD: [ItemType.SPELL_ITEM, 
                        ItemType.PROTECTION_SPELL_ITEM, 
                        ItemType.TREASURE_ITEM, 
                        ItemType.POTION_ITEM,
                        ItemType.HOLY_WATER_ITEM, 
                        ItemType.KEY_ITEM]
}

# maps player character types to string description
player_character_to_str_map = {
    PlayerType.KNIGHT: "Knight",
    PlayerType.WIZARD: "Wizard"
}
'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from tucker_db import TuckerDB
from world import World

class WorldDB():

    # define variables for TuckerDB database
    TABLE_NAME="worlds"

    # make the TuckerDB instance a class variable, so we only have one connection
    tucker_db = None

    def __init__(self):
        logging.debug(">>> WorldDB.__init__()")

        # initalizar TuckerDB instance, if not already done
        if (WorldDB.tucker_db is None):
            WorldDB.tucker_db = TuckerDB(WorldDB.TABLE_NAME)
        
    # return string representation of object, as a JSON structure
    def get(self, name):
        logging.debug(f">>> WorldDB.get_world({name})")

        # get world dictionary from TuckerDB database
        world_dict = WorldDB.tucker_db.get(name)

        # if world cannot be found, log error and exit
        if (world_dict is None):
            logging.critical(f"WorldDB> Could not find world: {name}")
            return None

        logging.debug(f"WorldDB> Read world from DB: ({world_dict})")

        # create a world object from the dictionary with data
        world_obj = World.from_dict(world_dict)

        logging.debug(f"WorldDB> Return World object: ({world_obj})")
        return world_obj



'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging
import json
from tucker_db import TuckerDB
from item_config import item_from_dict

class ItemDB():
    """ 
    This class is used to persist items in a database.
    
    Attributes:
        TABLE_NAME (str): The name of the table in the database.
    """

    # define variables for ItemDB database
    TABLE_NAME = "items"

    # make the TuckerDB instance a class variable, so we only have one connection
    tucker_db = None

    def __init__(self):
        logging.debug(">>> ItemDB.__init__()")
        # initalizar TuckerDB instance, if not already done
        if (ItemDB.tucker_db is None):
            ItemDB.tucker_db = TuckerDB(ItemDB.TABLE_NAME)

    # get an item by id
    def get(self, id):
        logging.debug(f">>> ItemDB.get({id})")

        # get item dictionary from ItemDB database
        item_dict = ItemDB.tucker_db.get(id)

        # if item cannot be found, return None
        if (item_dict is None):
            logging.info(f"ItemDB.get> Could not find item: {id}")
            return None

        # use utility function in item_config to build the correct object of the specific item type
        item_obj =  item_from_dict(item_dict)
        logging.debug(f"ItemDB.get> Created object from dictionary: {item_obj}")

        # return the appropriate object base on the item type
        return item_obj
    
    # get items by a list of ids
    def query_ids(self, id_list):
        logging.debug(f">>> ItemDB.query_ids({id_list})")

        # if id list is empty, return None
        if (id_list is None) or (len(id_list) == 0):
            return None
        
        # iterate through the list of ids and get items
        item_list = []
        for id in id_list:
            item = self.get(id)
            if (item is None):
                logging.debug(f"ItemDB.query_ids> Could not find item for id: {id}")
            else:
                logging.debug(f"ItemDB.query_ids> Found item: {item}")
                item_list.append(self.get(id))

        return item_list



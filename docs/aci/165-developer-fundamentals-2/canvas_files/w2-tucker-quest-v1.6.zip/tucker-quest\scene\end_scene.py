'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from scene import Scene
from user_interaction import UserInteraction as ui

class EndScene(Scene):
    """ 
    This class handles the end scene of the game. At this time, it simply prints appropriate messages to the display. 
    """
    def __init__(self):
        # initialize base class attributes
        super().__init__()

    # start this scene, which will print the appropriate end game messages to the display
    def start(self):
        logging.debug(">>> EndScene.start()")

        # print message indicating the temple was found
        ui.print_temple_found()

    # Before we get to the end (when we are near the end gate), we display a suitable message
    def pre_start(self):
        logging.debug(">>> EndScene.pre_start()")

        # print message indicating the temple was found
        ui.print_temple_near()

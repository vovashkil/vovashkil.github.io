'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

'''
This file has configurations to define types for different game elements
'''

# this enum defines types associated with items
class ItemType:
    # item types
    TREASURE_ITEM = 1
    SWORD_ITEM = 100
    SPELL_ITEM = 101
    ARMOR_ITEM = 200
    PROTECTION_SPELL_ITEM = 201
    KEY_ITEM = 300
    POTION_ITEM = 400
    HOLY_WATER_ITEM = 401
    GENERAL_ATTACK_ITEM = 1000
    GENERAL_DEFENSE_ITEM = 1001

    # item category
    ATTACK_ITEM = 1
    DEFENSE_ITEM = 2
    GENERAL_ITEM = 3
    APPLICABLE_ITEM = 4

# this enum defines types associated with non player characters
class NPCType:
    HUMAN_ENEMY = 1
    WARLOCK = 2
    BEAST = 3
    UNDEAD = 4
    STORY_CHARACTER = 100
    QUEST_GIVER = 200
    EVIL_SHERRI = 300

# this enum defines types associated with player characters
class PlayerType:
    KNIGHT = 1
    WIZARD = 2

# this enum defines types associated with scenes
class SceneType:
    # scene types
    NO_SCENE = 0
    START_SCENE = 1
    GATE_SCENE = 2
    BATTLE_SCENE = 3
    QUEST_SCENE = 5
    ITEM_SCENE = 6
    ENCOUNTER_SCENE = 7
    APPLY_SCENE = 8
    END_SCENE = 100


'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import logging

from game_text import *
import text_utils as tu
import player_character_config as pcc
from map_ui import FINAL_CHAMBER

BATTLE_LINE_LENGHT = 120
BATTLE_RJUST = 60

class UserInteraction():

    # move directions
    LEFT = 'a'
    RIGHT = 'd'
    UP = 'w'
    DOWN = 's'
    INVENTORY = "i"
    USE = 'u'
    SAVE = 'S'
    QUIT = 'q'
    HELP = 'h'
    VALID_MOVES = ["a", "d", "w", "s", "i", "u", "S", "q", "h"]

    @staticmethod
    def print_message(message, confirm = False):
        print()
        print(message)

        if confirm:
            # wait for user to press enter, then clear screen
            tu.enter_to_continue()
            tu.clear_screen()

    @staticmethod    
    def enter_and_clear():
        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()
    
    @staticmethod
    def welcome_game():
        tu.clear_screen()
        print (GAME_WELCOME)
        
    @staticmethod
    def quit_message():
        print (GAME_QUIT)

    @staticmethod
    def ask_user_login():
        return tu.ask_open_question(question_intro = ASK_USER_LOGIN)
    
    @staticmethod
    def welcome_user(user_name):
        print (USER_WELCOME.format(user_name))

    @staticmethod
    def welcome_new_user(login):
        print (NEW_USER_WELCOME.format(login))

    @staticmethod
    def game_pre_start(player_name):
        print()
        print (GAME_PRE_START.format(player_name))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def game_start(player_name):
        print (GAME_START.format(player_name))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def game_instructions():
        print()
        print (GAME_INSTRUCTIONS)

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def ask_new_user_name(login):
        print() # extra line before question
        fname = tu.ask_open_question(ASK_NEW_USER_FNAME, max_length = 16)
        lname = tu.ask_open_question(ASK_NEW_USER_LNAME, max_length = 16)

        return (fname, lname)
    
    @staticmethod
    # asks for a player name and type, and returns a tupple with them
    def ask_character_info():
        print() # extra line before question

        # iterate through configured character types, and build matching lists of types and names
        char_types = []
        type_names = []
        for char_type, type_name in pcc.player_character_to_str_map.items():
            char_types.append(char_type)
            type_names.append(type_name)

        choice = tu.ask_numbered_choices(type_names, question_intro = ASK_CHARACTER_TYPE)

        # set appropriate character type depending on the choice (adjusted to starting index of 0)
        char_type = char_types[choice - 1]


        char_name = tu.ask_open_question(ASK_CHARACTER_NAME, max_length = 16)

        print() # extra line before question
        pronoun = tu.ask_open_question(ASK_CHARACTER_PRONOUN, max_length = 16)

        # return a tupple with player name , pronoun, and type
        return (char_name, pronoun, char_type)

    @staticmethod
    # select player character from list user's charaters (returnes as a (<type>,<id>) tuple)
    def select_player_character(characters):
        print() # extra line before question

        print (SELECT_PLAYER)

        # build list of player names from list of charact objects
        player_ids = []
        player_names = []
        for player_type_str, player_list in characters.items():
            # convert player type to int
            player_type = int(player_type_str)
            for id in player_list:
                # extract player name from id (id has format "<user>.<name>"
                player_name = id.split(".")[1]

                # create an option string combining name and type of character
                player_str = f"{player_name} ({pcc.player_character_to_str_map[player_type]})"

                # add this option to the list, and add track corresponding player type and id
                player_names.append(player_str)
                player_ids.append((player_type, id))

        # add an entry to the end of the list to create a new player character
        player_names.append("Create a new character")

        # ask user to select a player from a numbered list
        choice = tu.ask_numbered_choices(player_names)

        # return None if create new character was selected
        if (choice == len(player_names)):
            return None
        else:
            # return player id and type in that list position (adjust the index to normal range starting with 0)
            return player_ids[choice - 1]
        
    @staticmethod
    def get_player_move():
        logging.debug(">>> UserInteraction.get_player_move()")

        choice = tu.ask_choices(UserInteraction.VALID_MOVES, PLAYER_MOVE_PROMPT)

        # return the choice
        return choice
    
    @staticmethod
    def print_help():
        logging.debug(">>> UserInteraction.print_help()")

        tu.clear_screen()
        print (MOVE_INSTRUCTIONS)

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()
    
    @staticmethod
    def print_save_confirmation():
        logging.debug(">>> UserInteraction.print_save_confirmation()")

        tu.clear_screen()
        print()
        print (CONFIRM_SAVE_GAME)

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def ask_save_game():
        logging.debug(">>> UserInteraction.ask_save_game()")

        tu.clear_screen()
        print()
        return tu.ask_yn_question(ASK_SAVE_GAME)
    
    @staticmethod
    def ask_use_existing_session(player_name):
        logging.debug(">>> UserInteraction.ask_use_existing_session()")
        question_intro = ASK_USE_SESSION_INTRO.format(player_name)

        # ask original question
        tu.clear_screen()
        print()
        use_session = tu.ask_yn_question(ASK_USE_SESSION_PROMPT, question_intro)

        # if use answered no, make sure they understand this will clear their current game
        if (use_session == "n"):
            tu.clear_screen()
            print()
            conf = tu.ask_yn_question(ASK_CONFIRM_NEW_SESSION_PROMPT, ASK_CONFIRM_NEW_SESSION_INTRO)

            tu.clear_screen()

            # if they answered no, print message, and revert initial response
            if (conf == "n"):
                use_session = "y"
                print(REVERT_TO_USE_SESSION)

        # return true if user wants to reuse session, or false otherwise
        return True if use_session == "y" else False

    @staticmethod
    def confirm_session_loaded(player_name):
        logging.debug(">>> UserInteraction.confirm_session_loaded()")

        message = CONFIRM_SESSION_LOADED.format(player_name)

        tu.clear_screen()
        print()
        print (message)

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()


    @staticmethod
    def print_goodbye():
        logging.debug(">>> UserInteraction.print_goodbye()")

        tu.clear_screen()
        print()
        print(GAME_GOODBYE)

    @staticmethod
    def get_open_gate_option(description, with_key = False):
        logging.debug(">>> UserInteraction.get_open_gate_option()")

        # use slightly different question depending on whether it's a gate with key
        question_intro = ""
        if (with_key):
            question_intro = OPEN_GATE_WITH_KEY_QUESTION.format(description)
        else:
            question_intro = OPEN_GATE_QUESTION.format(description)

        option_texts = ["Go into the gate", "Step back"]

        choice = tu.ask_numbered_choices(option_texts, question_prompt = None, question_intro = question_intro)

        # return the choice
        return choice
    
    @staticmethod
    def print_no_key_message(gate_description, key_description):
        print()
        print (GATE_NO_KEY_MESSAGE.format(gate_description, key_description))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()


    @staticmethod
    def print_bad_move():
        print (PLAYER_BAD_MOVE)

    @staticmethod
    def print_confirm_gate_move(player_name, description):
        print()
        print (CONFIRM_GATE_MOVE.format(player_name, description))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_confirm_gate_return(player_name):
        print()
        print (CONFIRM_GATE_RETURN.format(player_name))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_item_found(description):
        tu.clear_screen()
        print()
        print (ITEM_FOUND.format(description))

    @staticmethod
    def print_item_can_use():
        print()
        print(ITEM_CAN_USE)

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_item_cannot_use():
        print()
        print(ITEM_CANNOT_USE)

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_attack_power(min, max):
        print()
        print(ATTACK_POWER.format(min, max))

    @staticmethod
    def print_defense_power(min, max):
        print()
        print(DEFENSE_POWER.format(min, max))

    @staticmethod
    def print_enemy_encounter(enemy_description, enemy_message):
        print()
        print(ENEMY_ENCOUNTER.format(enemy_description, tu.indent_and_quote(enemy_message)))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue("Press Enter and prepare to battle")
        tu.clear_screen()

    @staticmethod
    def print_attack_results(attacker_name, defender_name, attack_power, defense_power, damage, health, rjust = False):
        print()
        attack_str = f"Attack power: {attack_power}"
        defense_str = f"Defense power: {defense_power}"
        damage_str = f"Damage: {damage}"
        dash_str =    "-----------------------------------"
        health_str = f"{defender_name} health: {health}"


        # print left or right justified depending on rjust
        if (rjust):
            print(" ".rjust(BATTLE_RJUST) + attack_str)
            print(" ".rjust(BATTLE_RJUST) + defense_str)
            print(" ".rjust(BATTLE_RJUST) + damage_str)
            print(" ".rjust(BATTLE_RJUST) + dash_str)
            print(" ".rjust(BATTLE_RJUST) + health_str)      
        else:
            print(attack_str)
            print(defense_str)
            print(damage_str)
            print(dash_str)
            print(health_str)


    @staticmethod
    def print_player_death(player_name):
        print()
        print(PLAYER_DEATH.format(player_name))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_opponent_death(opponent_name):
        print()
        print(OPPONENT_DEATH.format(opponent_name))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def battle_continues(player_alive):
        print()
        print()
        if (player_alive):
            print(BATTLE_CONTINUES.center(BATTLE_LINE_LENGHT))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue("Press Enter to continue")
        tu.clear_screen()

    @staticmethod
    def print_counter_attack():
        print()
        print(COUNTER_ATTACK.center(BATTLE_LINE_LENGHT))

    @staticmethod
    def confirm_ready_battle():
        print("\n\n")
        
        tu.enter_to_continue("Press Enter to start the battle")
        tu.clear_screen()

    @staticmethod
    def announce_attack(attacker_name, oponent_name, weapon):
        print()
        print(ATTACK_ACTION.format(attacker_name, weapon))
        
    @staticmethod
    def announce_counter_attack(attacker_name, oponent_name, weapon):
        print()
        print(" ".rjust(BATTLE_RJUST) + COUNTER_ATTACK_ACTION.format(attacker_name, weapon))


    @staticmethod
    def print_npc_encounter(pronoun, enemy_description, npc_message):
        print()
        print(NPC_ENCOUNTER.format(enemy_description))
        tu.enter_to_continue()
        tu.clear_screen()
        print(NPC_MESSAGE.format(pronoun.capitalize(), tu.indent_and_quote(npc_message)))

    @staticmethod
    def print_npc_items_taken (player_name, item_list):
        print()
        print(RECEIVE_ITEMS)

        # iterate through items and print their name and description
        for item in item_list:
            print(tu.indent_text(ITEM_NAME_DESCRIPTION.format(item.name, item.description)))

    @staticmethod
    def print_enemy_items_taken (player_name, item_list):
        print()
        print(LOOT_ITEMS)

        # iterate through items and print their name and description
        for item in item_list:
            print(tu.indent_text(ITEM_NAME_DESCRIPTION.format(item.name, item.description)))

    @staticmethod
    def print_no_applicable_items(player_name):
        tu.clear_screen()
        print()
        print(NO_APPLICABLE_ITEMS.format(player_name))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_apply_result(apply_result):
        print()
        print (apply_result)

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def select_item(item_list):
        tu.clear_screen()
        print()

        # build a list of items choices using name and description
        item_options = [f"{item.name} - {item.description}" for item in item_list]

        # ask user to select item from a numbered list
        choice = tu.ask_numbered_choices(item_options, question_intro = "You look through your bag and find these items you can use:")

        # return selection postion (adjust the index to normal range starting with 0)
        return choice - 1

    @staticmethod
    def display_inventory (item_list):
        tu.clear_screen()
        print()
        print(INVENTORY_ITEMS)

        # iterate through items and print their name and description
        for item in item_list:
            print(tu.indent_text(ITEM_NAME_DESCRIPTION.format(item.name, item.description)))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_quest_tasks(items_list, enemies_list):
        # if there are items in the list, print the item list
        if (items_list):
            print()
            print(QUEST_ITEMS_LABEL)
            for item in items_list:
                print(tu.indent_text(item))

        # if there are enemies in the list, print the enemy list
        if (enemies_list):
            print()
            print(QUEST_ENEMIES_LABEL)
            for enemy in enemies_list:
                print(tu.indent_text(enemy))

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_quest_continue(quest_giver_name, continue_message, items_list, enemies_list):
        # print message indicating we're seeing a known quest giver
        print()
        print(QUEST_GIVER_RETURN.format(quest_giver_name))
        tu.enter_to_continue()
        tu.clear_screen()

        # print the missing quest tasks
        print()
        print(continue_message)
        UserInteraction.print_quest_tasks( items_list, enemies_list)

    @staticmethod
    def print_quest_complete(complete_message):
        print()
        print(complete_message)

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_score(score_obj, final = False):
        tu.clear_screen()

        # use appropriate adjective depending on this is a current or final score
        score_type = "current"
        if (final):
            score_type = "final"

        # prepare strings to print
        score_str = GAME_SCORE.format(score_type, score_obj.score)
        stats_str = GAME_STATS.format(score_type, score_obj.enemies_defeated, score_obj.completed_quests,
                                      score_obj.items_collected, score_obj.cells_visited)

        # print messages
        print()
        print(stats_str)
        print()
        print(score_str) 

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_temple_near():

        # print messages
        print()
        print(TEMPLE_NEAR)
        print()

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_temple_found():
        tu.clear_screen()
        print()
        message = TEMPLE_FOUND.format(FINAL_CHAMBER)
        tu.print_centered_text(message)
        print()

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_won_game(player_name):
        # print game winning message in a big text box
        message = GAME_CONGRATS.format(player_name)
        tu.print_boxed_text(message, padding = 1)

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()

    @staticmethod
    def print_lost_game(player_name):

        # print game winning message in a big text box
        message = GAME_LOST.format(player_name)
        tu.print_boxed_text(message)

        # wait for user to press enter, then clear screen
        tu.enter_to_continue()
        tu.clear_screen()
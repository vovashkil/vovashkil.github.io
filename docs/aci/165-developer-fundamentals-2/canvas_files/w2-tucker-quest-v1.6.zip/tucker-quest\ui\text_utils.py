'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

'''
This module has various utilies used to interact with a terminal scresn
'''

from game_text import *
import os
import time

DEFAULT_TEXT_LINE_LENGTH = 120
TEXT_INDENT = "    "

# Utility to ask an open question
# Optinal validation is done for alphanumeric or max length (defaults to a very large number otherwise)
def ask_open_question(question_prompt = None, question_intro = None, alpha=True, max_length = 100000):
    # if there is an intro line before question, print it
    if (question_intro is not None):
        print(question_intro)

    # if no question was passed, create a general prompt:
    if (question_prompt is None):
        question_prompt = "Answer: "

    answer = ""
    # Keep asking until we get a non-empty valid answer
    while (True):
        answer = input(question_prompt)

        # if answer is not alphanumeric, or is too long, or empty ask again
        if (alpha and not answer.isalnum()) or (len(answer) > max_length) or (len(answer) == 0):
            print("Invalid answer. Please try again.")
        # else, return the anser
        else:
            return answer

# Utility to ask a question with options, when the options are passed in
def ask_choices(options, question_prompt = None, option_texts = None, question_intro = None):
    # if there is an intro line before question, print it
    if (question_intro is not None):
        print(question_intro)

    # if no promp was passed, build one from the options
    if (question_prompt is None):
        question_prompt = "Select option: "
        for option in options:
            prompt += f"{option}, "
        question_prompt = question_prompt[:-2]

    # if option texts were passed, print them along with options
    if (option_texts is not None):
        for i in range(len(option_texts)):
            print(f"{options[i]} - {option_texts[i]}")

    # Keep asking until we get a valid answer (which will return inside the loop)
    while (True):
        answer = input(question_prompt)
        if (answer in options):
            return answer
        else:
            print("Invalid answer. Please try again.")

# Utility to ask a question where options will be selected by entering a number
def ask_numbered_choices(option_texts, question_prompt = None, question_intro = None):
    # if there is an intro line before question, print it
    if (question_intro is not None):
        print(question_intro)

    # if no promp was passed, use a default one
    if (question_prompt is None):
        question_prompt = "Enter the number corresponding to your choice: "

    # print numbered options for each item on option_texts
    for i in range(len(option_texts)):
        print(f"  {i + 1}: {option_texts[i]}")

    # Keep asking until we get a valid answer (which will return inside the loop)
    while (True):
        answer = input(question_prompt)
        # validate answer is a number and in the correct range
        if (answer.isdigit()):
            answer_int = int(answer)
            if (answer_int > 0 and answer_int <= len(option_texts)):
                return answer_int
        else:
            print("Invalid answer. Please try again.")

# Utility to ask a simple yes/no question
def ask_yn_question(question_prompt = None, question_intro = None):
    # if there is an intro line before question, print it
    if (question_intro is not None):
        print(question_intro)

    # if no promp was passed, use a default one
    if (question_prompt is None):
        question_prompt = "Please enter (y/n): "

    # Keep asking until we get a valid answer (which will return inside the loop)
    while (True):
        answer = input(question_prompt).lower()
        # validate answer is a number and in the correct range
        if (answer == "y" or answer == "n"):
            return answer
        else:
            print("Invalid answer. Please try again.")

# clears a terminal screen
def clear_screen(delay = None):
    # add a delay if requested
    if (delay is not None):
        time.sleep(delay)

    # if this is windows, use cls
    if os.name == 'nt':
        os.system('cls')
    # else, use clear
    else:
        os.system('clear')  

# Wait for enter to continue
def enter_to_continue(question_prompt = None, line_length = DEFAULT_TEXT_LINE_LENGTH):
    print()
    # if a question_prompt was passed, use it
    if (question_prompt is None):
        question_prompt = " Press Enter to continue... ".center(line_length, "-")
    else:
        question_prompt = f" {question_prompt} ".center(line_length, "-")

    input(question_prompt)

# simple utility to indent text and put it inside quotes
def indent_and_quote(text):
    # fits add a quote to beginning and end of string (plus the indent)
    text = TEXT_INDENT + '"' +  text + '"'
    
    # now replace \n with an indent
    return text.replace("\n", "\n" + TEXT_INDENT)

# simple utility to indent text 
def indent_text(text):
    # add indent to the beginning
    text = TEXT_INDENT + text
    
    # replace \n with an indent for subsequent lines (if any)
    return text.replace("\n", "\n" + TEXT_INDENT)

# simple utility to print centered text 
def print_centered_text(text, line_width=DEFAULT_TEXT_LINE_LENGTH):
    # since text could be multipline, we start by splitting it
    text_list = text.split("\n")

    # print centered text lines
    mid_width = line_width // 2
    for text in text_list:
        text_pos = mid_width + (len(text) // 2)
        print(text.rjust(text_pos))

# This utility functions are used to print a text sourrounded by a border of boxes
# A multi-line text can be used as well, and padding can be specified
u_box1 = u"\u2588"
u_box2 = u"\u2593"
DEFAULT_BOX_HEIGHT = 20
def print_boxed_line(text, box_width=DEFAULT_TEXT_LINE_LENGTH, padding = 0):
    # space available for text
    text_space = box_width - 2
        
    # left padding for text should be half of the difference between the full area and the text area
    text_lpad = (text_space - len(text)) // 2
    
    # right padding should be the same, but to be safe, we make it the total minus what we already used
    text_rpad = text_space - len(text) - text_lpad
    
    # now just print everything
    print("".rjust(padding) + u_box1 + \
          "".rjust(text_lpad) + text + \
          "".rjust(text_rpad) + u_box1)

def print_boxed_text(text, box_width=DEFAULT_TEXT_LINE_LENGTH, box_height=DEFAULT_BOX_HEIGHT, padding = 0):
    # if padding was specified, reduce the width to accomodate
    if (padding > 0):
        box_width -= padding * 2

    # print carriage returns for padding on top
    for i in range(padding):
        print()

    # since text could be multipline, we start by splitting it
    text_list = text.split("\n")

    # calculate padding om top and bottom of box (do nothing if it's negative)
    pad_height = (box_height // 2) - len(text_list) // 2
    if pad_height < 0:
        return

    # print top line
    print("".rjust(padding) + u_box1.rjust(box_width, u_box1))

    # print half height of blank lines with border
    for i in range(pad_height - 1):
        print("".rjust(padding) + u_box1 + " ".ljust(box_width - 2) + u_box1)
        
    # print centered text lines
    for text in text_list:
        print_boxed_line(text, box_width, padding)

    # print half height of blank lines with border
    for i in range(pad_height - 1):
        print("".rjust(padding) + u_box1 + " ".ljust(box_width - 2) + u_box1)

    # print bottom line
    print("".rjust(padding) + u_box1.rjust(box_width, u_box1))

    # print carriage returns for padding on top
    for i in range(padding):
        print()
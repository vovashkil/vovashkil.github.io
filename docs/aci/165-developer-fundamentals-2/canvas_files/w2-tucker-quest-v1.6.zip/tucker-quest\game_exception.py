'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

# General exception for unexpected game conditions
class GameException(Exception):
    def __init__(self, message="Unexpected game error"):
        self.message = message
        super().__init__(self.message)

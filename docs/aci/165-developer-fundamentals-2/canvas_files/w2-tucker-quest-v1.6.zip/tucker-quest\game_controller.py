'''
WARNING: This code is offered for educational purposes. It is not intended to be used in production.
This code is provided "as is" without warranty of any kind, either expressed or implied.
The author(s) are not responsible for any damages or other consequences that may occur as a result of using this code
The author(s) may not be held liable for any damages or other consequences that may occur as a result of using this code.
'''

import json
import logging
from user_interaction import UserInteraction as ui
from world_db import WorldDB
from user_db import UserDB
from player_character_db import PlayerCharacterDB
from game_session_db import GameSessionDB
from score_db import ScoreDB
from score import Score
from user import User
from scene_controller import SceneController
from game_session import GameSession
from game_utils import error_exit
import game_globals as gg
import player_character_config as pcc

class GameController():

    # World name
    WORLD_NAME  = "Tucker World"

    def __init__(self):
        logging.debug(">>> GameController.__init__()")
        # inialize attributes
        self.scene_controller = SceneController()
        self.state = None

        # initialize DB objects
        self.world_db = WorldDB()
        self.user_db = UserDB()
        self.player_db = PlayerCharacterDB()
        self.game_session_db = GameSessionDB()

        # track whether user info changed
        self.new_user = False
        self.new_player = False

        # track whether this is a new or existing game
        self.new_game = True

    # return string representation of object, as a JSON structure
    def __str__(self):
        return json.dumps(self, default=lambda o: o.__dict__)
    
    # entry point for program
    def run(self):
        logging.debug(">>> GameController.run()")

        # display welcome message
        ui.welcome_game()

        # initialize assets and player for this game
        self.init()

        # start the game
        self.start()

    # initialize assets and player for this game
    def init(self):
        logging.debug(">>> GameController.init()")

        # load player for this game
        player = self.load_player()

        # load assets for this game
        self.load_game_session(player)

        # if this is a new session, display message to confirm start
        if (self.new_game):
            ui.game_pre_start(gg.game_session.player.name)

        # display message with instruction
        ui.game_instructions()

    # initialize assets and player for this game
    def start(self):
        logging.debug(">>> GameController.start()")

        # if this is a new game session, print opening scene
        if (self.new_game):
            # display message welcoming new user
            ui.game_start(gg.game_session.player.name)
        
        # start scene_controller event look, which will run until the game is over
        gameResult = self.scene_controller.event_loop()

        # take appropriate next steps depending on how game ended
        if (gameResult == SceneController.QUIT_GAME):
            logging.debug("GameController.start> Player quit")
            self.process_quit()
        elif (gameResult == SceneController.LOST_GAME):
            logging.debug("GameController.start> Player lost")
            self.process_lost()
        else:
            logging.debug("GameController.start> Player won")
            self.process_won()

    # load a game session for the player
    def load_game_session(self, player):
        logging.debug(">>> GameController.load_game_session()")

        # try to retrieve an existing game session for this player
        game_session = self.game_session_db.get(player.id)

        # if a game session was found ...
        if (game_session is not None):
            logging.info(f"load_game_session> Found game session for player {player}")

            # confirm if user wants to use existing game session
            use_session = ui.ask_use_existing_session(player.name)

            # if user wants to use existing game session ...
            if (use_session):
                logging.info(f"load_game_session> reusing previous session")

                # set global game session to the game session retrieved from DB
                gg.game_session = game_session
                logging.info(f"load_game_session> Set global game session: {gg.game_session}")
                # set global world to the world retrieved from session
                gg.world = game_session.world

                # confirm that session was loaded
                ui.confirm_session_loaded(player.name)

                # update variable to indicate that this is not a new game, and return
                self.new_game = False
                return

            # else, if player wants a new session, clear session from database, and reset 
            else:
                logging.info(f"load_game_session> deleting previous session and starting a new one")
                self.game_session_db.delete(game_session)

                
        # if no game session was found, or we chose not to reuse
        self.create_game_session(player)


    # create a new game session for the player
    def create_game_session(self, player):
        logging.debug(">>> GameController.create_game_session()")

        # initialize game session global variable
        gg.game_session = GameSession()

        # load the standard new World for this game into global variable
        gg.world = self.world_db.get(self.WORLD_NAME)

        # confirm we were able to retrieve world
        if (gg.world is None):
            logging.critical(f"load_assets> Could not find world: {self.WORLD_NAME}")
            error_exit("Could not find world")

        logging.debug(f"load_assets> Global world: {gg.world}")

        # update gg.game_session with a reference to the world
        gg.game_session.world = gg.world

        # update gg.game_session current position with world starting position
        gg.game_session.curr_location = gg.world.starting_location
        logging.info(f"load_assets> Current game session: {gg.game_session}")

        # update game session with selected player
        gg.game_session.player = player
        logging.debug(f"load_player> Current game session: {gg.game_session}")

    # select user and player character
    def load_player(self):
        logging.debug(">>> GameController.load_player()")
        
        # select user
        login = ui.ask_user_login()

        # retrieve user from DB
        user = self.user_db.get(login)

        # if no user was found, create a new one
        if (user is None):
            # display message welcoming new user
            ui.welcome_new_user(login)

            logging.info(f"load_player> No user with login {login}")
            user = self.create_new_user(login)
        else:
            # display message welcoming user
            ui.welcome_user(user.first_name)

        logging.info(f"load_player> User: {user}")

        # select player character from available ones for this user (or create new player)
        player = self.select_player_character(user)
        
        # save user and player DB if needed
        self.save_user_player_db(user, player)

        return player

    # select a player player
    def select_player_character(self, user):
        logging.debug(">>> GameController.select_player({user})")
        
        # if the user has no character yet, create one
        if (len(user.characters) == 0):
            # create player and add to user's character list
            player = self.create_player_character(user)

            # add player id user's list of characters
            user.add_character(player.type, player.id)

            return player

        else:
            # select player character from list user's charaters (as a <type>,<id> tuple)
            player_id_type = ui.select_player_character(user.characters)

            # if no player was selected, create a new one
            if (player_id_type is None):
                logging.debug("select_player_character> User decided to create a new character")
                # create player and add to user's character list
                player = self.create_player_character(user)

                # add player id user's list of characters
                user.add_character(player.type, player.id)

                return player
            
            # if a player was selected, retrieve player object from database
            else:
                logging.debug(f"select_player_character> Selected player character ({player_id_type[1]})")
                player = self.get_player_from_db(player_id_type)
                logging.debug(f"select_player_character> Retrieved player ({player})")
                return player
            

    # get a player from the appropriate database, depending on the type
    def get_player_from_db(self, player_id_type):
        logging.debug(f">>> GameController.get_player_from_db({player_id_type})")

        # get player object from database
        player = self.player_db.get(player_id_type[1])
        logging.debug(f"get_player_from_db> Retrieved player ({player})")

        return player
        

    # create a new user for a login
    def create_new_user(self, login):
        logging.debug(">>> GameController.create_new_user({login})")

        # ask user for user name (returned as (first, last))
        name = ui.ask_new_user_name(login)

        # create a new user with login, name, and empty list of characters
        user = User(login, name[0], name[1], {})

        # note that a new user was created
        self.new_user = True

        # return user
        return user

    # select player
    def create_player_character(self, user):
        logging.debug(f">>> GameController.create_player_character({user})")

        # ask user for character name and type
        player_name, player_pronoum, player_type = ui.ask_character_info()

        # construct player_name and if concatenating user and character name
        id = f"{user.login}.{player_name}"
        
        # create the appropriate player object charater depending on the type
        player = pcc.player_object_map[player_type]
        
        # set basic attributes on player
        player.name = player_name
        player.pronoun = player_pronoum
        player.id = id
        player.level = 1

        logging.info(f"create_player_character> Created player {player}")

        # note that a new player was created
        self.new_user = True

        return player
    
    # persist new user and/or player if needed
    def save_user_player_db(self, user, player):
        logging.debug(f">>> GameController.save_user_player_db({player})")

        # if a new user was created, save it
        if (self.new_user):

            # save the player using DB object
            self.player_db.save(player)

        # if either a new user or new player was created, save user information
        if (self.new_user or self.new_player):
            self.user_db.save(user)

    def process_quit(self):
        logging.debug(f">>> GameController.process_quit()")

        # check if player wants to save
        save_option = ui.ask_save_game()

        # if player wants to save, save game
        if (save_option == "y"):
            # save current session into database
            self.game_session_db.save(gg.game_session)
            logging.debug(f"SceneController.process_save_game> saved session")

            ui.print_save_confirmation()

        # calculate and save score to the database
        self.process_score()

        # print goodbye message
        ui.print_goodbye()

    def process_lost(self):
        logging.debug(f">>> GameController.process_lost()")

        # print congratulations message
        ui.print_lost_game(gg.game_session.player.name)
        
        # persist the player score
        self.process_score()

        # print goodbye message
        ui.print_goodbye()

        # delete the current session from database, since this game is over
        logging.info(f"process_won> deleting session")
        self.game_session_db.delete(gg.game_session)

    def process_won(self):
        logging.debug(f">>> GameController.process_won()")

        # print congratulations message
        ui.print_won_game(gg.game_session.player.name)
        
        # persist the player score
        self.process_score()

        # print goodbye message
        ui.print_goodbye()

        # delete the current session from database, since this game is over
        logging.info(f"process_won> deleting session")
        self.game_session_db.delete(gg.game_session)


    # This method takes care of calculatin the score and persisting it to the database
    def process_score(self):
        logging.debug(f">>> GameController.process_score()")

        # creat a Score object based on current session and game result
        score_obj = Score(gg.game_session.session_id, gg.game_session.player.id, self.scene_controller.game_result)

        # calculate the score for this session (this loads the score attributes with all relevant score values)
        score = score_obj.calculate_score(gg.game_session)
        logging.debug(f"SceneController.process_score> Session score: {score}")

        # persist the score to the database
        score_db = ScoreDB()
        score_db.save(score_obj)

        # print current stats and score, and use the final result to decide whether this is current or final score
        ui.print_score(score_obj, self.scene_controller.game_result == SceneController.WON_GAME)




const ApplicationDetail = () => {
 
    return <div>
      <h1>Individual application detail will go here</h1>
    </div>;
  };
  
  export default ApplicationDetail;
  
import React from 'react'

const Footer = () => {
  return (
    
    <div className='footer'>
        <p>Official Pet Shelter site of AnyCompany Pets</p>
        <p>© 2023 AnyCompany Petshelter. All rights reserved.</p>
    </div>
    
  )
}

export default Footer
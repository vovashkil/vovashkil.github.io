# Pets Shelter frontend

This React + Vite application is used as an activity during the ACI DI2 e-learning.

## Week 2 Setup Instructions
Please follow these setup instructions prior to working on the activities in this lesson.

1. To run the React frontend application, open the IDE terminal and run the following commands.

    ```bash
    cd ~/environment/pet-shelter-client
    npm install
    npm run dev
    ```

1. Open the preview of the React application in another browser tab or window. 

1. To run commands and instructions for Week 2, open a new terminal window.


[React MIT License](https://github.com/facebook/react?tab=MIT-1-ov-file#readme)

React is property of Meta Platforms, Inc. Reference in this lab to any specific commercial product, process, or service, or the use of any trade, firm, or corporation name is provided for informational purposes, and does not constitute endorsement, recommendation, or favoring by Amazon Web Services.

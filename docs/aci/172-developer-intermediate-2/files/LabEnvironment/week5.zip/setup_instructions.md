## Week 5 Setup Instructions

You must complete these setup instructions before starting the Week 5 activities.


1. In the **pet-shelter-client** directory, open the **.env** file. Keep this file open because you will need it for the next steps.

2. <i aria-hidden="true" class="fas fa-keyboard"></i> **Command:** Use the following commands to run the setup script file, which automates the following tasks so that your application is in the same state as the previous week's final solution:
    - Builds and deploys the backend created in the previous week
    - Populates the Amazon DynamoDB tables with seed data
    - Installs packages for the frontend React application

    ```bash
    cd ~/environment
    chmod +x setup_app.sh
    ./setup_app.sh 
    ```

3. In the terminal, copy the Amazon Simple Storage Service (Amazon S3) bucket URL and paste it into your **.env** file to update the **VITE_PET_IMAGES_BUCKET_URL** value. 

4. Save the **.env** file. 

5. Scroll up to see the outputs from the AWS Serverless Application Model (AWS SAM) deployment.

    <i aria-hidden="true" class="fas fa-sticky-note" style="color:#563377"></i> **Note:** The outputs appear in green text.

6. Update **VITE_API_GATEWAY_URL** with the PetsAPI **prod** stage URL from the outputs generated from your AWS SAM deployment.

7. <i aria-hidden="true" class="fas fa-keyboard"></i> **Command:** Enter the following commands to run the React frontend client application.

    ```bash
    cd ~/environment/pet-shelter-client
    npm run dev
    ```

8. To view the React frontend application, expand the preview in the browser.

9.  Open a new terminal tab. This is where you will enter commands for the Week 5 activities.

<i aria-hidden="true" class="far fa-thumbs-up" style="color:#008296"></i> **Task complete:** You are now ready to follow along with the Week 5 activities.


[React MIT License](https://github.com/facebook/react?tab=MIT-1-ov-file#readme)

Reference in this lab to any specific commercial product, process, or service, or the use of any trade, firm, or corporation name is provided for informational purposes, and does not constitute endorsement, recommendation, or favoring by Amazon Web Services.
